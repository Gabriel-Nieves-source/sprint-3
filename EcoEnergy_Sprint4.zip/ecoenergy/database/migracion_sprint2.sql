-- =========================================================
-- RUTA: database/migracion_sprint2.sql
-- Proyecto: EcoEnergy - migración del Sprint 1 al Sprint 2
-- Úsalo SOLO si ya tienes la base de datos del Sprint 1 con
-- datos que quieres conservar. Ejecútalo una sola vez.
-- Si prefieres empezar de cero, ejecuta ecoenergy.sql.
-- =========================================================

USE ecoenergy;

-- Roles y tarifa personal (HU-06, HU-15, HU-16, HU-17)
ALTER TABLE usuarios
    ADD COLUMN rol ENUM('usuario', 'administrador') NOT NULL DEFAULT 'usuario' AFTER password_hash,
    ADD COLUMN tarifa_kwh_personal DECIMAL(10,2) NULL AFTER rol;

ALTER TABLE usuarios
    ADD CONSTRAINT chk_tarifa_personal_positiva CHECK (tarifa_kwh_personal IS NULL OR tarifa_kwh_personal > 0);

-- Historial de tarifas con el administrador que hizo el cambio (HU-15)
ALTER TABLE tarifas
    ADD COLUMN id_usuario_admin INT NULL AFTER activa;

ALTER TABLE tarifas
    ADD CONSTRAINT fk_tarifa_admin
        FOREIGN KEY (id_usuario_admin) REFERENCES usuarios(id_usuario)
        ON DELETE SET NULL
        ON UPDATE CASCADE;

-- Recomendaciones gestionadas por el administrador (HU-17)
CREATE TABLE recomendaciones (
    id_recomendacion    INT AUTO_INCREMENT PRIMARY KEY,
    titulo              VARCHAR(120) NOT NULL UNIQUE,
    descripcion         VARCHAR(1000) NOT NULL,
    id_categoria        INT NULL,
    activa              TINYINT(1) NOT NULL DEFAULT 1,
    id_usuario_admin    INT NULL,
    fecha_creacion      DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_recomendacion_categoria
        FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_recomendacion_admin
        FOREIGN KEY (id_usuario_admin) REFERENCES usuarios(id_usuario)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Historial de reportes PDF (HU-10, HU-16)
CREATE TABLE reportes_generados (
    id_reporte          INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario          INT NOT NULL,
    id_hogar            INT NULL,
    nombre_hogar        VARCHAR(100) NOT NULL,
    consumo_mensual_kwh DECIMAL(12,3) NOT NULL,
    costo_mensual_cop   DECIMAL(14,2) NOT NULL,
    tarifa_kwh_cop      DECIMAL(10,2) NOT NULL,
    fecha_generacion    DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reporte_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_reporte_hogar
        FOREIGN KEY (id_hogar) REFERENCES hogares(id_hogar)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Historial del asistente IA (HU-11)
CREATE TABLE consultas_ia (
    id_consulta     INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario      INT NOT NULL,
    id_hogar        INT NOT NULL,
    pregunta        VARCHAR(500) NOT NULL,
    respuesta       TEXT NOT NULL,
    modo            VARCHAR(20) NOT NULL,
    fecha_consulta  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_consulta_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_consulta_hogar
        FOREIGN KEY (id_hogar) REFERENCES hogares(id_hogar)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Consejos de ahorro iniciales (HU-17)
INSERT INTO recomendaciones (titulo, descripcion, id_categoria) VALUES
('Revisa el sello de la nevera', 'Comprueba que el empaque de la puerta cierre bien y evita abrirla con frecuencia: el compresor trabaja menos y la nevera consume menos energía.', (SELECT id_categoria FROM categorias WHERE nombre = 'Refrigeración')),
('Aleja la nevera de fuentes de calor', 'Ubica la nevera lejos de la estufa, el horno o la luz directa del sol y deja espacio detrás para que circule el aire.', (SELECT id_categoria FROM categorias WHERE nombre = 'Refrigeración')),
('Cambia a iluminación LED', 'Las bombillas LED dan la misma luz que una incandescente usando una fracción de la potencia. Empieza por las que más horas permanecen encendidas.', (SELECT id_categoria FROM categorias WHERE nombre = 'Iluminación')),
('Aprovecha la luz natural', 'Abre cortinas durante el día y apaga las luces de los espacios que no estás usando.', (SELECT id_categoria FROM categorias WHERE nombre = 'Iluminación')),
('Evita el modo de espera', 'Televisores, consolas y equipos de sonido siguen consumiendo en modo de espera. Desconéctalos o usa una regleta con interruptor.', (SELECT id_categoria FROM categorias WHERE nombre = 'Entretenimiento')),
('Lava con carga completa', 'Usa la lavadora con carga completa y en ciclos de agua fría cuando sea posible: se reduce el número de ciclos y la energía para calentar agua.', (SELECT id_categoria FROM categorias WHERE nombre = 'Lavado')),
('Tapa las ollas al cocinar', 'Cocinar con la olla tapada y usar el tamaño de hornilla adecuado reduce el tiempo de uso de la estufa eléctrica.', (SELECT id_categoria FROM categorias WHERE nombre = 'Cocina')),
('Ajusta la temperatura del aire acondicionado', 'Programa el aire acondicionado en una temperatura moderada y mantén puertas y ventanas cerradas mientras funciona.', (SELECT id_categoria FROM categorias WHERE nombre = 'Climatización')),
('Desconecta los cargadores', 'Los cargadores conectados sin dispositivo siguen consumiendo energía. Desconéctalos cuando no estén en uso.', NULL),
('Revisa tu consumo cada mes', 'Compara tu consumo mensual en EcoEnergy con tu factura para detectar cambios y confirmar el efecto de tus acciones de ahorro.', NULL);

-- Después de migrar, convierte tu cuenta en administrador desde backend/:
--   npm run crear-admin -- tu_correo@ejemplo.com
