-- =========================================================
-- RUTA: database/ecoenergy.sql
-- Proyecto: EcoEnergy - Sprint 2
-- Descripción: Script completo de creación de base de datos.
-- Si ya tienes la base de datos del Sprint 1 con datos que
-- quieres conservar, usa database/migracion_sprint2.sql.
-- =========================================================

DROP DATABASE IF EXISTS ecoenergy;
CREATE DATABASE ecoenergy
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ecoenergy;

-- ---------------------------------------------------------
-- TABLA: usuarios
-- Relación: 1 usuario -> N hogares
-- Sprint 2: rol (HU-15/16/17) y tarifa personal (HU-06).
-- Si tarifa_kwh_personal es NULL se usa la tarifa de referencia.
-- ---------------------------------------------------------
CREATE TABLE usuarios (
    id_usuario          INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo     VARCHAR(150) NOT NULL,
    correo              VARCHAR(150) NOT NULL UNIQUE,
    password_hash       VARCHAR(255) NOT NULL,
    rol                 ENUM('usuario', 'administrador') NOT NULL DEFAULT 'usuario',
    tarifa_kwh_personal DECIMAL(10,2) NULL,
    fecha_creacion      DATETIME DEFAULT CURRENT_TIMESTAMP,
    activo              TINYINT(1) DEFAULT 1,
    CONSTRAINT chk_tarifa_personal_positiva CHECK (tarifa_kwh_personal IS NULL OR tarifa_kwh_personal > 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: categorias
-- Catálogo básico de categorías de electrodomésticos
-- Relación: 1 categoria -> N electrodomesticos
-- ---------------------------------------------------------
CREATE TABLE categorias (
    id_categoria    INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: hogares
-- Relación: N hogares -> 1 usuario
-- Relación: 1 hogar -> N electrodomesticos
-- ---------------------------------------------------------
CREATE TABLE hogares (
    id_hogar        INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario      INT NOT NULL,
    nombre_hogar    VARCHAR(100) NOT NULL,
    fecha_creacion  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_hogar_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: electrodomesticos
-- Relación: N electrodomesticos -> 1 hogar
-- Relación: N electrodomesticos -> 1 categoria
-- ---------------------------------------------------------
CREATE TABLE electrodomesticos (
    id_electrodomestico INT AUTO_INCREMENT PRIMARY KEY,
    id_hogar             INT NOT NULL,
    id_categoria         INT NOT NULL,
    nombre                VARCHAR(100) NOT NULL,
    potencia_watts        DECIMAL(10,2) NOT NULL,
    cantidad              INT NOT NULL DEFAULT 1,
    horas_uso_diario      DECIMAL(5,2) NOT NULL,
    dias_uso_semana       TINYINT NOT NULL,
    fecha_creacion        DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_electro_hogar
        FOREIGN KEY (id_hogar) REFERENCES hogares(id_hogar)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_electro_categoria
        FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT chk_potencia_positiva CHECK (potencia_watts > 0),
    CONSTRAINT chk_cantidad_positiva CHECK (cantidad > 0),
    CONSTRAINT chk_horas_validas CHECK (horas_uso_diario > 0 AND horas_uso_diario <= 24),
    CONSTRAINT chk_dias_validos CHECK (dias_uso_semana BETWEEN 1 AND 7)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: tarifas  (HU-15)
-- Tarifa de referencia del kWh que administra el administrador.
-- Solo una fila tiene activa = 1; las anteriores quedan como
-- historial de cambios.
-- ---------------------------------------------------------
CREATE TABLE tarifas (
    id_tarifa           INT AUTO_INCREMENT PRIMARY KEY,
    valor_kwh_cop       DECIMAL(10,2) NOT NULL,
    activa              TINYINT(1) NOT NULL DEFAULT 1,
    id_usuario_admin    INT NULL,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_tarifa_no_negativa CHECK (valor_kwh_cop >= 0),
    CONSTRAINT fk_tarifa_admin
        FOREIGN KEY (id_usuario_admin) REFERENCES usuarios(id_usuario)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: recomendaciones  (HU-17)
-- Consejos de ahorro que gestiona el administrador. Los usan
-- las recomendaciones inteligentes (HU-12) y el asistente (HU-11).
-- id_categoria NULL = consejo general para cualquier hogar.
-- ---------------------------------------------------------
CREATE TABLE recomendaciones (
    id_recomendacion    INT AUTO_INCREMENT PRIMARY KEY,
    titulo              VARCHAR(120) NOT NULL UNIQUE,
    descripcion         VARCHAR(1000) NOT NULL,
    id_categoria        INT NULL,
    activa              TINYINT(1) NOT NULL DEFAULT 1,
    id_usuario_admin    INT NULL,
    fecha_creacion      DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_recomendacion_categoria
        FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_recomendacion_admin
        FOREIGN KEY (id_usuario_admin) REFERENCES usuarios(id_usuario)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: reportes_generados  (HU-10 y HU-16)
-- Historial de reportes PDF. Guarda un resumen del momento en
-- que se generó para poder consultarlo después.
-- ---------------------------------------------------------
CREATE TABLE reportes_generados (
    id_reporte          INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario          INT NOT NULL,
    id_hogar            INT NULL,
    nombre_hogar        VARCHAR(100) NOT NULL,
    consumo_mensual_kwh DECIMAL(12,3) NOT NULL,
    costo_mensual_cop   DECIMAL(14,2) NOT NULL,
    tarifa_kwh_cop      DECIMAL(10,2) NOT NULL,
    fecha_generacion    DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reporte_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_reporte_hogar
        FOREIGN KEY (id_hogar) REFERENCES hogares(id_hogar)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: consultas_ia  (HU-11)
-- Historial de preguntas al asistente, por usuario y hogar.
-- ---------------------------------------------------------
CREATE TABLE consultas_ia (
    id_consulta     INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario      INT NOT NULL,
    id_hogar        INT NOT NULL,
    pregunta        VARCHAR(500) NOT NULL,
    respuesta       TEXT NOT NULL,
    modo            VARCHAR(20) NOT NULL,
    fecha_consulta  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_consulta_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_consulta_hogar
        FOREIGN KEY (id_hogar) REFERENCES hogares(id_hogar)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =========================================================
-- DATOS INICIALES
-- =========================================================

-- Categorías básicas
INSERT INTO categorias (nombre) VALUES
('Refrigeración'),
('Iluminación'),
('Entretenimiento'),
('Cocina'),
('Lavado'),
('Climatización'),
('Otros');

-- Tarifa de referencia inicial (COP por kWh, valor de ejemplo)
INSERT INTO tarifas (valor_kwh_cop, activa) VALUES (850.00, 1);

-- Consejos de ahorro iniciales (HU-17). El administrador puede
-- crear, editar o eliminar estos registros desde la aplicación.
INSERT INTO recomendaciones (titulo, descripcion, id_categoria) VALUES
('Revisa el sello de la nevera', 'Comprueba que el empaque de la puerta cierre bien y evita abrirla con frecuencia: el compresor trabaja menos y la nevera consume menos energía.', (SELECT id_categoria FROM categorias WHERE nombre = 'Refrigeración')),
('Aleja la nevera de fuentes de calor', 'Ubica la nevera lejos de la estufa, el horno o la luz directa del sol y deja espacio detrás para que circule el aire.', (SELECT id_categoria FROM categorias WHERE nombre = 'Refrigeración')),
('Cambia a iluminación LED', 'Las bombillas LED dan la misma luz que una incandescente usando una fracción de la potencia. Empieza por las que más horas permanecen encendidas.', (SELECT id_categoria FROM categorias WHERE nombre = 'Iluminación')),
('Aprovecha la luz natural', 'Abre cortinas durante el día y apaga las luces de los espacios que no estás usando.', (SELECT id_categoria FROM categorias WHERE nombre = 'Iluminación')),
('Evita el modo de espera', 'Televisores, consolas y equipos de sonido siguen consumiendo en modo de espera. Desconéctalos o usa una regleta con interruptor.', (SELECT id_categoria FROM categorias WHERE nombre = 'Entretenimiento')),
('Lava con carga completa', 'Usa la lavadora con carga completa y en ciclos de agua fría cuando sea posible: se reduce el número de ciclos y la energía para calentar agua.', (SELECT id_categoria FROM categorias WHERE nombre = 'Lavado')),
('Tapa las ollas al cocinar', 'Cocinar con la olla tapada y usar el tamaño de hornilla adecuado reduce el tiempo de uso de la estufa eléctrica.', (SELECT id_categoria FROM categorias WHERE nombre = 'Cocina')),
('Ajusta la temperatura del aire acondicionado', 'Programa el aire acondicionado en una temperatura moderada y mantén puertas y ventanas cerradas mientras funciona.', (SELECT id_categoria FROM categorias WHERE nombre = 'Climatización')),
('Desconecta los cargadores', 'Los cargadores conectados sin dispositivo siguen consumiendo energía. Desconéctalos cuando no estén en uso.', NULL),
('Revisa tu consumo cada mes', 'Compara tu consumo mensual en EcoEnergy con tu factura para detectar cambios y confirmar el efecto de tus acciones de ahorro.', NULL);

-- =========================================================
-- ADMINISTRADOR
-- Por seguridad no se crea un administrador con contraseña fija.
-- Regístrate en la aplicación y luego, desde backend/, ejecuta:
--   npm run crear-admin -- tu_correo@ejemplo.com
-- =========================================================
