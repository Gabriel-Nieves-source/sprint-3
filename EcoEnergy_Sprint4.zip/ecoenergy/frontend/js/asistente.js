// Asistente EcoEnergy IA (HU-11).
// La IA recibe los datos calculados por EcoEnergy; el frontend solo envia
// la pregunta y el hogar. El historial se guarda en el backend.

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('asistente');

  const campo = document.getElementById('pregunta');
  document.getElementById('form-ia').addEventListener('submit', preguntarIA);
  document.getElementById('btn-borrar-historial').addEventListener('click', borrarHistorial);
  campo.addEventListener('input', actualizarContador);
  document.querySelectorAll('.chip-ia').forEach((boton) => {
    boton.addEventListener('click', () => {
      campo.value = boton.dataset.pregunta;
      actualizarContador();
      campo.focus();
    });
  });

  // Pregunta sugerida desde otra pagina (por ejemplo, Recomendaciones).
  const sugerida = new URLSearchParams(window.location.search).get('pregunta');
  if (sugerida) {
    campo.value = sugerida.slice(0, 500);
    actualizarContador();
  }

  try {
    const hogar = await prepararSelectorHogar(() => {
      document.getElementById('respuesta-ia').style.display = 'none';
      cargarResumenIA();
      cargarHistorial();
    });
    if (!hogar) {
      document.getElementById('sin-hogar-aviso').style.display = 'block';
      document.getElementById('contenido-ia').style.display = 'none';
      return;
    }
    document.getElementById('sin-hogar-aviso').style.display = 'none';
    document.getElementById('contenido-ia').style.display = 'block';
    await Promise.all([cargarResumenIA(), cargarHistorial()]);
  } catch (error) {
    mostrarMensaje('mensaje-ia', error.message);
  }
});

function actualizarContador() {
  document.getElementById('contador-pregunta').textContent = document.getElementById('pregunta').value.length;
}

async function cargarResumenIA() {
  try {
    const datos = await apiFetch(`/consumo/hogar/${obtenerHogarSeleccionado()}`);
    const resumen = datos.resumen_hogar;
    document.getElementById('ia-consumo-mensual').textContent = formatoKwh(resumen.consumo_mensual_kwh);
    document.getElementById('ia-costo-mensual').textContent = formatoCOP(resumen.costo_mensual_cop);
    document.getElementById('ia-mayor-consumidor').textContent = datos.mayor_consumidor
      ? `${datos.mayor_consumidor.nombre} (${formatoNumero(datos.mayor_consumidor.porcentaje_participacion, 1)} %)`
      : 'Sin datos';
  } catch (error) {
    mostrarMensaje('mensaje-ia', error.message);
  }
}

async function cargarHistorial() {
  try {
    const historial = await apiFetch(`/ia/historial/${obtenerHogarSeleccionado()}`);
    const contenedor = document.getElementById('historial-ia');
    if (!historial.length) {
      contenedor.innerHTML = '<p class="texto-secundario">Aún no has hecho preguntas en este hogar.</p>';
      return;
    }
    contenedor.innerHTML = historial.map((h) => `
      <div class="turno-ia">
        <p class="turno-pregunta"><strong>Tú:</strong> ${escaparHtml(h.pregunta)}</p>
        <p class="turno-respuesta">${escaparHtml(h.respuesta)}</p>
        <p class="texto-secundario texto-pequeno">${formatoFecha(h.fecha_consulta)} · ${h.modo === 'ia' ? 'IA conectada' : 'Modo respaldo'}</p>
      </div>
    `).join('');
  } catch (error) {
    console.error(error);
  }
}

async function borrarHistorial() {
  if (!confirm('¿Borrar el historial del asistente para este hogar?')) return;
  try {
    await apiFetch(`/ia/historial/${obtenerHogarSeleccionado()}`, { method: 'DELETE' });
    await cargarHistorial();
  } catch (error) {
    mostrarMensaje('mensaje-ia', error.message);
  }
}

async function preguntarIA(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-ia');

  const idHogar = obtenerHogarSeleccionado();
  const pregunta = document.getElementById('pregunta').value.trim();
  const boton = document.getElementById('btn-preguntar');

  if (!idHogar) {
    mostrarMensaje('mensaje-ia', 'Selecciona un hogar antes de preguntar.');
    return;
  }
  if (!pregunta) {
    mostrarMensaje('mensaje-ia', 'Escribe una pregunta.');
    return;
  }

  boton.disabled = true;
  boton.textContent = 'Analizando...';

  try {
    const resultado = await apiFetch('/ia/preguntar', {
      method: 'POST',
      body: JSON.stringify({ id_hogar: Number(idHogar), pregunta })
    });

    document.getElementById('respuesta-ia').style.display = 'block';
    document.getElementById('texto-respuesta-ia').textContent = resultado.respuesta;
    document.getElementById('modo-ia').textContent = resultado.modo === 'ia' ? 'IA conectada' : 'Modo respaldo';

    const aviso = document.getElementById('aviso-ia');
    aviso.textContent = resultado.aviso || '';
    aviso.style.display = resultado.aviso ? 'block' : 'none';

    document.getElementById('pregunta').value = '';
    actualizarContador();
    await cargarHistorial();
    document.getElementById('respuesta-ia').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    mostrarMensaje('mensaje-ia', error.message);
  } finally {
    boton.disabled = false;
    boton.textContent = 'Preguntar a EcoEnergy IA';
  }
}
