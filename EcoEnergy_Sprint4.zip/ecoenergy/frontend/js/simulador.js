// Simulador de ahorro energetico (HU-08).
// Envia al backend solo los valores que el usuario cambio; el backend
// recalcula con el motor de EcoEnergy sin guardar nada.

let equiposSimulador = [];

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('simulador');

  document.getElementById('form-simulador').addEventListener('submit', simular);
  document.getElementById('btn-restablecer').addEventListener('click', restablecer);

  try {
    const hogar = await prepararSelectorHogar(cargarEquipos);
    if (!hogar) {
      document.getElementById('sin-hogar-aviso').style.display = 'block';
      return;
    }
    document.getElementById('contenido-simulador').style.display = 'block';
    await cargarEquipos();
  } catch (error) {
    mostrarMensaje('mensaje-simulador', error.message);
  }
});

async function cargarEquipos() {
  ocultarMensaje('mensaje-simulador');
  document.getElementById('resultado-simulacion').style.display = 'none';
  const datos = await apiFetch(`/consumo/hogar/${obtenerHogarSeleccionado()}`);
  equiposSimulador = datos.detalle_por_electrodomestico;

  const hayEquipos = equiposSimulador.length > 0;
  document.getElementById('sin-equipos-aviso').style.display = hayEquipos ? 'none' : 'block';
  document.getElementById('tarjeta-escenario').style.display = hayEquipos ? 'block' : 'none';

  const cuerpo = document.getElementById('tabla-simulador');
  cuerpo.innerHTML = equiposSimulador.map((e) => `
    <tr>
      <td><strong>${escaparHtml(e.nombre)}</strong><br><span class="texto-secundario">${escaparHtml(e.categoria)}</span></td>
      <td>${formatoNumero(e.horas_uso_diario, 1)} h</td>
      <td><input type="number" class="input-tabla" data-id="${e.id_electrodomestico}" data-campo="horas_uso_diario"
                 min="0" max="24" step="0.5" value="${e.horas_uso_diario}" aria-label="Horas simuladas de ${escaparHtml(e.nombre)}"></td>
      <td>${formatoNumero(e.potencia_watts, 0)}</td>
      <td><input type="number" class="input-tabla" data-id="${e.id_electrodomestico}" data-campo="potencia_watts"
                 min="1" step="1" value="${e.potencia_watts}" aria-label="Potencia simulada de ${escaparHtml(e.nombre)}"></td>
      <td>${formatoKwh(e.consumo_mensual_kwh)}</td>
    </tr>
  `).join('');
}

function restablecer() {
  cargarEquipos().catch((error) => mostrarMensaje('mensaje-simulador', error.message));
}

function leerCambios() {
  const cambios = new Map();
  for (const input of document.querySelectorAll('#tabla-simulador input')) {
    const id = Number(input.dataset.id);
    const campo = input.dataset.campo;
    const equipo = equiposSimulador.find((e) => e.id_electrodomestico === id);
    const texto = input.value.trim();
    const valor = Number(texto);

    if (campo === 'horas_uso_diario' && (texto === '' || !Number.isFinite(valor) || valor < 0 || valor > 24)) {
      throw new Error(`Las horas simuladas de ${equipo.nombre} deben estar entre 0 y 24.`);
    }
    if (campo === 'potencia_watts' && (texto === '' || !Number.isFinite(valor) || valor <= 0)) {
      throw new Error(`La potencia simulada de ${equipo.nombre} debe ser mayor que 0 W.`);
    }
    if (valor !== equipo[campo]) {
      const cambio = cambios.get(id) || { id_electrodomestico: id };
      cambio[campo] = valor;
      cambios.set(id, cambio);
    }
  }
  return [...cambios.values()];
}

async function simular(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-simulador');

  let cambios;
  try {
    cambios = leerCambios();
  } catch (error) {
    mostrarMensaje('mensaje-simulador', error.message);
    return;
  }
  if (!cambios.length) {
    mostrarMensaje('mensaje-simulador', 'Cambia las horas o la potencia de al menos un electrodoméstico para simular.');
    return;
  }

  const boton = document.getElementById('btn-simular');
  boton.disabled = true;
  try {
    const r = await apiFetch(`/simulador/hogar/${obtenerHogarSeleccionado()}`, {
      method: 'POST',
      body: JSON.stringify({ cambios })
    });
    pintarResultado(r);
  } catch (error) {
    mostrarMensaje('mensaje-simulador', error.message);
  } finally {
    boton.disabled = false;
  }
}

function pintarResultado(r) {
  const insignia = document.getElementById('insignia-resultado');
  const texto = document.getElementById('texto-resultado');
  insignia.className = 'insignia-ia';

  if (r.resultado === 'ahorro') {
    insignia.textContent = 'Ahorro';
    texto.innerHTML = `Con este escenario ahorrarías <strong>${formatoKwh(r.ahorro.consumo_mensual_kwh)}</strong> y
      <strong>${formatoCOP(r.ahorro.costo_mensual_cop)} al mes</strong> (${formatoCOP(r.ahorro.costo_anual_cop)} al año),
      un ${formatoNumero(r.porcentaje_ahorro, 1)} % menos que tu consumo actual.`;
  } else if (r.resultado === 'aumento') {
    insignia.textContent = 'Aumento';
    insignia.classList.add('insignia-alerta');
    texto.innerHTML = `Este escenario <strong>aumenta</strong> tu consumo en ${formatoKwh(-r.ahorro.consumo_mensual_kwh)} al mes,
      con un costo adicional de <strong>${formatoCOP(-r.ahorro.costo_mensual_cop)} mensuales</strong>.`;
  } else {
    insignia.textContent = 'Sin cambio';
    texto.textContent = 'El escenario simulado tiene el mismo consumo que el actual.';
  }

  const filas = [
    ['Diario (promedio)', 'consumo_diario_kwh', 'costo_diario_cop'],
    ['Mensual', 'consumo_mensual_kwh', 'costo_mensual_cop'],
    ['Anual', 'consumo_anual_kwh', 'costo_anual_cop']
  ];
  document.getElementById('tabla-resultado').innerHTML = filas.map(([nombre, kwh, cop]) => `
    <tr>
      <td><strong>${nombre}</strong></td>
      <td>${formatoKwh(r.actual[kwh])}</td>
      <td>${formatoKwh(r.simulado[kwh])}</td>
      <td>${formatoKwh(r.ahorro[kwh])}</td>
      <td>${formatoCOP(r.ahorro[cop])}</td>
    </tr>
  `).join('');

  document.getElementById('tabla-detalle-simulacion').innerHTML = r.detalle.filter((d) => d.modificado).map((d) => {
    const cambios = [];
    if (d.actual.horas_uso_diario !== d.simulado.horas_uso_diario) {
      cambios.push(`${formatoNumero(d.actual.horas_uso_diario, 1)} h → ${formatoNumero(d.simulado.horas_uso_diario, 1)} h`);
    }
    if (d.actual.potencia_watts !== d.simulado.potencia_watts) {
      cambios.push(`${formatoNumero(d.actual.potencia_watts)} W → ${formatoNumero(d.simulado.potencia_watts)} W`);
    }
    return `
      <tr>
        <td>${escaparHtml(d.nombre)}</td>
        <td>${cambios.join('<br>')}</td>
        <td>${formatoKwh(d.actual.consumo_mensual_kwh)}</td>
        <td>${formatoKwh(d.simulado.consumo_mensual_kwh)}</td>
        <td>${formatoCOP(d.ahorro_mensual_cop)}</td>
      </tr>`;
  }).join('');

  const tarjeta = document.getElementById('resultado-simulacion');
  tarjeta.style.display = 'block';
  tarjeta.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
