// Recomendaciones inteligentes (HU-12).

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('recomendaciones');

  try {
    const hogar = await prepararSelectorHogar(cargarRecomendaciones);
    if (!hogar) {
      document.getElementById('sin-hogar-aviso').style.display = 'block';
      return;
    }
    document.getElementById('contenido-recomendaciones').style.display = 'block';
    await cargarRecomendaciones();
  } catch (error) {
    mostrarMensaje('mensaje-recomendaciones', error.message);
  }
});

const ETIQUETAS_PRIORIDAD = { alta: 'Prioridad alta', media: 'Prioridad media', informativa: 'Revisión' };

async function cargarRecomendaciones() {
  ocultarMensaje('mensaje-recomendaciones');
  try {
    const r = await apiFetch(`/recomendaciones/hogar/${obtenerHogarSeleccionado()}`);
    pintarConsejos(r.consejos);

    if (!r.hay_datos) {
      document.getElementById('bloque-analisis').style.display = 'none';
      document.getElementById('sin-datos').style.display = 'block';
      document.getElementById('texto-sin-datos').textContent = r.mensaje;
      return;
    }
    document.getElementById('sin-datos').style.display = 'none';
    document.getElementById('bloque-analisis').style.display = 'block';

    document.getElementById('r-consumo').textContent = formatoKwh(r.analisis.consumo_mensual_kwh);
    document.getElementById('r-costo').textContent = formatoCOP(r.analisis.costo_mensual_cop);
    document.getElementById('r-ahorro').textContent = formatoCOP(r.ahorro_potencial.mensual_cop);

    const hallazgos = [
      `<strong>${escaparHtml(r.analisis.mayor_consumidor)}</strong> es tu mayor consumidor: ${formatoNumero(r.analisis.porcentaje_mayor_consumidor, 1)} % del consumo mensual.`
    ];
    if (r.analisis.equipos_uso_prolongado.length) {
      hallazgos.push(`Equipos con uso prolongado (6 horas o más al día): ${r.analisis.equipos_uso_prolongado.map(escaparHtml).join(', ')}.`);
    }
    if (r.ahorro_potencial.mensual_cop > 0) {
      hallazgos.push(`Aplicando todas las acciones con ahorro podrías reducir tu consumo cerca de un ${formatoNumero(r.ahorro_potencial.porcentaje, 1)} %:
        ${formatoKwh(r.ahorro_potencial.mensual_kwh)} y ${formatoCOP(r.ahorro_potencial.anual_cop)} al año.`);
    } else {
      hallazgos.push('Tus equipos ya tienen tiempos de uso moderados; revisa los consejos generales.');
    }
    document.getElementById('lista-hallazgos').innerHTML = hallazgos.map((h) => `<li>${h}</li>`).join('');

    document.getElementById('lista-acciones').innerHTML = r.acciones.length
      ? r.acciones.map(tarjetaAccion).join('')
      : '<p class="texto-secundario">No encontramos acciones de ahorro adicionales para este hogar.</p>';
  } catch (error) {
    mostrarMensaje('mensaje-recomendaciones', error.message);
  }
}

function tarjetaAccion(a) {
  const pregunta = encodeURIComponent(`¿Cómo puedo ahorrar energía con ${a.electrodomestico}?`);
  return `
    <article class="accion accion-${a.prioridad}">
      <div class="accion-encabezado">
        <h3>${escaparHtml(a.titulo)}</h3>
        <span class="insignia-ia insignia-${a.prioridad}">${ETIQUETAS_PRIORIDAD[a.prioridad]}</span>
      </div>
      <p>${escaparHtml(a.accion)}</p>
      ${a.ahorro_mensual_cop > 0
        ? `<p class="texto-ahorro">Ahorro estimado: ${formatoKwh(a.ahorro_mensual_kwh)} y ${formatoCOP(a.ahorro_mensual_cop)} al mes (${formatoCOP(a.ahorro_anual_cop)} al año).</p>`
        : ''}
      ${a.supuesto ? `<p class="texto-secundario texto-pequeno">${escaparHtml(a.supuesto)}</p>` : ''}
      <div class="botones-fila">
        <a class="btn btn-pequeno" href="simulador.html">Probar en el simulador</a>
        <a class="btn btn-secundario btn-pequeno" href="asistente.html?pregunta=${pregunta}">Preguntar al asistente</a>
      </div>
    </article>`;
}

function pintarConsejos(consejos) {
  const lista = document.getElementById('lista-consejos');
  lista.innerHTML = consejos.length
    ? consejos.map((c) => `
        <li>
          <strong>${escaparHtml(c.titulo)}</strong>
          <span class="etiqueta-categoria">${escaparHtml(c.categoria || 'General')}</span>
          <p>${escaparHtml(c.descripcion)}</p>
        </li>`).join('')
    : '<li>No hay consejos disponibles por ahora.</li>';
}
