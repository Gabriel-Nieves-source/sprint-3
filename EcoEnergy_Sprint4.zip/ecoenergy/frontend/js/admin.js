// Panel de administracion: HU-16 (estadisticas), HU-15 (tarifa) y HU-17 (recomendaciones).
// El backend valida el rol en cada peticion; esta pagina solo se muestra a administradores.

let graficoCategorias = null;
let recomendacionesCache = [];

document.addEventListener('DOMContentLoaded', async () => {
  protegerPaginaAdmin();
  if (!esAdministrador()) return;
  renderizarBarraSuperior('admin');

  document.querySelectorAll('.pestana').forEach((boton) => {
    boton.addEventListener('click', () => mostrarPestana(boton.dataset.pestana));
  });
  document.getElementById('btn-actualizar-estadisticas').addEventListener('click', cargarEstadisticas);
  document.getElementById('form-tarifa-admin').addEventListener('submit', actualizarTarifa);
  document.getElementById('form-recomendacion').addEventListener('submit', guardarRecomendacion);
  document.getElementById('btn-cancelar-rec').addEventListener('click', limpiarFormulario);

  await Promise.all([cargarEstadisticas(), cargarTarifa(), cargarCategorias(), cargarRecomendaciones()]);
});

function mostrarPestana(nombre) {
  document.querySelectorAll('.pestana').forEach((b) => b.classList.toggle('activa', b.dataset.pestana === nombre));
  document.querySelectorAll('.panel-pestana').forEach((p) => {
    p.style.display = p.id === `panel-${nombre}` ? 'block' : 'none';
  });
}

// Si el backend responde 403 (por ejemplo, se le quito el rol), se avisa.
function manejarError(idMensaje, error) {
  mostrarMensaje(idMensaje, error.message);
}

// ---------- HU-16 ----------
async function cargarEstadisticas() {
  try {
    const e = await apiFetch('/admin/estadisticas');
    document.getElementById('e-usuarios').textContent = formatoNumero(e.usuarios_registrados);
    document.getElementById('e-hogares').textContent = formatoNumero(e.hogares_creados);
    document.getElementById('e-equipos').textContent = formatoNumero(e.electrodomesticos_registrados);
    document.getElementById('e-promedio').textContent = formatoKwh(e.consumo_promedio_mensual_hogar_kwh);
    document.getElementById('e-reportes').textContent = formatoNumero(e.reportes_generados);

    document.getElementById('e-detalle').innerHTML = [
      `Usuarios activos: <strong>${formatoNumero(e.usuarios_activos)}</strong> (administradores: ${formatoNumero(e.administradores)})`,
      `Hogares con electrodomésticos: <strong>${formatoNumero(e.hogares_con_electrodomesticos)}</strong> de ${formatoNumero(e.hogares_creados)}`,
      `Consumo mensual total de la plataforma: <strong>${formatoKwh(e.consumo_total_mensual_kwh)}</strong>`,
      `Consumo promedio mensual por electrodoméstico: <strong>${formatoKwh(e.consumo_promedio_mensual_electrodomestico_kwh)}</strong>`,
      `Reportes generados en los últimos 30 días: <strong>${formatoNumero(e.reportes_ultimos_30_dias)}</strong>`,
      `Consultas al asistente IA: <strong>${formatoNumero(e.consultas_asistente_ia)}</strong>`,
      `Tarifa de referencia vigente: <strong>${formatoCOP(e.tarifa_referencia_cop)}</strong> por kWh`,
      `<span class="texto-secundario">El consumo promedio por hogar considera los hogares que tienen al menos un electrodoméstico. Actualizado: ${formatoFecha(e.generado_en)}</span>`
    ].map((t) => `<li>${t}</li>`).join('');

    pintarGraficoCategorias(e.consumo_por_categoria);
  } catch (error) {
    manejarError('mensaje-admin', error);
  }
}

function pintarGraficoCategorias(datos) {
  const contexto = document.getElementById('grafico-categorias').getContext('2d');
  if (graficoCategorias) graficoCategorias.destroy();
  if (!datos.length || typeof Chart === 'undefined') return;
  graficoCategorias = new Chart(contexto, {
    type: 'bar',
    data: {
      labels: datos.map((d) => d.categoria),
      datasets: [{ label: 'kWh/mes', data: datos.map((d) => d.consumo_mensual_kwh), backgroundColor: '#0288d1' }]
    },
    options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true } } }
  });
}

// ---------- HU-15 ----------
async function cargarTarifa() {
  try {
    const t = await apiFetch('/admin/tarifa');
    document.getElementById('t-actual').textContent = `${formatoCOP(t.tarifa_referencia_cop)} por kWh`;
    document.getElementById('t-info').textContent = `Es el valor predeterminado para calcular los costos. ${t.usuarios_con_tarifa_personal === 1 ? '1 usuario usa' : `${t.usuarios_con_tarifa_personal} usuarios usan`} su propia tarifa y no se ve afectado por este cambio.`;
    document.getElementById('t-historial').innerHTML = t.historial.map((h) => `
      <tr>
        <td>${formatoCOP(h.valor_kwh_cop)}</td>
        <td>${formatoFecha(h.fecha_actualizacion)}</td>
        <td>${escaparHtml(h.actualizado_por || 'Valor inicial')}</td>
        <td>${h.activa ? '<span class="insignia-ia">Vigente</span>' : 'Anterior'}</td>
      </tr>`).join('');
  } catch (error) {
    manejarError('mensaje-tarifa-admin', error);
  }
}

async function actualizarTarifa(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-tarifa-admin');
  ocultarMensaje('mensaje-exito-tarifa-admin');
  const campo = document.getElementById('nueva_tarifa');
  const valor = Number(campo.value);
  if (!campo.value || !Number.isFinite(valor) || valor <= 0) {
    mostrarMensaje('mensaje-tarifa-admin', 'Escribe un valor del kWh mayor que 0.');
    return;
  }
  if (!confirm(`¿Cambiar la tarifa de referencia a ${formatoCOP(valor)} por kWh?`)) return;
  try {
    const r = await apiFetch('/admin/tarifa', { method: 'PUT', body: JSON.stringify({ valor_kwh_cop: valor }) });
    campo.value = '';
    mostrarMensaje('mensaje-exito-tarifa-admin', r.mensaje, 'exito');
    await Promise.all([cargarTarifa(), cargarEstadisticas()]);
  } catch (error) {
    manejarError('mensaje-tarifa-admin', error);
  }
}

// ---------- HU-17 ----------
async function cargarCategorias() {
  try {
    const categorias = await apiFetch('/electrodomesticos/categorias');
    document.getElementById('rec_categoria').innerHTML = '<option value="">General (todos los hogares)</option>' +
      categorias.map((c) => `<option value="${c.id_categoria}">${escaparHtml(c.nombre)}</option>`).join('');
  } catch (error) {
    manejarError('mensaje-rec', error);
  }
}

async function cargarRecomendaciones() {
  try {
    recomendacionesCache = await apiFetch('/admin/recomendaciones');
    const cuerpo = document.getElementById('tabla-recomendaciones');
    if (!recomendacionesCache.length) {
      cuerpo.innerHTML = '<tr><td colspan="5">No hay recomendaciones registradas.</td></tr>';
      return;
    }
    cuerpo.innerHTML = '';
    recomendacionesCache.forEach((r) => {
      const fila = document.createElement('tr');
      fila.innerHTML = `
        <td><strong>${escaparHtml(r.titulo)}</strong></td>
        <td>${escaparHtml(r.categoria || 'General')}</td>
        <td class="celda-texto">${escaparHtml(r.descripcion)}</td>
        <td>${r.activa ? '<span class="insignia-ia">Activa</span>' : '<span class="insignia-ia insignia-inactiva">Inactiva</span>'}</td>
        <td class="acciones-tabla">
          <button class="btn btn-pequeno" data-accion="editar">Editar</button>
          <button class="btn btn-peligro btn-pequeno" data-accion="eliminar">Eliminar</button>
        </td>`;
      fila.querySelector('[data-accion="editar"]').addEventListener('click', () => editarRecomendacion(r));
      fila.querySelector('[data-accion="eliminar"]').addEventListener('click', () => eliminarRecomendacion(r));
      cuerpo.appendChild(fila);
    });
  } catch (error) {
    manejarError('mensaje-rec', error);
  }
}

function editarRecomendacion(r) {
  document.getElementById('id_recomendacion').value = r.id_recomendacion;
  document.getElementById('rec_titulo').value = r.titulo;
  document.getElementById('rec_descripcion').value = r.descripcion;
  document.getElementById('rec_categoria').value = r.id_categoria || '';
  document.getElementById('rec_activa').checked = r.activa;
  document.getElementById('titulo-form-rec').textContent = 'Editar recomendación';
  document.getElementById('btn-guardar-rec').textContent = 'Guardar cambios';
  document.getElementById('btn-cancelar-rec').style.display = 'inline-block';
  document.getElementById('form-recomendacion').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function limpiarFormulario() {
  document.getElementById('form-recomendacion').reset();
  document.getElementById('id_recomendacion').value = '';
  document.getElementById('rec_activa').checked = true;
  document.getElementById('titulo-form-rec').textContent = 'Nueva recomendación';
  document.getElementById('btn-guardar-rec').textContent = 'Crear recomendación';
  document.getElementById('btn-cancelar-rec').style.display = 'none';
}

async function guardarRecomendacion(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-rec');
  ocultarMensaje('mensaje-exito-rec');

  const id = document.getElementById('id_recomendacion').value;
  const datos = {
    titulo: document.getElementById('rec_titulo').value.trim(),
    descripcion: document.getElementById('rec_descripcion').value.trim(),
    id_categoria: document.getElementById('rec_categoria').value || null,
    activa: document.getElementById('rec_activa').checked
  };
  if (datos.titulo.length < 3 || datos.descripcion.length < 10) {
    mostrarMensaje('mensaje-rec', 'El título debe tener al menos 3 caracteres y la descripción al menos 10.');
    return;
  }

  try {
    const r = await apiFetch(id ? `/admin/recomendaciones/${id}` : '/admin/recomendaciones', {
      method: id ? 'PUT' : 'POST',
      body: JSON.stringify(datos)
    });
    mostrarMensaje('mensaje-exito-rec', r.mensaje, 'exito');
    limpiarFormulario();
    await cargarRecomendaciones();
  } catch (error) {
    manejarError('mensaje-rec', error);
  }
}

async function eliminarRecomendacion(r) {
  if (!confirm(`¿Eliminar la recomendación "${r.titulo}"? Dejará de usarse en el sistema y en el asistente.`)) return;
  ocultarMensaje('mensaje-rec');
  try {
    const respuesta = await apiFetch(`/admin/recomendaciones/${r.id_recomendacion}`, { method: 'DELETE' });
    mostrarMensaje('mensaje-exito-rec', respuesta.mensaje, 'exito');
    if (document.getElementById('id_recomendacion').value === String(r.id_recomendacion)) limpiarFormulario();
    await cargarRecomendaciones();
  } catch (error) {
    manejarError('mensaje-rec', error);
  }
}
