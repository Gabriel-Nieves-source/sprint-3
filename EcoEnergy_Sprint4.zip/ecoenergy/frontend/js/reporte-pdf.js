// Generacion del reporte PDF (HU-10).
// 1. Pide al backend los datos del reporte (y queda registrado en el historial).
// 2. Dibuja los graficos con Chart.js en un canvas fuera de pantalla.
// 3. Arma el PDF con pdf-lib y lo descarga.
// Incluye: datos del usuario y hogar, consumo y costo (diario, mensual, anual),
// estadisticas por electrodomestico, graficos y recomendaciones.

const PDF_VERDE = [0.18, 0.49, 0.2];
const PDF_AZUL = [0.01, 0.53, 0.82];
const PDF_GRIS = [0.35, 0.35, 0.35];
const COLORES_GRAFICO = ['#2e7d32', '#0288d1', '#66bb6a', '#4fc3f7', '#1b5e20', '#01579b', '#81c784', '#29b6f6'];

// Las fuentes estandar del PDF usan la codificacion WinAnsi: se reemplazan los
// caracteres que no existen en ella para que nunca falle la generacion.
const EXTRA_WINANSI = '€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ';
function textoPdf(texto) {
  return String(texto === undefined || texto === null ? '' : texto)
    .replace(/[  ]/g, ' ')
    .replace(/\s+/g, ' ')
    .split('')
    .map((c) => (c.charCodeAt(0) < 256 || EXTRA_WINANSI.includes(c) ? c : '?'))
    .join('');
}

function pdfCOP(valor) {
  return '$ ' + Math.round(valor || 0).toLocaleString('es-CO');
}

function pdfKwh(valor) {
  return Number(valor || 0).toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' kWh';
}

async function graficoComoPng(config, ancho, alto) {
  const canvas = document.createElement('canvas');
  canvas.width = ancho;
  canvas.height = alto;
  const grafico = new Chart(canvas.getContext('2d'), {
    ...config,
    options: { ...config.options, responsive: false, animation: false, devicePixelRatio: 1 }
  });
  const url = canvas.toDataURL('image/png');
  grafico.destroy();
  return url;
}

async function generarYDescargarReportePDF(idHogar) {
  if (!idHogar) throw new Error('Selecciona un hogar para generar el reporte.');
  if (typeof PDFLib === 'undefined' || typeof Chart === 'undefined') {
    throw new Error('No se pudieron cargar las librerías del reporte (carpeta frontend/vendor). Recarga la página con Ctrl + F5.');
  }

  const datos = await apiFetch(`/reportes/hogar/${idHogar}`, { method: 'POST' });
  const bytes = await construirPdf(datos);
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const fecha = new Date(datos.fecha_generacion).toISOString().slice(0, 10);
  const nombre = `EcoEnergy_reporte_${datos.consumo.nombre_hogar.replace(/[^A-Za-z0-9]+/g, '_')}_${fecha}.pdf`;

  const enlace = document.createElement('a');
  enlace.href = URL.createObjectURL(blob);
  enlace.download = nombre;
  document.body.appendChild(enlace);
  enlace.click();
  enlace.remove();
  setTimeout(() => URL.revokeObjectURL(enlace.href), 5000);
  return { nombre, bytes };
}

async function construirPdf(datos) {
  const { PDFDocument, StandardFonts, rgb } = PDFLib;
  const doc = await PDFDocument.create();
  doc.setTitle(textoPdf(`Reporte EcoEnergy - ${datos.consumo.nombre_hogar}`));
  doc.setAuthor('EcoEnergy');
  const fuente = await doc.embedFont(StandardFonts.Helvetica);
  const negrita = await doc.embedFont(StandardFonts.HelveticaBold);

  const ANCHO = 595.28;
  const ALTO = 841.89;
  const MARGEN = 48;
  const UTIL = ANCHO - MARGEN * 2;
  let pagina;
  let y;

  const color = (c) => rgb(c[0], c[1], c[2]);
  function nuevaPagina() {
    pagina = doc.addPage([ANCHO, ALTO]);
    y = ALTO - MARGEN;
  }
  function espacio(necesario) {
    if (y - necesario < MARGEN + 20) nuevaPagina();
  }
  function lineasDe(texto, tam, font, ancho) {
    const palabras = textoPdf(texto).split(' ');
    const lineas = [];
    let actual = '';
    palabras.forEach((p) => {
      const prueba = actual ? `${actual} ${p}` : p;
      if (font.widthOfTextAtSize(prueba, tam) > ancho && actual) {
        lineas.push(actual);
        actual = p;
      } else {
        actual = prueba;
      }
    });
    if (actual) lineas.push(actual);
    return lineas;
  }
  function parrafo(texto, { tam = 10, font = fuente, c = [0.15, 0.15, 0.15], x = MARGEN, ancho = UTIL, despues = 6 } = {}) {
    const lineas = lineasDe(texto, tam, font, ancho);
    lineas.forEach((l) => {
      espacio(tam + 4);
      pagina.drawText(l, { x, y: y - tam, size: tam, font, color: color(c) });
      y -= tam + 4;
    });
    y -= despues;
  }
  // espacioSiguiente: alto del contenido que va despues, para que el titulo
  // no quede solo al final de una pagina.
  function titulo(texto, espacioSiguiente = 40) {
    espacio(32 + espacioSiguiente);
    y -= 8;
    pagina.drawText(textoPdf(texto), { x: MARGEN, y: y - 14, size: 14, font: negrita, color: color(PDF_VERDE) });
    y -= 24;
  }
  function tabla(encabezados, filas, anchos) {
    const alto = 18;
    const fila = (valores, esEncabezado) => {
      const lineasPorCelda = valores.map((v, i) => lineasDe(v, 9, esEncabezado ? negrita : fuente, anchos[i] - 8));
      const h = Math.max(alto, Math.max(...lineasPorCelda.map((l) => l.length)) * 11 + 7);
      espacio(h);
      if (esEncabezado) {
        pagina.drawRectangle({ x: MARGEN, y: y - h, width: UTIL, height: h, color: rgb(0.91, 0.96, 0.91) });
      }
      let x = MARGEN;
      lineasPorCelda.forEach((lineas, i) => {
        lineas.forEach((l, j) => {
          pagina.drawText(l, { x: x + 4, y: y - 12 - j * 11, size: 9, font: esEncabezado ? negrita : fuente, color: color(esEncabezado ? PDF_VERDE : [0.15, 0.15, 0.15]) });
        });
        x += anchos[i];
      });
      pagina.drawLine({ start: { x: MARGEN, y: y - h }, end: { x: MARGEN + UTIL, y: y - h }, thickness: 0.5, color: rgb(0.85, 0.85, 0.85) });
      y -= h;
    };
    fila(encabezados, true);
    filas.forEach((f) => fila(f, false));
    y -= 10;
  }

  const c = datos.consumo;
  const r = c.resumen_hogar;
  const rec = datos.recomendaciones;
  const fechaTexto = new Date(datos.fecha_generacion).toLocaleString('es-CO', { dateStyle: 'long', timeStyle: 'short' });

  // ---------- Encabezado ----------
  nuevaPagina();
  pagina.drawRectangle({ x: 0, y: ALTO - 96, width: ANCHO, height: 96, color: color(PDF_VERDE) });
  pagina.drawText('EcoEnergy', { x: MARGEN, y: ALTO - 46, size: 24, font: negrita, color: rgb(1, 1, 1) });
  pagina.drawText(textoPdf('Reporte de consumo energético'), { x: MARGEN, y: ALTO - 72, size: 13, font: fuente, color: rgb(1, 1, 1) });
  y = ALTO - 120;
  parrafo(`Usuario: ${datos.usuario.nombre_completo} (${datos.usuario.correo})`, { despues: 0 });
  parrafo(`Hogar: ${c.nombre_hogar}`, { despues: 0 });
  parrafo(`Fecha de generación: ${fechaTexto}`, { despues: 0 });
  parrafo(`Tarifa usada: ${pdfCOP(c.tarifa_kwh_cop)} por kWh (${c.tarifa_origen === 'personal' ? 'tarifa personal del usuario' : 'tarifa de referencia de EcoEnergy'})`, { despues: 4 });

  // ---------- Consumo y costos ----------
  titulo('1. Consumo y costo estimado');
  if (!c.detalle_por_electrodomestico.length) {
    parrafo('Este hogar todavía no tiene electrodomésticos registrados, por lo que no hay consumo para reportar.');
  } else {
    tabla(
      ['Periodo', 'Consumo', 'Costo estimado'],
      [
        ['Diario (promedio)', pdfKwh(r.consumo_diario_kwh), pdfCOP(r.costo_diario_cop)],
        ['Mensual', pdfKwh(r.consumo_mensual_kwh), pdfCOP(r.costo_mensual_cop)],
        ['Anual', pdfKwh(r.consumo_anual_kwh), pdfCOP(r.costo_anual_cop)]
      ],
      [UTIL * 0.4, UTIL * 0.3, UTIL * 0.3]
    );
    parrafo('Cálculo de EcoEnergy: consumo (kWh) = potencia (W) × cantidad × horas de uso / 1000, con los días de uso por semana registrados.', { tam: 8, c: PDF_GRIS });
  }

  // ---------- Estadisticas ----------
  if (c.detalle_por_electrodomestico.length) {
    titulo('2. Estadísticas por electrodoméstico');
    const mayor = c.mayor_consumidor;
    parrafo(`Electrodomésticos registrados: ${r.cantidad_electrodomesticos}. Mayor consumidor: ${mayor.nombre}, con el ${String(mayor.porcentaje_participacion).replace('.', ',')} % del consumo mensual.`);
    const ordenados = [...c.detalle_por_electrodomestico].sort((a, b) => b.consumo_mensual_kwh - a.consumo_mensual_kwh);
    tabla(
      ['Electrodoméstico', 'Uso', 'Diario', 'Mensual', 'Costo mensual', '% del total'],
      ordenados.map((e) => [
        `${e.nombre} (${e.categoria})`,
        `${e.cantidad} × ${e.potencia_watts} W, ${String(e.horas_uso_diario).replace('.', ',')} h, ${e.dias_uso_semana} d/sem`,
        pdfKwh(e.consumo_diario_kwh),
        pdfKwh(e.consumo_mensual_kwh),
        pdfCOP(e.costo_mensual_cop),
        `${String(e.porcentaje_participacion).replace('.', ',')} %`
      ]),
      [UTIL * 0.22, UTIL * 0.24, UTIL * 0.13, UTIL * 0.14, UTIL * 0.15, UTIL * 0.12]
    );

    // ---------- Graficos ----------
    titulo('3. Gráficos', UTIL / 2 + 14);
    const barras = await graficoComoPng({
      type: 'bar',
      data: { labels: ordenados.map((e) => e.nombre), datasets: [{ data: ordenados.map((e) => e.consumo_mensual_kwh), backgroundColor: '#2e7d32' }] },
      options: { plugins: { legend: { display: false }, title: { display: true, text: 'Consumo mensual por electrodoméstico (kWh)', font: { size: 22 } } }, scales: { x: { ticks: { font: { size: 18 } } }, y: { beginAtZero: true, ticks: { font: { size: 18 } } } } }
    }, 1000, 500);
    const torta = await graficoComoPng({
      type: 'pie',
      data: { labels: ordenados.map((e) => e.nombre), datasets: [{ data: ordenados.map((e) => e.consumo_mensual_kwh), backgroundColor: ordenados.map((_, i) => COLORES_GRAFICO[i % COLORES_GRAFICO.length]) }] },
      options: { plugins: { legend: { position: 'right', labels: { font: { size: 20 } } }, title: { display: true, text: 'Distribución del consumo mensual', font: { size: 22 } } } }
    }, 1000, 500);
    for (const imagen of [barras, torta]) {
      const png = await doc.embedPng(imagen);
      const alto = UTIL / 2;
      espacio(alto + 10);
      pagina.drawImage(png, { x: MARGEN, y: y - alto, width: UTIL, height: alto });
      y -= alto + 14;
    }
  }

  // ---------- Recomendaciones ----------
  titulo(`${c.detalle_por_electrodomestico.length ? '4' : '2'}. Recomendaciones de ahorro`);
  if (!rec.hay_datos) {
    parrafo(rec.mensaje);
  } else if (rec.acciones.length) {
    const conAhorro = rec.acciones.filter((a) => a.ahorro_mensual_cop > 0);
    if (conAhorro.length) {
      parrafo(`Aplicando las acciones con ahorro calculado podrías ahorrar cerca de ${pdfKwh(rec.ahorro_potencial.mensual_kwh)} y ${pdfCOP(rec.ahorro_potencial.mensual_cop)} al mes (${pdfCOP(rec.ahorro_potencial.anual_cop)} al año).`, { font: negrita });
    }
    rec.acciones.forEach((a, i) => {
      espacio(70); // mantiene junta cada recomendacion (titulo, accion y ahorro)
      parrafo(`${i + 1}. ${a.titulo}`, { font: negrita, despues: 0 });
      parrafo(a.accion, { x: MARGEN + 12, ancho: UTIL - 12, despues: 0 });
      if (a.ahorro_mensual_cop > 0) {
        parrafo(`Ahorro estimado: ${pdfKwh(a.ahorro_mensual_kwh)} y ${pdfCOP(a.ahorro_mensual_cop)} al mes.`, { x: MARGEN + 12, ancho: UTIL - 12, c: PDF_AZUL, despues: 0 });
      }
      if (a.supuesto) parrafo(a.supuesto, { x: MARGEN + 12, ancho: UTIL - 12, tam: 8, c: PDF_GRIS, despues: 0 });
      y -= 6;
    });
  } else {
    parrafo('Tus equipos ya tienen tiempos de uso moderados; revisa los consejos generales.');
  }
  if (rec.consejos.length) {
    parrafo('Consejos de EcoEnergy:', { font: negrita, despues: 2 });
    rec.consejos.slice(0, 5).forEach((consejo) => parrafo(`• ${consejo.titulo}: ${consejo.descripcion}`, { x: MARGEN + 6, ancho: UTIL - 6, despues: 2 }));
  }

  // ---------- Pie de pagina ----------
  const paginas = doc.getPages();
  paginas.forEach((p, i) => {
    p.drawText(textoPdf(`EcoEnergy · Reporte generado el ${fechaTexto} · Página ${i + 1} de ${paginas.length}`), {
      x: MARGEN, y: 24, size: 8, font: fuente, color: color(PDF_GRIS)
    });
  });

  return doc.save();
}
