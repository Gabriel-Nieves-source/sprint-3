// Dashboard: consumo diario/mensual/anual (HU-05), costos y tarifa (HU-06),
// mayor consumidor, grafico y reporte PDF (HU-10).

let graficoDashboard = null;

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('dashboard');

  document.getElementById('form-tarifa').addEventListener('submit', actualizarTarifa);
  document.getElementById('btn-tarifa-referencia').addEventListener('click', usarTarifaReferencia);
  document.getElementById('btn-reporte').addEventListener('click', descargarReporte);

  try {
    const hogarActivo = await prepararSelectorHogar(cargarDashboard);
    if (!hogarActivo) {
      mostrarSinHogar();
      return;
    }
    mostrarContenido();
    await Promise.all([cargarDashboard(), cargarTarifa(), cargarHistorialReportes()]);
  } catch (error) {
    console.error(error);
  }
});

function mostrarSinHogar() {
  document.getElementById('sin-hogar-aviso').style.display = 'block';
  document.getElementById('contenido-dashboard').style.display = 'none';
}

function mostrarContenido() {
  document.getElementById('sin-hogar-aviso').style.display = 'none';
  document.getElementById('contenido-dashboard').style.display = 'block';
}

async function cargarDashboard() {
  const id_hogar = obtenerHogarSeleccionado();
  if (!id_hogar) return;

  try {
    const datos = await apiFetch(`/consumo/hogar/${id_hogar}`);
    pintarMetricas(datos);
    pintarMayorConsumidor(datos.mayor_consumidor);
    pintarTablaDetalle(datos.detalle_por_electrodomestico);
    pintarGrafico(datos.detalle_por_electrodomestico);
  } catch (error) {
    console.error(error);
  }
}

function pintarMetricas(datos) {
  const r = datos.resumen_hogar;
  document.getElementById('valor-consumo-diario').textContent = formatoKwh(r.consumo_diario_kwh);
  document.getElementById('valor-consumo-mensual').textContent = formatoKwh(r.consumo_mensual_kwh);
  document.getElementById('valor-consumo-anual').textContent = formatoKwh(r.consumo_anual_kwh);
  document.getElementById('valor-costo-diario').textContent = formatoCOP(r.costo_diario_cop);
  document.getElementById('valor-costo-mensual').textContent = formatoCOP(r.costo_mensual_cop);
  document.getElementById('valor-costo-anual').textContent = formatoCOP(r.costo_anual_cop);
}

function pintarMayorConsumidor(mayor) {
  const texto = document.getElementById('mayor-consumidor-texto');
  if (!mayor) {
    texto.textContent = 'Aún no hay electrodomésticos registrados en este hogar.';
    return;
  }
  texto.innerHTML = `<strong>${escaparHtml(mayor.nombre)}</strong> (${escaparHtml(mayor.categoria)}) consume aproximadamente
    ${formatoKwh(mayor.consumo_mensual_kwh)} al mes (${formatoNumero(mayor.porcentaje_participacion, 1)} % del total),
    con un costo estimado de ${formatoCOP(mayor.costo_mensual_cop)}.`;
}

function pintarTablaDetalle(detalle) {
  const cuerpoTabla = document.getElementById('tabla-dashboard');
  cuerpoTabla.innerHTML = '';

  if (!detalle || detalle.length === 0) {
    cuerpoTabla.innerHTML = '<tr><td colspan="7">No hay electrodomésticos registrados.</td></tr>';
    return;
  }

  detalle.forEach((equipo) => {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${escaparHtml(equipo.nombre)}</td>
      <td>${escaparHtml(equipo.categoria)}</td>
      <td>${formatoKwh(equipo.consumo_diario_kwh)}</td>
      <td>${formatoKwh(equipo.consumo_mensual_kwh)}</td>
      <td>${formatoKwh(equipo.consumo_anual_kwh)}</td>
      <td>${formatoCOP(equipo.costo_mensual_cop)}</td>
      <td>${formatoCOP(equipo.costo_anual_cop)}</td>
    `;
    cuerpoTabla.appendChild(fila);
  });
}

function pintarGrafico(detalle) {
  const contexto = document.getElementById('grafico-dashboard').getContext('2d');
  if (graficoDashboard) graficoDashboard.destroy();
  if (!detalle || detalle.length === 0 || typeof Chart === 'undefined') return;

  graficoDashboard = new Chart(contexto, {
    type: 'bar',
    data: {
      labels: detalle.map((e) => e.nombre),
      datasets: [{ label: 'Consumo mensual (kWh)', data: detalle.map((e) => e.consumo_mensual_kwh), backgroundColor: '#2e7d32' }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// ---------- HU-06: tarifa ----------
async function cargarTarifa() {
  try {
    const t = await apiFetch('/tarifas/mi-tarifa');
    const texto = document.getElementById('tarifa-actual-texto');
    if (t.origen === 'personal') {
      texto.innerHTML = `Tus costos se calculan con <strong>tu tarifa personal: ${formatoCOP(t.tarifa_kwh_cop)} por kWh</strong>.
        La tarifa de referencia de EcoEnergy es ${formatoCOP(t.tarifa_referencia)}.`;
      document.getElementById('btn-tarifa-referencia').style.display = 'inline-block';
    } else {
      texto.innerHTML = `Tus costos se calculan con la <strong>tarifa de referencia: ${formatoCOP(t.tarifa_kwh_cop)} por kWh</strong>.
        Si tu factura tiene otro valor, escríbelo abajo.`;
      document.getElementById('btn-tarifa-referencia').style.display = 'none';
    }
  } catch (error) {
    mostrarMensaje('mensaje-tarifa', error.message);
  }
}

async function actualizarTarifa(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-tarifa');
  ocultarMensaje('mensaje-exito-tarifa');

  const campo = document.getElementById('valor_kwh_cop');
  const valor = Number(campo.value);
  if (!campo.value || !Number.isFinite(valor) || valor <= 0) {
    mostrarMensaje('mensaje-tarifa', 'Escribe un valor del kWh mayor que 0.');
    return;
  }

  try {
    const r = await apiFetch('/tarifas/mi-tarifa', { method: 'PUT', body: JSON.stringify({ valor_kwh_cop: valor }) });
    campo.value = '';
    mostrarMensaje('mensaje-exito-tarifa', r.mensaje, 'exito');
    await Promise.all([cargarTarifa(), cargarDashboard()]);
  } catch (error) {
    mostrarMensaje('mensaje-tarifa', error.message);
  }
}

async function usarTarifaReferencia() {
  ocultarMensaje('mensaje-tarifa');
  try {
    const r = await apiFetch('/tarifas/mi-tarifa', { method: 'DELETE' });
    mostrarMensaje('mensaje-exito-tarifa', r.mensaje, 'exito');
    await Promise.all([cargarTarifa(), cargarDashboard()]);
  } catch (error) {
    mostrarMensaje('mensaje-tarifa', error.message);
  }
}

// ---------- HU-10: reporte PDF ----------
async function descargarReporte() {
  const boton = document.getElementById('btn-reporte');
  ocultarMensaje('mensaje-reporte');
  boton.disabled = true;
  boton.textContent = 'Generando reporte...';
  try {
    await generarYDescargarReportePDF(obtenerHogarSeleccionado());
    await cargarHistorialReportes();
  } catch (error) {
    mostrarMensaje('mensaje-reporte', error.message);
  } finally {
    boton.disabled = false;
    boton.textContent = 'Descargar reporte PDF';
  }
}

async function cargarHistorialReportes() {
  try {
    const reportes = await apiFetch('/reportes');
    const lista = document.getElementById('lista-reportes');
    if (!reportes.length) {
      lista.innerHTML = '<li>Sin reportes aún.</li>';
      return;
    }
    lista.innerHTML = reportes.slice(0, 5).map((r) => `
      <li><strong>${escaparHtml(r.nombre_hogar)}</strong> · ${formatoFecha(r.fecha_generacion)}
        <span class="texto-secundario">— ${formatoKwh(r.consumo_mensual_kwh)}/mes, ${formatoCOP(r.costo_mensual_cop)}</span></li>
    `).join('');
  } catch (error) {
    console.error(error);
  }
}
