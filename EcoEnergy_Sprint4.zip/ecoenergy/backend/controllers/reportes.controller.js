// Reportes de consumo (HU-10).
// El backend entrega los datos del reporte (consumo, costos, estadisticas
// y recomendaciones) y registra la generacion en el historial. El archivo
// PDF lo arma el navegador con esos datos, incluyendo los graficos.

const { pool } = require('../db');
const { obtenerDatosConsumoHogar } = require('./consumo.controller');
const { generarRecomendaciones } = require('../services/recomendaciones.service');

async function generarReporte(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const datos = await obtenerDatosConsumoHogar(req.params.id_hogar, id_usuario);
    const recomendaciones = await generarRecomendaciones(datos);
    const [[usuario]] = await pool.query(
      'SELECT nombre_completo, correo FROM usuarios WHERE id_usuario = ?',
      [id_usuario]
    );

    const [resultado] = await pool.query(
      `INSERT INTO reportes_generados
        (id_usuario, id_hogar, nombre_hogar, consumo_mensual_kwh, costo_mensual_cop, tarifa_kwh_cop)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        id_usuario,
        datos.id_hogar,
        datos.nombre_hogar,
        datos.resumen_hogar.consumo_mensual_kwh,
        datos.resumen_hogar.costo_mensual_cop,
        datos.tarifa_kwh_cop
      ]
    );

    return res.status(201).json({
      id_reporte: resultado.insertId,
      fecha_generacion: new Date().toISOString(),
      usuario: { nombre_completo: usuario.nombre_completo, correo: usuario.correo },
      consumo: datos,
      recomendaciones
    });
  } catch (error) {
    if (error.status === 403) {
      return res.status(403).json({ error: error.message });
    }
    console.error('Error en generarReporte:', error);
    return res.status(500).json({ error: 'Error del servidor al generar el reporte.' });
  }
}

// Historial de reportes del usuario (los mas recientes primero).
async function listarMisReportes(req, res) {
  try {
    const [reportes] = await pool.query(
      `SELECT id_reporte, id_hogar, nombre_hogar, consumo_mensual_kwh, costo_mensual_cop,
              tarifa_kwh_cop, fecha_generacion
       FROM reportes_generados
       WHERE id_usuario = ?
       ORDER BY fecha_generacion DESC, id_reporte DESC
       LIMIT 20`,
      [req.usuario.id_usuario]
    );
    return res.json(reportes.map((r) => ({
      ...r,
      consumo_mensual_kwh: Number(r.consumo_mensual_kwh),
      costo_mensual_cop: Number(r.costo_mensual_cop),
      tarifa_kwh_cop: Number(r.tarifa_kwh_cop)
    })));
  } catch (error) {
    console.error('Error en listarMisReportes:', error);
    return res.status(500).json({ error: 'Error del servidor al listar los reportes.' });
  }
}

module.exports = { generarReporte, listarMisReportes };
