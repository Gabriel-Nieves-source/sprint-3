// Funciones del administrador:
//   HU-15 Administrar la tarifa de referencia del kWh.
//   HU-16 Consultar estadisticas generales de la plataforma.
//   HU-17 Gestionar las recomendaciones que usan el asistente y el sistema.
// Todas las rutas pasan por verificarToken + verificarAdmin.

const { pool } = require('../db');
const { calcularConsumo, redondear } = require('../services/calculo.service');
const { obtenerTarifaReferencia, validarValorTarifa } = require('../services/tarifa.service');

// ------------------------------------------------------------------
// HU-15 Tarifas
// ------------------------------------------------------------------
async function obtenerTarifa(req, res) {
  try {
    const [historial] = await pool.query(
      `SELECT t.id_tarifa, t.valor_kwh_cop, t.activa, t.fecha_actualizacion,
              u.nombre_completo AS actualizado_por
       FROM tarifas t
       LEFT JOIN usuarios u ON u.id_usuario = t.id_usuario_admin
       ORDER BY t.fecha_actualizacion DESC, t.id_tarifa DESC
       LIMIT 10`
    );
    const [[personales]] = await pool.query(
      'SELECT COUNT(*) AS total FROM usuarios WHERE tarifa_kwh_personal IS NOT NULL'
    );
    return res.json({
      tarifa_referencia_cop: await obtenerTarifaReferencia(),
      usuarios_con_tarifa_personal: Number(personales.total),
      historial: historial.map((t) => ({ ...t, valor_kwh_cop: Number(t.valor_kwh_cop), activa: Boolean(t.activa) }))
    });
  } catch (error) {
    console.error('Error en obtenerTarifa:', error);
    return res.status(500).json({ error: 'Error del servidor al consultar la tarifa.' });
  }
}

async function actualizarTarifa(req, res) {
  const { valor_kwh_cop } = req.body || {};
  const errorValidacion = validarValorTarifa(valor_kwh_cop);
  if (errorValidacion) {
    return res.status(400).json({ error: errorValidacion });
  }

  let conexion;
  try {
    conexion = await pool.getConnection();
    await conexion.beginTransaction();
    await conexion.query('UPDATE tarifas SET activa = 0 WHERE activa = 1');
    await conexion.query(
      'INSERT INTO tarifas (valor_kwh_cop, activa, id_usuario_admin) VALUES (?, 1, ?)',
      [Number(valor_kwh_cop), req.usuario.id_usuario]
    );
    await conexion.commit();

    return res.json({
      mensaje: 'Tarifa de referencia actualizada. Se usará en los cálculos de los usuarios que no tienen una tarifa personal.',
      tarifa_referencia_cop: await obtenerTarifaReferencia()
    });
  } catch (error) {
    if (conexion) await conexion.rollback().catch(() => {});
    console.error('Error en actualizarTarifa:', error);
    return res.status(500).json({ error: 'Error del servidor al actualizar la tarifa.' });
  } finally {
    if (conexion) conexion.release();
  }
}

// ------------------------------------------------------------------
// HU-16 Estadisticas generales
// ------------------------------------------------------------------
async function contar(sql, params = []) {
  const [[fila]] = await pool.query(sql, params);
  return Number(fila.total);
}

async function obtenerEstadisticas(req, res) {
  try {
    const [equipos] = await pool.query(
      `SELECT e.id_hogar, e.potencia_watts, e.cantidad, e.horas_uso_diario, e.dias_uso_semana,
              c.nombre AS categoria
       FROM electrodomesticos e
       JOIN categorias c ON c.id_categoria = e.id_categoria`
    );

    // El consumo se calcula con el mismo motor que ve cada usuario.
    const porHogar = new Map();
    const porCategoria = new Map();
    let totalMensual = 0;
    equipos.forEach((e) => {
      const { consumo_mensual_kwh } = calcularConsumo(e);
      totalMensual += consumo_mensual_kwh;
      porHogar.set(e.id_hogar, (porHogar.get(e.id_hogar) || 0) + consumo_mensual_kwh);
      porCategoria.set(e.categoria, (porCategoria.get(e.categoria) || 0) + consumo_mensual_kwh);
    });

    const hogaresConEquipos = porHogar.size;
    const tarifaReferencia = await obtenerTarifaReferencia();

    return res.json({
      usuarios_registrados: await contar('SELECT COUNT(*) AS total FROM usuarios'),
      usuarios_activos: await contar('SELECT COUNT(*) AS total FROM usuarios WHERE activo = 1'),
      administradores: await contar("SELECT COUNT(*) AS total FROM usuarios WHERE rol = 'administrador'"),
      hogares_creados: await contar('SELECT COUNT(*) AS total FROM hogares'),
      hogares_con_electrodomesticos: hogaresConEquipos,
      electrodomesticos_registrados: equipos.length,
      consumo_total_mensual_kwh: redondear(totalMensual),
      consumo_promedio_mensual_hogar_kwh: hogaresConEquipos ? redondear(totalMensual / hogaresConEquipos) : 0,
      consumo_promedio_mensual_electrodomestico_kwh: equipos.length ? redondear(totalMensual / equipos.length) : 0,
      reportes_generados: await contar('SELECT COUNT(*) AS total FROM reportes_generados'),
      reportes_ultimos_30_dias: await contar('SELECT COUNT(*) AS total FROM reportes_generados WHERE fecha_generacion >= DATE_SUB(NOW(), INTERVAL 30 DAY)'),
      consultas_asistente_ia: await contar('SELECT COUNT(*) AS total FROM consultas_ia'),
      tarifa_referencia_cop: tarifaReferencia,
      consumo_por_categoria: [...porCategoria.entries()]
        .map(([categoria, kwh]) => ({ categoria, consumo_mensual_kwh: redondear(kwh) }))
        .sort((a, b) => b.consumo_mensual_kwh - a.consumo_mensual_kwh),
      generado_en: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error en obtenerEstadisticas:', error);
    return res.status(500).json({ error: 'Error del servidor al calcular las estadísticas.' });
  }
}

// ------------------------------------------------------------------
// HU-17 Recomendaciones
// ------------------------------------------------------------------
async function validarRecomendacion(datos) {
  const titulo = typeof datos.titulo === 'string' ? datos.titulo.trim() : '';
  const descripcion = typeof datos.descripcion === 'string' ? datos.descripcion.trim() : '';

  if (titulo.length < 3) return { error: 'El título debe tener al menos 3 caracteres.' };
  if (titulo.length > 120) return { error: 'El título no puede superar 120 caracteres.' };
  if (descripcion.length < 10) return { error: 'La descripción debe tener al menos 10 caracteres.' };
  if (descripcion.length > 1000) return { error: 'La descripción no puede superar 1000 caracteres.' };

  let id_categoria = null;
  if (datos.id_categoria !== undefined && datos.id_categoria !== null && datos.id_categoria !== '') {
    id_categoria = Number(datos.id_categoria);
    if (!Number.isInteger(id_categoria) || id_categoria <= 0) return { error: 'La categoría no es válida.' };
    const [filas] = await pool.query('SELECT id_categoria FROM categorias WHERE id_categoria = ?', [id_categoria]);
    if (!filas.length) return { error: 'La categoría no existe.' };
  }

  const activa = datos.activa === undefined ? true : Boolean(datos.activa);
  return { valores: { titulo, descripcion, id_categoria, activa } };
}

function mapearRecomendacion(r) {
  return { ...r, activa: Boolean(r.activa) };
}

async function listarRecomendaciones(req, res) {
  try {
    const [filas] = await pool.query(
      `SELECT r.id_recomendacion, r.titulo, r.descripcion, r.id_categoria, r.activa,
              r.fecha_creacion, r.fecha_actualizacion, c.nombre AS categoria
       FROM recomendaciones r
       LEFT JOIN categorias c ON c.id_categoria = r.id_categoria
       ORDER BY r.fecha_actualizacion DESC, r.id_recomendacion DESC`
    );
    return res.json(filas.map(mapearRecomendacion));
  } catch (error) {
    console.error('Error en listarRecomendaciones:', error);
    return res.status(500).json({ error: 'Error del servidor al listar las recomendaciones.' });
  }
}

async function crearRecomendacion(req, res) {
  try {
    const { error, valores } = await validarRecomendacion(req.body || {});
    if (error) return res.status(400).json({ error });

    const [resultado] = await pool.query(
      `INSERT INTO recomendaciones (titulo, descripcion, id_categoria, activa, id_usuario_admin)
       VALUES (?, ?, ?, ?, ?)`,
      [valores.titulo, valores.descripcion, valores.id_categoria, valores.activa ? 1 : 0, req.usuario.id_usuario]
    );
    return res.status(201).json({ mensaje: 'Recomendación creada correctamente.', id_recomendacion: resultado.insertId });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Ya existe una recomendación con ese título.' });
    }
    console.error('Error en crearRecomendacion:', error);
    return res.status(500).json({ error: 'Error del servidor al crear la recomendación.' });
  }
}

async function editarRecomendacion(req, res) {
  try {
    const id = Number(req.params.id_recomendacion);
    const [existe] = await pool.query('SELECT id_recomendacion FROM recomendaciones WHERE id_recomendacion = ?', [id]);
    if (!existe.length) return res.status(404).json({ error: 'La recomendación no existe.' });

    const { error, valores } = await validarRecomendacion(req.body || {});
    if (error) return res.status(400).json({ error });

    await pool.query(
      `UPDATE recomendaciones
       SET titulo = ?, descripcion = ?, id_categoria = ?, activa = ?, id_usuario_admin = ?
       WHERE id_recomendacion = ?`,
      [valores.titulo, valores.descripcion, valores.id_categoria, valores.activa ? 1 : 0, req.usuario.id_usuario, id]
    );
    return res.json({ mensaje: 'Recomendación actualizada correctamente.' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Ya existe una recomendación con ese título.' });
    }
    console.error('Error en editarRecomendacion:', error);
    return res.status(500).json({ error: 'Error del servidor al editar la recomendación.' });
  }
}

async function eliminarRecomendacion(req, res) {
  try {
    const [resultado] = await pool.query(
      'DELETE FROM recomendaciones WHERE id_recomendacion = ?',
      [Number(req.params.id_recomendacion)]
    );
    if (!resultado.affectedRows) return res.status(404).json({ error: 'La recomendación no existe.' });
    return res.json({ mensaje: 'Recomendación eliminada correctamente.' });
  } catch (error) {
    console.error('Error en eliminarRecomendacion:', error);
    return res.status(500).json({ error: 'Error del servidor al eliminar la recomendación.' });
  }
}

module.exports = {
  obtenerTarifa,
  actualizarTarifa,
  obtenerEstadisticas,
  listarRecomendaciones,
  crearRecomendacion,
  editarRecomendacion,
  eliminarRecomendacion
};
