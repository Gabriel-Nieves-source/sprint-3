// Recomendaciones inteligentes para el usuario (HU-12).

const { obtenerDatosConsumoHogar } = require('./consumo.controller');
const { generarRecomendaciones } = require('../services/recomendaciones.service');

async function obtenerRecomendacionesHogar(req, res) {
  try {
    const datos = await obtenerDatosConsumoHogar(req.params.id_hogar, req.usuario.id_usuario);
    return res.json(await generarRecomendaciones(datos));
  } catch (error) {
    if (error.status === 403) {
      return res.status(403).json({ error: error.message });
    }
    console.error('Error en obtenerRecomendacionesHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al generar las recomendaciones.' });
  }
}

module.exports = { obtenerRecomendacionesHogar };
