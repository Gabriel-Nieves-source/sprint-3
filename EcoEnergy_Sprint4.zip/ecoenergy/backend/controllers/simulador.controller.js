// Simulador de ahorro energetico (HU-08).
// Recalcula el consumo con horas de uso (y, opcionalmente, potencia)
// distintas, usando el mismo motor de EcoEnergy. No escribe nada en la
// base de datos: los datos reales del hogar no cambian.

const { obtenerDatosConsumoHogar } = require('./consumo.controller');
const { calcularConsumo, calcularCosto, redondear } = require('../services/calculo.service');

function validarCambio(cambio, equiposPorId) {
  if (!cambio || typeof cambio !== 'object') return 'Cada cambio debe ser un objeto.';
  const id = Number(cambio.id_electrodomestico);
  if (!equiposPorId.has(id)) {
    return 'Uno de los electrodomesticos no pertenece a este hogar.';
  }
  if (cambio.horas_uso_diario !== undefined) {
    const horas = Number(cambio.horas_uso_diario);
    if (cambio.horas_uso_diario === '' || cambio.horas_uso_diario === null || !Number.isFinite(horas) || horas < 0 || horas > 24) {
      return 'Las horas simuladas deben estar entre 0 y 24.';
    }
  }
  if (cambio.potencia_watts !== undefined) {
    const potencia = Number(cambio.potencia_watts);
    if (cambio.potencia_watts === '' || cambio.potencia_watts === null || !Number.isFinite(potencia) || potencia <= 0 || potencia > 100000) {
      return 'La potencia simulada debe ser mayor que 0 W.';
    }
  }
  return null;
}

function diferencia(actual, simulado, campo) {
  return redondear(actual[campo] - simulado[campo], campo.startsWith('costo') ? 2 : 3);
}

async function simularHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;
    const cambios = req.body && req.body.cambios;

    if (!Array.isArray(cambios) || cambios.length === 0) {
      return res.status(400).json({ error: 'Indica al menos un cambio para simular.' });
    }

    const datos = await obtenerDatosConsumoHogar(id_hogar, id_usuario);
    const tarifa = datos.tarifa_kwh_cop;
    const equiposPorId = new Map(datos.detalle_por_electrodomestico.map((e) => [e.id_electrodomestico, e]));

    const cambiosPorId = new Map();
    for (const cambio of cambios) {
      const error = validarCambio(cambio, equiposPorId);
      if (error) return res.status(400).json({ error });
      cambiosPorId.set(Number(cambio.id_electrodomestico), cambio);
    }

    const totalActual = { consumo_diario_kwh: 0, consumo_mensual_kwh: 0, consumo_anual_kwh: 0 };
    const totalSimulado = { consumo_diario_kwh: 0, consumo_mensual_kwh: 0, consumo_anual_kwh: 0 };

    const detalle = datos.detalle_por_electrodomestico.map((actual) => {
      const cambio = cambiosPorId.get(actual.id_electrodomestico) || {};
      const parametros = {
        potencia_watts: cambio.potencia_watts !== undefined ? Number(cambio.potencia_watts) : actual.potencia_watts,
        cantidad: actual.cantidad,
        horas_uso_diario: cambio.horas_uso_diario !== undefined ? Number(cambio.horas_uso_diario) : actual.horas_uso_diario,
        dias_uso_semana: actual.dias_uso_semana
      };
      const consumoSimulado = calcularConsumo(parametros);
      const simulado = { ...parametros, ...consumoSimulado, ...calcularCosto(consumoSimulado, tarifa) };

      Object.keys(totalActual).forEach((k) => {
        totalActual[k] += actual[k];
        totalSimulado[k] += simulado[k];
      });

      return {
        id_electrodomestico: actual.id_electrodomestico,
        nombre: actual.nombre,
        categoria: actual.categoria,
        modificado: cambiosPorId.has(actual.id_electrodomestico),
        actual: {
          potencia_watts: actual.potencia_watts,
          horas_uso_diario: actual.horas_uso_diario,
          consumo_mensual_kwh: actual.consumo_mensual_kwh,
          costo_mensual_cop: actual.costo_mensual_cop
        },
        simulado: {
          potencia_watts: simulado.potencia_watts,
          horas_uso_diario: simulado.horas_uso_diario,
          consumo_mensual_kwh: simulado.consumo_mensual_kwh,
          costo_mensual_cop: simulado.costo_mensual_cop
        },
        ahorro_mensual_kwh: diferencia(actual, simulado, 'consumo_mensual_kwh'),
        ahorro_mensual_cop: diferencia(actual, simulado, 'costo_mensual_cop')
      };
    });

    const resumen = (total) => {
      const consumo = {
        consumo_diario_kwh: redondear(total.consumo_diario_kwh),
        consumo_mensual_kwh: redondear(total.consumo_mensual_kwh),
        consumo_anual_kwh: redondear(total.consumo_anual_kwh)
      };
      return { ...consumo, ...calcularCosto(consumo, tarifa) };
    };
    const actual = resumen(totalActual);
    const simulado = resumen(totalSimulado);

    const ahorro = {
      consumo_diario_kwh: diferencia(actual, simulado, 'consumo_diario_kwh'),
      consumo_mensual_kwh: diferencia(actual, simulado, 'consumo_mensual_kwh'),
      consumo_anual_kwh: diferencia(actual, simulado, 'consumo_anual_kwh'),
      costo_diario_cop: diferencia(actual, simulado, 'costo_diario_cop'),
      costo_mensual_cop: diferencia(actual, simulado, 'costo_mensual_cop'),
      costo_anual_cop: diferencia(actual, simulado, 'costo_anual_cop')
    };

    let resultado = 'sin_cambio';
    if (ahorro.consumo_mensual_kwh > 0) resultado = 'ahorro';
    if (ahorro.consumo_mensual_kwh < 0) resultado = 'aumento';

    return res.json({
      id_hogar: datos.id_hogar,
      tarifa_kwh_cop: tarifa,
      datos_reales_modificados: false,
      resultado,
      actual,
      simulado,
      ahorro,
      porcentaje_ahorro: actual.consumo_mensual_kwh > 0
        ? redondear((ahorro.consumo_mensual_kwh / actual.consumo_mensual_kwh) * 100, 1)
        : 0,
      detalle
    });
  } catch (error) {
    if (error.status === 403) {
      return res.status(403).json({ error: error.message });
    }
    console.error('Error en simularHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al simular el ahorro.' });
  }
}

module.exports = { simularHogar };
