// Tarifa personal del usuario (HU-06: "Permitir actualizar la tarifa").
// El usuario puede usar el valor del kWh de su propia factura. Si la
// elimina, vuelve a usarse la tarifa de referencia del administrador.

const { pool } = require('../db');
const { obtenerTarifaUsuario, validarValorTarifa } = require('../services/tarifa.service');

async function obtenerMiTarifa(req, res) {
  try {
    return res.json(await obtenerTarifaUsuario(req.usuario.id_usuario));
  } catch (error) {
    console.error('Error en obtenerMiTarifa:', error);
    return res.status(500).json({ error: 'Error del servidor al consultar la tarifa.' });
  }
}

async function actualizarMiTarifa(req, res) {
  try {
    const { valor_kwh_cop } = req.body || {};
    const errorValidacion = validarValorTarifa(valor_kwh_cop);
    if (errorValidacion) {
      return res.status(400).json({ error: errorValidacion });
    }

    await pool.query(
      'UPDATE usuarios SET tarifa_kwh_personal = ? WHERE id_usuario = ?',
      [Number(valor_kwh_cop), req.usuario.id_usuario]
    );

    return res.json({
      mensaje: 'Tarifa actualizada. Los costos se recalcularon con el nuevo valor.',
      ...(await obtenerTarifaUsuario(req.usuario.id_usuario))
    });
  } catch (error) {
    console.error('Error en actualizarMiTarifa:', error);
    return res.status(500).json({ error: 'Error del servidor al actualizar la tarifa.' });
  }
}

async function eliminarMiTarifa(req, res) {
  try {
    await pool.query(
      'UPDATE usuarios SET tarifa_kwh_personal = NULL WHERE id_usuario = ?',
      [req.usuario.id_usuario]
    );
    return res.json({
      mensaje: 'Ahora se usa la tarifa de referencia de EcoEnergy.',
      ...(await obtenerTarifaUsuario(req.usuario.id_usuario))
    });
  } catch (error) {
    console.error('Error en eliminarMiTarifa:', error);
    return res.status(500).json({ error: 'Error del servidor al restablecer la tarifa.' });
  }
}

module.exports = { obtenerMiTarifa, actualizarMiTarifa, eliminarMiTarifa };
