// Endpoints del asistente IA de EcoEnergy (HU-11).
//
// PRINCIPIO DE RESPONSABILIDAD UNICA (SRP): este controlador solo atiende las
// peticiones HTTP (validar, responder, manejar errores). El resto esta en:
//   services/ia/asistente.service.js    -> decide entre IA y respaldo
//   services/ia/clientes/*              -> adaptadores de cada proveedor (Adapter)
//   services/ia/fabricaClienteIA.js     -> crea el adaptador segun el .env
//   services/ia/contexto.service.js     -> instrucciones y datos para la IA
//   services/ia/respaldo.service.js     -> respuestas sin IA
//   services/ia/historial.repository.js -> tabla consultas_ia
// La IA solo interpreta datos calculados por EcoEnergy; nunca calcula.

const { obtenerDatosConsumoHogar } = require('./consumo.controller');
const { verificarPropiedadHogar } = require('./hogares.controller');
const { generarRecomendaciones } = require('../services/recomendaciones.service');
const { AsistenteIA } = require('../services/ia/asistente.service');
const { crearClienteIA } = require('../services/ia/fabricaClienteIA');
const historial = require('../services/ia/historial.repository');

const MAX_PREGUNTA = 500;
const TURNOS_HISTORIAL = 3;

// Inversion de dependencias: el asistente recibe el adaptador ya creado.
// Se crea una vez al iniciar el servidor (cambiar el .env requiere reiniciar).
const asistente = new AsistenteIA({ cliente: crearClienteIA() });

async function preguntarIA(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar, pregunta } = req.body || {};

    const idHogarNumero = Number(id_hogar);
    const preguntaLimpia = typeof pregunta === 'string' ? pregunta.trim() : '';

    if (!Number.isInteger(idHogarNumero) || idHogarNumero <= 0) {
      return res.status(400).json({ error: 'El id_hogar debe ser un numero entero valido.' });
    }
    if (!preguntaLimpia) {
      return res.status(400).json({ error: 'Escribe una pregunta para el asistente IA.' });
    }
    if (preguntaLimpia.length > MAX_PREGUNTA) {
      return res.status(400).json({ error: `La pregunta no puede superar ${MAX_PREGUNTA} caracteres.` });
    }

    const datos = await obtenerDatosConsumoHogar(idHogarNumero, id_usuario);
    const recomendaciones = await generarRecomendaciones(datos);
    const anteriores = await historial.listar(id_usuario, idHogarNumero, TURNOS_HISTORIAL);
    const resultado = await asistente.responder({ datos, recomendaciones, pregunta: preguntaLimpia, historial: anteriores });

    await historial.guardar({
      id_usuario,
      id_hogar: idHogarNumero,
      pregunta: preguntaLimpia,
      respuesta: resultado.respuesta,
      modo: resultado.modo
    });

    return res.json({
      pregunta: preguntaLimpia,
      respuesta: resultado.respuesta,
      modo: resultado.modo,
      modelo: resultado.modelo || null,
      aviso: resultado.aviso || null,
      datos_referencia: {
        consumo_mensual_kwh: datos.resumen_hogar.consumo_mensual_kwh,
        costo_mensual_cop: datos.resumen_hogar.costo_mensual_cop,
        mayor_consumidor: datos.mayor_consumidor ? datos.mayor_consumidor.nombre : null
      }
    });
  } catch (error) {
    if (error.status === 403) {
      return res.status(403).json({ error: error.message });
    }
    console.error('Error en preguntarIA:', error);
    return res.status(500).json({ error: 'No fue posible procesar la consulta del asistente IA.' });
  }
}

async function verificarHogar(req, res) {
  const idHogar = Number(req.params.id_hogar);
  if (!Number.isInteger(idHogar) || idHogar <= 0 || !(await verificarPropiedadHogar(idHogar, req.usuario.id_usuario))) {
    res.status(403).json({ error: 'No tienes permiso sobre este hogar.' });
    return null;
  }
  return idHogar;
}

async function listarHistorial(req, res) {
  try {
    const idHogar = await verificarHogar(req, res);
    if (!idHogar) return;
    return res.json(await historial.listar(req.usuario.id_usuario, idHogar, 20));
  } catch (error) {
    console.error('Error en listarHistorial:', error);
    return res.status(500).json({ error: 'Error del servidor al consultar el historial.' });
  }
}

async function borrarHistorial(req, res) {
  try {
    const idHogar = await verificarHogar(req, res);
    if (!idHogar) return;
    await historial.borrar(req.usuario.id_usuario, idHogar);
    return res.json({ mensaje: 'Historial del asistente eliminado.' });
  } catch (error) {
    console.error('Error en borrarHistorial:', error);
    return res.status(500).json({ error: 'Error del servidor al borrar el historial.' });
  }
}

module.exports = { preguntarIA, listarHistorial, borrarHistorial };
