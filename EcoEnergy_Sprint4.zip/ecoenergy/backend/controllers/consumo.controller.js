// Consumo energetico (HU-05) y costo estimado (HU-06) de un hogar.
// Los calculos los hace el motor de EcoEnergy (services/calculo.service.js),
// nunca una IA.

const { pool } = require('../db');
const { verificarPropiedadHogar } = require('./hogares.controller');
const { calcularHogar } = require('../services/calculo.service');
const { obtenerTarifaUsuario } = require('../services/tarifa.service');

async function obtenerEquiposHogar(id_hogar) {
  const [equipos] = await pool.query(
    `SELECT e.id_electrodomestico, e.nombre, e.potencia_watts, e.cantidad,
            e.horas_uso_diario, e.dias_uso_semana, e.id_categoria,
            c.nombre AS categoria
     FROM electrodomesticos e
     JOIN categorias c ON c.id_categoria = e.id_categoria
     WHERE e.id_hogar = ?
     ORDER BY e.fecha_creacion DESC, e.id_electrodomestico DESC`,
    [id_hogar]
  );
  return equipos;
}

// Devuelve el consumo y costo del hogar completo y por electrodomestico.
// Lanza un error con status 403 si el hogar no es del usuario.
async function obtenerDatosConsumoHogar(id_hogar, id_usuario) {
  const esPropio = await verificarPropiedadHogar(id_hogar, id_usuario);
  if (!esPropio) {
    const error = new Error('No tienes permiso sobre este hogar.');
    error.status = 403;
    throw error;
  }

  const [[hogar]] = await pool.query('SELECT nombre_hogar FROM hogares WHERE id_hogar = ?', [id_hogar]);
  const equipos = await obtenerEquiposHogar(id_hogar);
  const tarifa = await obtenerTarifaUsuario(id_usuario);
  const calculo = calcularHogar(equipos, tarifa.tarifa_kwh_cop);

  return {
    id_hogar: Number(id_hogar),
    nombre_hogar: hogar ? hogar.nombre_hogar : '',
    tarifa_kwh_cop: tarifa.tarifa_kwh_cop,
    tarifa_origen: tarifa.origen,
    tarifa_referencia_cop: tarifa.tarifa_referencia,
    ...calculo
  };
}

async function obtenerConsumoHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;
    const datos = await obtenerDatosConsumoHogar(id_hogar, id_usuario);
    return res.json(datos);
  } catch (error) {
    if (error.status === 403) {
      return res.status(403).json({ error: error.message });
    }
    console.error('Error en obtenerConsumoHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al calcular el consumo.' });
  }
}

module.exports = { obtenerConsumoHogar, obtenerDatosConsumoHogar, obtenerEquiposHogar };
