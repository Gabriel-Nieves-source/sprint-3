// Middleware de autenticacion: verifica el token JWT enviado
// en el header Authorization: Bearer <token>.
// Protege rutas y asegura que cada usuario solo acceda a sus datos.

const jwt = require('jsonwebtoken');
require('dotenv').config();
const { pool } = require('../db');

function verificarToken(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token no proporcionado.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.usuario = { id_usuario: payload.id_usuario, correo: payload.correo };
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Token invalido o expirado.' });
  }
}

// Solo deja pasar a administradores (HU-15, HU-16, HU-17).
// El rol se consulta en la base de datos en cada peticion, para que un
// cambio de rol tenga efecto inmediato y no dependa del token.
async function verificarAdmin(req, res, next) {
  try {
    const [filas] = await pool.query(
      'SELECT rol, activo FROM usuarios WHERE id_usuario = ?',
      [req.usuario.id_usuario]
    );
    if (!filas.length || !filas[0].activo || filas[0].rol !== 'administrador') {
      return res.status(403).json({ error: 'Esta funcion es solo para administradores.' });
    }
    req.usuario.rol = 'administrador';
    next();
  } catch (error) {
    console.error('Error en verificarAdmin:', error);
    return res.status(500).json({ error: 'Error del servidor al verificar permisos.' });
  }
}

module.exports = { verificarToken, verificarAdmin };
