// PATRON STRATEGY (GoF) - estrategias concretas de recomendacion.
// Para agregar una nueva forma de ahorro se crea otra subclase y se agrega a
// ESTRATEGIAS_PREDETERMINADAS; el motor no cambia (principio abierto/cerrado).

const { EstrategiaRecomendacion, CATEGORIAS_ESENCIALES, HORAS_USO_PROLONGADO } = require('./EstrategiaRecomendacion');

const POTENCIA_LED_W = 9; // bombilla LED tipica que reemplaza una incandescente de 60 W

// Bombillas de alta potencia -> reemplazar por LED.
class ReemplazoLedEstrategia extends EstrategiaRecomendacion {
  constructor() { super('reemplazo_led'); }

  aplica(equipo) {
    return equipo.categoria === 'Iluminación' && equipo.potencia_watts > POTENCIA_LED_W * 2;
  }

  generar(equipo, { tarifa }) {
    return {
      tipo: this.tipo,
      titulo: `Cambia ${equipo.nombre} a LED`,
      accion: `Reemplaza ${equipo.cantidad > 1 ? `las ${equipo.cantidad} bombillas` : 'la bombilla'} de ${equipo.potencia_watts} W por LED de ${POTENCIA_LED_W} W, manteniendo las mismas ${this.formatoHoras(equipo.horas_uso_diario)} horas de uso.`,
      supuesto: `Se asume una bombilla LED de ${POTENCIA_LED_W} W, equivalente habitual a una incandescente de 60 W.`,
      ...this.ahorroPorCambio(equipo, { potencia_watts: POTENCIA_LED_W }, tarifa)
    };
  }
}

// Equipos no esenciales con uso prolongado, o el mayor consumidor -> menos horas.
class ReducirHorasEstrategia extends EstrategiaRecomendacion {
  constructor() { super('reducir_horas'); }

  aplica(equipo, { esMayorConsumidor }) {
    if (CATEGORIAS_ESENCIALES.includes(equipo.categoria)) return false;
    return equipo.horas_uso_diario >= HORAS_USO_PROLONGADO || (esMayorConsumidor && equipo.horas_uso_diario > 1);
  }

  generar(equipo, { tarifa }) {
    const horas = equipo.horas_uso_diario;
    if (horas >= HORAS_USO_PROLONGADO) {
      const reduccion = horas >= 12 ? 2 : 1;
      return {
        tipo: this.tipo,
        titulo: `Reduce el uso de ${equipo.nombre}`,
        accion: `Usa ${equipo.nombre} ${reduccion} ${reduccion === 1 ? 'hora' : 'horas'} menos al día (de ${this.formatoHoras(horas)} a ${this.formatoHoras(horas - reduccion)} horas).`,
        ...this.ahorroPorCambio(equipo, { horas_uso_diario: horas - reduccion }, tarifa)
      };
    }
    return {
      tipo: this.tipo,
      titulo: `Reduce el uso de ${equipo.nombre}`,
      accion: `${equipo.nombre} es tu mayor consumidor. Usarlo 1 hora menos al día (de ${this.formatoHoras(horas)} a ${this.formatoHoras(horas - 1)} horas) tiene el mayor impacto en tu factura.`,
      ...this.ahorroPorCambio(equipo, { horas_uso_diario: horas - 1 }, tarifa)
    };
  }
}

// Lavadoras usadas 4 o mas dias -> agrupar ciclos con carga completa.
class AgruparCiclosEstrategia extends EstrategiaRecomendacion {
  constructor() { super('agrupar_ciclos'); }

  aplica(equipo) {
    return equipo.categoria === 'Lavado' && equipo.dias_uso_semana >= 4;
  }

  generar(equipo, { tarifa }) {
    const dias = equipo.dias_uso_semana - 2;
    return {
      tipo: this.tipo,
      titulo: `Agrupa los ciclos de ${equipo.nombre}`,
      accion: `Acumula ropa y usa ${equipo.nombre} con carga completa ${dias} días por semana en lugar de ${equipo.dias_uso_semana}.`,
      ...this.ahorroPorCambio(equipo, { dias_uso_semana: dias }, tarifa)
    };
  }
}

// Equipos esenciales con gran participacion -> revisar eficiencia (informativa).
class RevisarEficienciaEstrategia extends EstrategiaRecomendacion {
  constructor() { super('eficiencia'); }

  aplica(equipo) {
    return CATEGORIAS_ESENCIALES.includes(equipo.categoria) && equipo.porcentaje_participacion >= 30;
  }

  generar(equipo) {
    return {
      tipo: this.tipo,
      titulo: `Revisa la eficiencia de ${equipo.nombre}`,
      accion: `${equipo.nombre} funciona todo el tiempo y representa el ${String(equipo.porcentaje_participacion).replace('.', ',')} % de tu consumo. Revisa el sello de la puerta y su ubicación; si es un modelo antiguo, usa el simulador con la potencia de un modelo eficiente para comparar.`,
      ahorro_mensual_kwh: 0,
      ahorro_mensual_cop: 0,
      ahorro_anual_cop: 0
    };
  }
}

const ESTRATEGIAS_PREDETERMINADAS = [
  new ReemplazoLedEstrategia(),
  new ReducirHorasEstrategia(),
  new AgruparCiclosEstrategia(),
  new RevisarEficienciaEstrategia()
];

module.exports = {
  EstrategiaRecomendacion,
  ReemplazoLedEstrategia,
  ReducirHorasEstrategia,
  AgruparCiclosEstrategia,
  RevisarEficienciaEstrategia,
  ESTRATEGIAS_PREDETERMINADAS,
  POTENCIA_LED_W
};
