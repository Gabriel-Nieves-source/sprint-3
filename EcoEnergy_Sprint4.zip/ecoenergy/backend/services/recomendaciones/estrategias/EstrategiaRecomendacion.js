// PATRON STRATEGY (GoF) - interfaz comun de las estrategias de recomendacion.
//
// Cada estrategia representa una forma distinta de ahorrar energia
// (cambiar a LED, reducir horas, agrupar lavados, revisar eficiencia).
// El motor de recomendaciones las recorre sin saber cuales son ni como
// calculan su ahorro: solo usa esta interfaz.
//
//   aplica(equipo, contexto)  -> boolean   ¿la estrategia sirve para este equipo?
//   generar(equipo, contexto) -> accion    { tipo, titulo, accion, ahorro_mensual_kwh, ahorro_mensual_cop, ahorro_anual_cop, supuesto? }
//
// contexto: { tarifa, esMayorConsumidor }

const { calcularConsumo, calcularCosto, redondear } = require('../../calculo.service');

class EstrategiaRecomendacion {
  constructor(tipo) {
    if (new.target === EstrategiaRecomendacion) {
      throw new Error('EstrategiaRecomendacion es abstracta: crea una subclase.');
    }
    this.tipo = tipo;
  }

  aplica(/* equipo, contexto */) {
    throw new Error('aplica() debe implementarse en la estrategia.');
  }

  generar(/* equipo, contexto */) {
    throw new Error('generar() debe implementarse en la estrategia.');
  }

  // Utilidades compartidas por todas las estrategias.
  // El ahorro siempre lo calcula el motor matematico de EcoEnergy.
  ahorroPorCambio(equipo, cambios, tarifa) {
    const actual = calcularConsumo(equipo);
    const nuevo = calcularConsumo({ ...equipo, ...cambios });
    const kwh = redondear(actual.consumo_mensual_kwh - nuevo.consumo_mensual_kwh);
    const cop = redondear(calcularCosto({ consumo_diario_kwh: 0, consumo_mensual_kwh: kwh, consumo_anual_kwh: 0 }, tarifa).costo_mensual_cop, 2);
    return { ahorro_mensual_kwh: kwh, ahorro_mensual_cop: cop, ahorro_anual_cop: redondear(cop * 12, 2) };
  }

  formatoHoras(h) {
    return Number.isInteger(h) ? String(h) : String(redondear(h, 1)).replace('.', ',');
  }
}

const CATEGORIAS_ESENCIALES = ['Refrigeración'];
const HORAS_USO_PROLONGADO = 6;

module.exports = { EstrategiaRecomendacion, CATEGORIAS_ESENCIALES, HORAS_USO_PROLONGADO };
