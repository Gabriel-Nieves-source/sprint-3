// Motor de recomendaciones inteligentes (HU-12) - "Contexto" del patron Strategy.
//
// PATRON STRATEGY (GoF): el motor recibe una lista de estrategias y, para cada
// electrodomestico, aplica las que correspondan y se queda con la de mayor ahorro.
// PRINCIPIO ABIERTO/CERRADO (OCP): agregar una estrategia nueva no requiere
// modificar este archivo.
// PRINCIPIO DE INVERSION DE DEPENDENCIAS (DIP): las estrategias y la fuente de
// los consejos del administrador se inyectan por el constructor, por lo que el
// motor se puede probar sin base de datos.

const { redondear } = require('../calculo.service');
const { CATEGORIAS_ESENCIALES, HORAS_USO_PROLONGADO } = require('./estrategias/EstrategiaRecomendacion');

const MAX_ACCIONES = 6;

class MotorRecomendaciones {
  constructor({ estrategias, obtenerConsejos }) {
    if (!Array.isArray(estrategias) || !estrategias.length) {
      throw new Error('El motor necesita al menos una estrategia de recomendación.');
    }
    this.estrategias = estrategias;
    this.obtenerConsejos = obtenerConsejos;
  }

  mejorAccion(equipo, contexto) {
    const candidatas = this.estrategias
      .filter((estrategia) => estrategia.aplica(equipo, contexto))
      .map((estrategia) => estrategia.generar(equipo, contexto));
    if (!candidatas.length) return null;
    return candidatas.reduce((mejor, a) => (a.ahorro_mensual_cop > mejor.ahorro_mensual_cop ? a : mejor));
  }

  // datos: resultado de obtenerDatosConsumoHogar
  async generar(datos) {
    const detalle = datos.detalle_por_electrodomestico || [];
    const tarifa = datos.tarifa_kwh_cop;
    const categorias = [...new Set(detalle.map((e) => e.categoria))];
    const consejos = await this.obtenerConsejos(categorias);

    if (!detalle.length) {
      return {
        id_hogar: datos.id_hogar,
        hay_datos: false,
        mensaje: 'Registra al menos un electrodoméstico para recibir recomendaciones personalizadas.',
        analisis: null,
        acciones: [],
        ahorro_potencial: { mensual_kwh: 0, mensual_cop: 0, anual_cop: 0 },
        consejos
      };
    }

    const mayor = datos.mayor_consumidor;
    const acciones = detalle
      .map((equipo) => {
        const contexto = { tarifa, esMayorConsumidor: Boolean(mayor && equipo.id_electrodomestico === mayor.id_electrodomestico) };
        const accion = this.mejorAccion(equipo, contexto);
        return accion && {
          ...accion,
          id_electrodomestico: equipo.id_electrodomestico,
          electrodomestico: equipo.nombre,
          categoria: equipo.categoria,
          porcentaje_participacion: equipo.porcentaje_participacion
        };
      })
      .filter(Boolean)
      .sort((a, b) => b.ahorro_mensual_cop - a.ahorro_mensual_cop || b.porcentaje_participacion - a.porcentaje_participacion)
      .slice(0, MAX_ACCIONES);

    acciones.forEach((a) => {
      a.prioridad = a.ahorro_mensual_cop >= datos.resumen_hogar.costo_mensual_cop * 0.05 ? 'alta' : a.ahorro_mensual_cop > 0 ? 'media' : 'informativa';
    });

    const conAhorro = acciones.filter((a) => a.ahorro_mensual_kwh > 0);
    const ahorroKwh = redondear(conAhorro.reduce((s, a) => s + a.ahorro_mensual_kwh, 0));
    const ahorroCop = redondear(conAhorro.reduce((s, a) => s + a.ahorro_mensual_cop, 0), 2);

    return {
      id_hogar: datos.id_hogar,
      hay_datos: true,
      analisis: {
        consumo_mensual_kwh: datos.resumen_hogar.consumo_mensual_kwh,
        costo_mensual_cop: datos.resumen_hogar.costo_mensual_cop,
        mayor_consumidor: mayor ? mayor.nombre : null,
        porcentaje_mayor_consumidor: mayor ? mayor.porcentaje_participacion : 0,
        equipos_uso_prolongado: detalle
          .filter((e) => e.horas_uso_diario >= HORAS_USO_PROLONGADO && !CATEGORIAS_ESENCIALES.includes(e.categoria))
          .map((e) => e.nombre),
        categorias
      },
      acciones,
      ahorro_potencial: {
        mensual_kwh: ahorroKwh,
        mensual_cop: ahorroCop,
        anual_cop: redondear(ahorroCop * 12, 2),
        porcentaje: datos.resumen_hogar.consumo_mensual_kwh > 0
          ? redondear((ahorroKwh / datos.resumen_hogar.consumo_mensual_kwh) * 100, 1)
          : 0
      },
      consejos
    };
  }
}

module.exports = { MotorRecomendaciones, MAX_ACCIONES };
