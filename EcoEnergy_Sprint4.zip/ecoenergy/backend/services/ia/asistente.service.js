// Asistente de IA de EcoEnergy (HU-11).
//
// PRINCIPIO DE INVERSION DE DEPENDENCIAS (DIP): el asistente no conoce
// Gemini, Groq ni OpenAI. Depende de la abstraccion ClienteIA, que recibe
// por el constructor. Por eso se puede cambiar de proveedor desde el .env, o
// probarlo con un cliente falso, sin modificar esta clase.
//
// Si no hay cliente o el proveedor falla, responde con el modo de respaldo.

const { INSTRUCCIONES, construirTurnos } = require('./contexto.service');
const { construirFallback } = require('./respaldo.service');

const AVISOS = {
  cuota: 'Se alcanzó el límite de uso o de créditos de la API de IA; se activó automáticamente el modo de respaldo de EcoEnergy.',
  clave: 'La clave de la API no es válida o ya no está disponible; se activó automáticamente el modo de respaldo de EcoEnergy.',
  api: 'La API de IA no estuvo disponible; se activó automáticamente el modo de respaldo de EcoEnergy.'
};

const MOTIVO_POR_CODIGO = { CUOTA_AGOTADA: 'cuota', CLAVE_INVALIDA: 'clave', API_NO_DISPONIBLE: 'api' };

class AsistenteIA {
  // cliente: un ClienteIA (adaptador) o null si no hay IA configurada.
  // respaldo: funcion que responde sin IA (inyectable para pruebas).
  constructor({ cliente = null, respaldo = construirFallback, registrarError = console.warn } = {}) {
    this.cliente = cliente;
    this.respaldo = respaldo;
    this.registrarError = registrarError;
  }

  async responder({ datos, recomendaciones, pregunta, historial = [] }) {
    if (!this.cliente) {
      return { respuesta: this.respaldo(datos, recomendaciones, pregunta), modo: 'fallback' };
    }
    try {
      const respuesta = await this.cliente.generar({
        instrucciones: INSTRUCCIONES,
        turnos: construirTurnos(datos, recomendaciones, pregunta, historial)
      });
      return { respuesta, modo: 'ia', modelo: this.cliente.descripcion };
    } catch (error) {
      // Errores esperados (limite agotado, clave invalida, tiempo agotado o
      // API no disponible): se cambia al modo de respaldo.
      this.registrarError(`Asistente IA: ${error.message}`);
      const motivo = MOTIVO_POR_CODIGO[error.codigo] || 'api';
      return {
        respuesta: this.respaldo(datos, recomendaciones, pregunta, motivo),
        modo: 'fallback',
        aviso: AVISOS[motivo]
      };
    }
  }
}

module.exports = { AsistenteIA, AVISOS };
