// PATRON ADAPTER (GoF) - adaptador para la API "Responses" de OpenAI.
//   Peticion:  { model, instructions, input: turnos }
//   Respuesta: { output: [{ content: [{ type: 'output_text', text }] }] }
// (output_text en la raiz solo existe en los SDK oficiales, no en la API HTTP.)

const { ClienteIA } = require('./ClienteIA');

class OpenAIResponsesAdapter extends ClienteIA {
  construirCuerpo({ instrucciones, turnos }) {
    return { model: this.modelo, instructions: instrucciones, input: turnos };
  }

  extraerTexto(data) {
    if (data && typeof data.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
    const partes = [];
    ((data && data.output) || []).forEach((item) => {
      (item.content || []).forEach((c) => {
        if ((c.type === 'output_text' || c.type === 'text') && typeof c.text === 'string') partes.push(c.text);
      });
    });
    return partes.join('\n').trim();
  }
}

module.exports = { OpenAIResponsesAdapter };
