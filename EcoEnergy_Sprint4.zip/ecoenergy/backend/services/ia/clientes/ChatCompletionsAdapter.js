// PATRON ADAPTER (GoF) - adaptador para las APIs con formato
// "Chat Completions" (lo usan Google Gemini y Groq).
//   Peticion:  { model, messages: [{ role: 'system' }, ...turnos] }
//   Respuesta: { choices: [{ message: { content } }] }

const { ClienteIA } = require('./ClienteIA');

class ChatCompletionsAdapter extends ClienteIA {
  construirCuerpo({ instrucciones, turnos }) {
    return {
      model: this.modelo,
      messages: [{ role: 'system', content: instrucciones }, ...turnos]
    };
  }

  extraerTexto(data) {
    const contenido = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (typeof contenido === 'string') return contenido.trim();
    if (Array.isArray(contenido)) return contenido.map((c) => c.text || '').join('\n').trim();
    return '';
  }
}

module.exports = { ChatCompletionsAdapter };
