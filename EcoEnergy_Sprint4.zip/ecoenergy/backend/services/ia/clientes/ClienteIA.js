// PATRON ADAPTER (GoF) - "Target": la interfaz que EcoEnergy espera de
// cualquier proveedor de inteligencia artificial.
//
// Cada proveedor (Gemini, Groq, OpenAI) tiene su propia API, con un formato
// de peticion y de respuesta diferente. Los adaptadores convierten esas APIs
// a esta unica interfaz:
//
//   generar({ instrucciones, turnos }) -> Promise<string>
//
// turnos: [{ role: 'user' | 'assistant', content: string }]
// Si el proveedor falla, el adaptador lanza un ErrorProveedorIA con un codigo
// comun (CUOTA_AGOTADA, CLAVE_INVALIDA o API_NO_DISPONIBLE).

const TIEMPO_MAXIMO_MS = 20000;

class ErrorProveedorIA extends Error {
  constructor(codigo, mensaje) {
    super(mensaje || codigo);
    this.name = 'ErrorProveedorIA';
    this.codigo = codigo;
  }
}

class ClienteIA {
  constructor({ nombre, url, modelo, clave, tiempoMaximoMs = TIEMPO_MAXIMO_MS, fetchImpl }) {
    if (new.target === ClienteIA) {
      throw new Error('ClienteIA es una clase abstracta: usa uno de sus adaptadores.');
    }
    this.nombre = nombre;
    this.url = url;
    this.modelo = modelo;
    this.clave = clave;
    this.tiempoMaximoMs = tiempoMaximoMs;
    // La funcion fetch se puede inyectar (util en pruebas unitarias).
    this.fetch = fetchImpl || ((...args) => fetch(...args));
  }

  get descripcion() {
    return `${this.nombre} · ${this.modelo}`;
  }

  // Metodos que cada adaptador debe implementar.
  construirCuerpo(/* { instrucciones, turnos } */) {
    throw new Error('construirCuerpo() debe implementarse en el adaptador.');
  }

  extraerTexto(/* respuestaJson */) {
    throw new Error('extraerTexto() debe implementarse en el adaptador.');
  }

  // Flujo comun a todos los proveedores: enviar, clasificar errores y extraer texto.
  async generar({ instrucciones, turnos }) {
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), this.tiempoMaximoMs);
    try {
      let respuesta;
      try {
        respuesta = await this.fetch(this.url, {
          method: 'POST',
          signal: controlador.signal,
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.clave}` },
          body: JSON.stringify(this.construirCuerpo({ instrucciones, turnos }))
        });
      } catch (error) {
        throw new ErrorProveedorIA('API_NO_DISPONIBLE', `${this.nombre} no respondio: ${error.message}`);
      }

      if (!respuesta.ok) {
        let detalle = '';
        try {
          detalle = await respuesta.text();
        } catch (_) {
          // Sin cuerpo legible: se clasifica solo por el codigo HTTP.
        }
        throw new ErrorProveedorIA(
          ClienteIA.clasificarError(respuesta.status, detalle),
          `${this.nombre} respondio ${respuesta.status}: ${detalle.slice(0, 200)}`
        );
      }

      const texto = this.extraerTexto(await respuesta.json());
      if (!texto) {
        throw new ErrorProveedorIA('API_NO_DISPONIBLE', `${this.nombre} no devolvio texto.`);
      }
      return texto;
    } finally {
      clearTimeout(temporizador);
    }
  }

  static clasificarError(status, detalle = '') {
    if (status === 401 || status === 403 || (status === 400 && /api[ _-]?key/i.test(detalle))) return 'CLAVE_INVALIDA';
    if (status === 429) return 'CUOTA_AGOTADA';
    return 'API_NO_DISPONIBLE';
  }
}

module.exports = { ClienteIA, ErrorProveedorIA };
