// Acceso a la tabla consultas_ia (historial del asistente, HU-11).
// PRINCIPIO DE RESPONSABILIDAD UNICA (SRP): solo se encarga de guardar y
// consultar el historial en MySQL.

const { pool } = require('../../db');

async function listar(id_usuario, id_hogar, limite) {
  const [filas] = await pool.query(
    `SELECT id_consulta, pregunta, respuesta, modo, fecha_consulta
     FROM consultas_ia
     WHERE id_usuario = ? AND id_hogar = ?
     ORDER BY fecha_consulta DESC, id_consulta DESC
     LIMIT ?`,
    [id_usuario, id_hogar, limite]
  );
  return filas;
}

async function guardar({ id_usuario, id_hogar, pregunta, respuesta, modo }) {
  await pool.query(
    'INSERT INTO consultas_ia (id_usuario, id_hogar, pregunta, respuesta, modo) VALUES (?, ?, ?, ?, ?)',
    [id_usuario, id_hogar, pregunta, respuesta, modo]
  );
}

async function borrar(id_usuario, id_hogar) {
  await pool.query('DELETE FROM consultas_ia WHERE id_usuario = ? AND id_hogar = ?', [id_usuario, id_hogar]);
}

module.exports = { listar, guardar, borrar };
