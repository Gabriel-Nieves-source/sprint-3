// Crea el adaptador de IA configurado en el archivo .env.
//   IA_PROVEEDOR=gemini | groq | openai,  IA_API_KEY=...,  IA_MODELO=(opcional)
// Si no hay IA_PROVEEDOR pero existe OPENAI_API_KEY, se usa OpenAI
// (compatibilidad con la configuracion del Sprint 1).
//
// PRINCIPIO ABIERTO/CERRADO (OCP): para agregar un proveedor nuevo basta con
// registrarlo en PROVEEDORES con su adaptador; no se modifica el asistente,
// el controlador ni los adaptadores existentes.

const { ChatCompletionsAdapter } = require('./clientes/ChatCompletionsAdapter');
const { OpenAIResponsesAdapter } = require('./clientes/OpenAIResponsesAdapter');

const PROVEEDORES = {
  gemini: {
    nombre: 'Google Gemini',
    url: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    modelo: 'gemini-3.5-flash-lite',
    Adaptador: ChatCompletionsAdapter
  },
  groq: {
    nombre: 'Groq',
    url: 'https://api.groq.com/openai/v1/chat/completions',
    modelo: 'openai/gpt-oss-120b',
    Adaptador: ChatCompletionsAdapter
  },
  openai: {
    nombre: 'OpenAI',
    url: 'https://api.openai.com/v1/responses',
    modelo: 'gpt-5.6-luna',
    Adaptador: OpenAIResponsesAdapter
  }
};

// Devuelve un ClienteIA o null si no hay proveedor configurado.
function crearClienteIA(env = process.env, opciones = {}) {
  const elegido = (env.IA_PROVEEDOR || '').trim().toLowerCase();
  let clave;
  let modelo;
  let base;

  if (elegido) {
    base = PROVEEDORES[elegido];
    if (!base) {
      console.warn(`IA_PROVEEDOR "${elegido}" no es valido. Opciones: ${Object.keys(PROVEEDORES).join(', ')}.`);
      return null;
    }
    clave = env.IA_API_KEY || (elegido === 'openai' ? env.OPENAI_API_KEY : '');
    modelo = env.IA_MODELO || (elegido === 'openai' && env.OPENAI_MODEL) || base.modelo;
  } else if (env.OPENAI_API_KEY) {
    base = PROVEEDORES.openai;
    clave = env.OPENAI_API_KEY;
    modelo = env.OPENAI_MODEL || base.modelo;
  }

  if (!base || !clave) return null;
  return new base.Adaptador({ nombre: base.nombre, url: base.url, modelo, clave, ...opciones });
}

module.exports = { crearClienteIA, PROVEEDORES };
