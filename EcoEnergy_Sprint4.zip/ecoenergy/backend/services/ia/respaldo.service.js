// Modo de respaldo del asistente (HU-11).
// PRINCIPIO DE RESPONSABILIDAD UNICA (SRP): este modulo solo sabe responder
// sin IA, con los datos ya calculados por EcoEnergy, segun el tipo de pregunta.

// ------------------------------------------------------------------
// Utilidades de texto
// ------------------------------------------------------------------
function normalizar(texto) {
  return texto.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
}

function cop(valor) {
  return `$${Math.round(valor).toLocaleString('es-CO')} COP`;
}

function kwh(valor) {
  return `${Number(valor).toLocaleString('es-CO', { maximumFractionDigits: 2 })} kWh`;
}

function pct(valor) {
  return `${String(valor).replace('.', ',')} %`;
}

// ------------------------------------------------------------------
// Clasificacion de la pregunta (para el modo de respaldo)
// ------------------------------------------------------------------
const PALABRAS_ENERGIA = ['consum', 'energ', 'kwh', 'luz', 'electric', 'electrodomest', 'equipo', 'factura', 'costo', 'cuesta',
  'pago', 'pagar', 'gasto', 'gasta', 'tarifa', 'ahorr', 'reduc', 'bajar', 'disminu', 'recomend', 'consejo', 'nevera', 'televis',
  'lavadora', 'bombill', 'foco', 'aire', 'ventilador', 'hogar', 'casa', 'mes', 'anual', 'diari', 'porcentaje', 'estadistic',
  'simul', 'eficien', 'watts', 'potencia', 'horas', 'mayor', 'grafic', 'reporte'];

function clasificarPregunta(pregunta, datos) {
  const texto = normalizar(pregunta);
  const nombresEquipos = (datos.detalle_por_electrodomestico || []).map((e) => normalizar(e.nombre));
  const tieneEnergia = PALABRAS_ENERGIA.some((p) => texto.includes(p)) || nombresEquipos.some((n) => n && texto.includes(n));
  if (!tieneEnergia) return 'fuera_de_tema';
  if (/simul/.test(texto)) return 'simulador';
  if (/ahorr|reduc|bajar|disminu|recomend|consejo|mejorar|optimiz/.test(texto)) return 'ahorro';
  if (/porcentaje|distribu|estadistic|compar|particip|grafic/.test(texto)) return 'estadisticas';
  if (/mayor|mas consume|consume mas|mas gasta|gasta mas|mas energia/.test(texto)) return 'mayor_consumidor';
  if (/costo|cuesta|pago|pagar|factura|dinero|pesos|cop|tarifa|precio|valor del kwh/.test(texto)) return 'costo';
  if (/diari|al dia|por dia|anual|al ano|por ano|mensual|al mes|por mes/.test(texto)) return 'periodos';
  return 'general';
}

// ------------------------------------------------------------------
// Modo de respaldo: responde segun la pregunta con datos calculados
// ------------------------------------------------------------------
function construirFallback(datos, recomendaciones, pregunta, motivo = 'sin_api_key') {
  const resumen = datos.resumen_hogar;
  const mayor = datos.mayor_consumidor;
  const detalle = [...(datos.detalle_por_electrodomestico || [])]
    .sort((a, b) => b.consumo_mensual_kwh - a.consumo_mensual_kwh);
  const tipo = clasificarPregunta(pregunta, datos);
  const lineas = [];

  if (tipo === 'fuera_de_tema') {
    lineas.push('Solo puedo ayudarte con temas del consumo energético de tu hogar: consumo en kWh, costos, electrodomésticos, ahorro y simulaciones.');
    lineas.push('Prueba con preguntas como "¿Qué electrodoméstico consume más?" o "¿Cómo puedo reducir mi factura?".');
  } else if (!detalle.length) {
    lineas.push('Todavía no hay electrodomésticos registrados en este hogar. Registra al menos uno para que EcoEnergy pueda analizar el consumo y generar recomendaciones.');
  } else if (tipo === 'mayor_consumidor') {
    lineas.push(`Tu mayor consumidor es ${mayor.nombre}: ${kwh(mayor.consumo_mensual_kwh)} al mes (${pct(mayor.porcentaje_participacion)} del total), con un costo estimado de ${cop(mayor.costo_mensual_cop)} mensuales.`);
    lineas.push('', 'Principales consumos del hogar:');
    detalle.slice(0, 3).forEach((e, i) => lineas.push(`${i + 1}. ${e.nombre}: ${kwh(e.consumo_mensual_kwh)}/mes (${pct(e.porcentaje_participacion)})`));
  } else if (tipo === 'costo') {
    lineas.push(`Con una tarifa de ${cop(datos.tarifa_kwh_cop)} por kWh (${datos.tarifa_origen === 'personal' ? 'tu tarifa personal' : 'tarifa de referencia de EcoEnergy'}), el costo estimado de tu hogar es:`);
    lineas.push(`- Diario: ${cop(resumen.costo_diario_cop)}`, `- Mensual: ${cop(resumen.costo_mensual_cop)}`, `- Anual: ${cop(resumen.costo_anual_cop)}`);
    lineas.push('', `${mayor.nombre} aporta ${cop(mayor.costo_mensual_cop)} de ese costo mensual.`);
  } else if (tipo === 'periodos') {
    lineas.push('Consumo calculado por EcoEnergy para tu hogar:');
    lineas.push(`- Diario (promedio): ${kwh(resumen.consumo_diario_kwh)} — ${cop(resumen.costo_diario_cop)}`);
    lineas.push(`- Mensual: ${kwh(resumen.consumo_mensual_kwh)} — ${cop(resumen.costo_mensual_cop)}`);
    lineas.push(`- Anual: ${kwh(resumen.consumo_anual_kwh)} — ${cop(resumen.costo_anual_cop)}`);
  } else if (tipo === 'estadisticas') {
    lineas.push(`Distribución del consumo mensual (${kwh(resumen.consumo_mensual_kwh)} en total):`);
    detalle.forEach((e) => lineas.push(`- ${e.nombre}: ${pct(e.porcentaje_participacion)} (${kwh(e.consumo_mensual_kwh)})`));
  } else if (tipo === 'ahorro' || tipo === 'simulador') {
    const acciones = recomendaciones.acciones.filter((a) => a.ahorro_mensual_cop > 0);
    if (acciones.length) {
      lineas.push('Acciones con mayor ahorro según tus datos:');
      acciones.slice(0, 3).forEach((a, i) => lineas.push(`${i + 1}. ${a.accion} Ahorro estimado: ${kwh(a.ahorro_mensual_kwh)} y ${cop(a.ahorro_mensual_cop)} al mes.`));
      lineas.push('', `Si aplicas todas las acciones sugeridas podrías ahorrar cerca de ${cop(recomendaciones.ahorro_potencial.mensual_cop)} al mes.`);
    } else {
      lineas.push(`Tus equipos ya tienen tiempos de uso moderados. Revisa primero ${mayor.nombre}, que representa el ${pct(mayor.porcentaje_participacion)} del consumo.`);
    }
    if (tipo === 'simulador') {
      lineas.push('', 'En el Simulador puedes cambiar las horas de uso o la potencia de cada equipo y ver el ahorro antes de hacer cambios reales.');
    }
    if (recomendaciones.consejos.length) {
      lineas.push('', `Consejo: ${recomendaciones.consejos[0].titulo}. ${recomendaciones.consejos[0].descripcion}`);
    }
  } else {
    lineas.push(`Tu hogar consume ${kwh(resumen.consumo_mensual_kwh)} al mes, con un costo estimado de ${cop(resumen.costo_mensual_cop)}.`);
    lineas.push(`El equipo que más consume es ${mayor.nombre} (${pct(mayor.porcentaje_participacion)} del total).`);
    const primera = recomendaciones.acciones.find((a) => a.ahorro_mensual_cop > 0);
    if (primera) lineas.push('', `Recomendación principal: ${primera.accion} Ahorro estimado: ${cop(primera.ahorro_mensual_cop)} al mes.`);
  }

  const cierre = {
    cuota: 'Se alcanzó el límite de uso de la API de IA; esta respuesta la generó el análisis de respaldo de EcoEnergy.',
    clave: 'La clave de la API no está disponible o no es válida; esta respuesta la generó el análisis de respaldo de EcoEnergy.',
    sin_api_key: 'Respuesta generada por el análisis de respaldo de EcoEnergy (la API de IA no está configurada).',
    api: 'La API de IA no está disponible en este momento; esta respuesta la generó el análisis de respaldo de EcoEnergy.'
  }[motivo] || '';

  return `${lineas.join('\n')}\n\n${cierre}`.trim();
}

module.exports = { clasificarPregunta, construirFallback };
