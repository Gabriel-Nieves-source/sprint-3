// Recomendaciones inteligentes (HU-12).
// Arma el motor de recomendaciones con sus dependencias reales:
//   - las estrategias de ahorro (patron Strategy)
//   - los consejos activos que gestiona el administrador (HU-17), desde MySQL
// El resto del sistema sigue usando generarRecomendaciones(datos).

const { pool } = require('../db');
const { MotorRecomendaciones } = require('./recomendaciones/MotorRecomendaciones');
const { ESTRATEGIAS_PREDETERMINADAS } = require('./recomendaciones/estrategias');

async function obtenerConsejosAdmin(categorias) {
  const [filas] = await pool.query(
    `SELECT r.id_recomendacion, r.titulo, r.descripcion, c.nombre AS categoria
     FROM recomendaciones r
     LEFT JOIN categorias c ON c.id_categoria = r.id_categoria
     WHERE r.activa = 1
     ORDER BY r.id_categoria IS NULL, r.titulo`
  );
  return filas.filter((f) => f.categoria === null || categorias.includes(f.categoria));
}

const motor = new MotorRecomendaciones({
  estrategias: ESTRATEGIAS_PREDETERMINADAS,
  obtenerConsejos: obtenerConsejosAdmin
});

function generarRecomendaciones(datos) {
  return motor.generar(datos);
}

module.exports = { generarRecomendaciones, obtenerConsejosAdmin };
