// Tarifa del kWh (HU-06 y HU-15).
// - Tarifa de referencia: la administra el administrador (tabla tarifas).
// - Tarifa personal: el usuario puede definir la de su factura.
// La tarifa que se usa en los calculos es la personal si existe;
// si no, la de referencia.

const { pool } = require('../db');

const TARIFA_MAXIMA = 100000; // COP por kWh; limite de seguridad contra errores de digitacion

async function obtenerTarifaReferencia() {
  const [filas] = await pool.query(
    'SELECT valor_kwh_cop FROM tarifas WHERE activa = 1 ORDER BY fecha_actualizacion DESC, id_tarifa DESC LIMIT 1'
  );
  return filas.length ? Number(filas[0].valor_kwh_cop) : 0;
}

async function obtenerTarifaUsuario(id_usuario) {
  const referencia = await obtenerTarifaReferencia();
  const [filas] = await pool.query(
    'SELECT tarifa_kwh_personal FROM usuarios WHERE id_usuario = ?',
    [id_usuario]
  );
  const personal = filas.length && filas[0].tarifa_kwh_personal !== null
    ? Number(filas[0].tarifa_kwh_personal)
    : null;

  return {
    tarifa_kwh_cop: personal !== null ? personal : referencia,
    origen: personal !== null ? 'personal' : 'referencia',
    tarifa_personal: personal,
    tarifa_referencia: referencia
  };
}

// Devuelve un mensaje de error o null si el valor es valido.
function validarValorTarifa(valor) {
  if (valor === undefined || valor === null || valor === '') {
    return 'El valor del kWh es obligatorio.';
  }
  const numero = Number(valor);
  if (typeof valor === 'boolean' || !Number.isFinite(numero)) {
    return 'El valor del kWh debe ser un numero.';
  }
  if (numero <= 0) {
    return 'El valor del kWh debe ser mayor que 0.';
  }
  if (numero > TARIFA_MAXIMA) {
    return `El valor del kWh no puede superar ${TARIFA_MAXIMA.toLocaleString('es-CO')} COP.`;
  }
  return null;
}

module.exports = {
  TARIFA_MAXIMA,
  obtenerTarifaReferencia,
  obtenerTarifaUsuario,
  validarValorTarifa
};
