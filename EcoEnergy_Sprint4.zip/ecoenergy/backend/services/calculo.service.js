// Motor matematico de EcoEnergy (HU-05 y HU-06).
// Es la unica fuente de los calculos de consumo y costo: lo usan el
// dashboard, el simulador, las recomendaciones, los reportes y la IA.
// La IA nunca recalcula estos valores; solo los interpreta.
//
//   consumo_dia_uso_kWh  = (Watts * Cantidad * HorasUsoDiario) / 1000
//   consumo_semanal_kWh  = consumo_dia_uso_kWh * DiasUsoSemana
//   consumo_mensual_kWh  = consumo_semanal_kWh * 4.345   (semanas/mes promedio)
//   consumo_anual_kWh    = consumo_mensual_kWh * 12
//   consumo_diario_kWh   = consumo_anual_kWh / 365       (promedio por dia del año)
//
// El consumo diario se expresa como promedio para que diario, mensual y
// anual sean coherentes entre si aunque un equipo no se use todos los dias.
// El consumo de un dia en que si se usa queda en consumo_dia_uso_kwh.

const SEMANAS_POR_MES = 4.345;
const MESES_POR_ANIO = 12;
const DIAS_POR_ANIO = 365;

function redondear(valor, decimales = 3) {
  return Number(Number(valor).toFixed(decimales));
}

function calcularConsumo(equipo) {
  const potencia = Number(equipo.potencia_watts);
  const cantidad = Number(equipo.cantidad);
  const horas = Number(equipo.horas_uso_diario);
  const dias = Number(equipo.dias_uso_semana);

  const diaUso = (potencia * cantidad * horas) / 1000;
  const semanal = diaUso * dias;
  const mensual = semanal * SEMANAS_POR_MES;
  const anual = mensual * MESES_POR_ANIO;
  const diario = anual / DIAS_POR_ANIO;

  return {
    consumo_dia_uso_kwh: redondear(diaUso),
    consumo_diario_kwh: redondear(diario),
    consumo_semanal_kwh: redondear(semanal),
    consumo_mensual_kwh: redondear(mensual),
    consumo_anual_kwh: redondear(anual)
  };
}

function calcularCosto(consumo, tarifa) {
  return {
    costo_diario_cop: redondear(consumo.consumo_diario_kwh * tarifa, 2),
    costo_mensual_cop: redondear(consumo.consumo_mensual_kwh * tarifa, 2),
    costo_anual_cop: redondear(consumo.consumo_anual_kwh * tarifa, 2)
  };
}

// Calcula el detalle por equipo, el resumen del hogar, el porcentaje de
// participacion de cada equipo y el mayor consumidor.
function calcularHogar(equipos, tarifa) {
  const detalle = equipos.map((equipo) => {
    const consumo = calcularConsumo(equipo);
    return {
      id_electrodomestico: equipo.id_electrodomestico,
      nombre: equipo.nombre,
      categoria: equipo.categoria,
      potencia_watts: Number(equipo.potencia_watts),
      cantidad: Number(equipo.cantidad),
      horas_uso_diario: Number(equipo.horas_uso_diario),
      dias_uso_semana: Number(equipo.dias_uso_semana),
      ...consumo,
      ...calcularCosto(consumo, tarifa)
    };
  });

  const total = (campo) => detalle.reduce((suma, e) => suma + e[campo], 0);
  const resumenConsumo = {
    consumo_diario_kwh: redondear(total('consumo_diario_kwh')),
    consumo_semanal_kwh: redondear(total('consumo_semanal_kwh')),
    consumo_mensual_kwh: redondear(total('consumo_mensual_kwh')),
    consumo_anual_kwh: redondear(total('consumo_anual_kwh'))
  };

  detalle.forEach((e) => {
    e.porcentaje_participacion = resumenConsumo.consumo_mensual_kwh > 0
      ? redondear((e.consumo_mensual_kwh / resumenConsumo.consumo_mensual_kwh) * 100, 1)
      : 0;
  });

  const mayorConsumidor = detalle.length
    ? detalle.reduce((max, e) => (e.consumo_mensual_kwh > max.consumo_mensual_kwh ? e : max))
    : null;

  return {
    resumen_hogar: {
      ...resumenConsumo,
      ...calcularCosto(resumenConsumo, tarifa),
      cantidad_electrodomesticos: detalle.length
    },
    mayor_consumidor: mayorConsumidor,
    detalle_por_electrodomestico: detalle
  };
}

module.exports = {
  SEMANAS_POR_MES,
  MESES_POR_ANIO,
  DIAS_POR_ANIO,
  redondear,
  calcularConsumo,
  calcularCosto,
  calcularHogar
};
