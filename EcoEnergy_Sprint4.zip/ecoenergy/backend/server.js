// Punto de entrada del backend EcoEnergy.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { verificarConexion } = require('./db');

const authRoutes = require('./routes/auth.routes');
const hogaresRoutes = require('./routes/hogares.routes');
const electrodomesticosRoutes = require('./routes/electrodomesticos.routes');
const consumoRoutes = require('./routes/consumo.routes');
const iaRoutes = require('./routes/ia.routes');
const tarifasRoutes = require('./routes/tarifas.routes');
const simuladorRoutes = require('./routes/simulador.routes');
const recomendacionesRoutes = require('./routes/recomendaciones.routes');
const reportesRoutes = require('./routes/reportes.routes');
const adminRoutes = require('./routes/admin.routes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Rutas de la API
app.use('/api/auth', authRoutes);
app.use('/api/hogares', hogaresRoutes);
app.use('/api/electrodomesticos', electrodomesticosRoutes);
app.use('/api/consumo', consumoRoutes);
app.use('/api/ia', iaRoutes);
app.use('/api/tarifas', tarifasRoutes);
app.use('/api/simulador', simuladorRoutes);
app.use('/api/recomendaciones', recomendacionesRoutes);
app.use('/api/reportes', reportesRoutes);
app.use('/api/admin', adminRoutes);

// Ruta de salud, util para verificar que el backend esta activo
app.get('/api/health', (req, res) => {
  res.json({ estado: 'EcoEnergy backend activo' });
});

// Manejo de rutas no encontradas
app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada.' });
});

// Manejo centralizado de errores no capturados
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'El cuerpo de la peticion no es un JSON valido.' });
  }
  console.error('Error no controlado:', err);
  res.status(500).json({ error: 'Error interno del servidor.' });
});

async function iniciar() {
  await verificarConexion();
  app.listen(PORT, () => {
    console.log(`EcoEnergy backend corriendo en http://localhost:${PORT}`);
  });
}

iniciar();
