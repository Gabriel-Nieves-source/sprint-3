// HU-12: recomendaciones inteligentes del hogar.
const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const { obtenerRecomendacionesHogar } = require('../controllers/recomendaciones.controller');

router.use(verificarToken);
router.get('/hogar/:id_hogar', obtenerRecomendacionesHogar);

module.exports = router;
