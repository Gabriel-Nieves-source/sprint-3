// HU-15, HU-16 y HU-17: funciones exclusivas del administrador.
const express = require('express');
const router = express.Router();
const { verificarToken, verificarAdmin } = require('../middleware/auth.middleware');
const admin = require('../controllers/admin.controller');

router.use(verificarToken, verificarAdmin);

router.get('/tarifa', admin.obtenerTarifa);
router.put('/tarifa', admin.actualizarTarifa);

router.get('/estadisticas', admin.obtenerEstadisticas);

router.get('/recomendaciones', admin.listarRecomendaciones);
router.post('/recomendaciones', admin.crearRecomendacion);
router.put('/recomendaciones/:id_recomendacion', admin.editarRecomendacion);
router.delete('/recomendaciones/:id_recomendacion', admin.eliminarRecomendacion);

module.exports = router;
