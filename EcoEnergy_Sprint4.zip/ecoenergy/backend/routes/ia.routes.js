const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const { preguntarIA, listarHistorial, borrarHistorial } = require('../controllers/ia.controller');

router.use(verificarToken);
router.post('/preguntar', preguntarIA);
router.get('/historial/:id_hogar', listarHistorial);
router.delete('/historial/:id_hogar', borrarHistorial);

module.exports = router;
