// HU-08: simulador de ahorro (no modifica datos reales).
const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const { simularHogar } = require('../controllers/simulador.controller');

router.use(verificarToken);
router.post('/hogar/:id_hogar', simularHogar);

module.exports = router;
