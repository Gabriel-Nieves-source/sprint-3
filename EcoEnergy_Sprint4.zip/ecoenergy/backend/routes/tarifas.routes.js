// HU-06: tarifa personal del usuario.
const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const { obtenerMiTarifa, actualizarMiTarifa, eliminarMiTarifa } = require('../controllers/tarifas.controller');

router.use(verificarToken);
router.get('/mi-tarifa', obtenerMiTarifa);
router.put('/mi-tarifa', actualizarMiTarifa);
router.delete('/mi-tarifa', eliminarMiTarifa);

module.exports = router;
