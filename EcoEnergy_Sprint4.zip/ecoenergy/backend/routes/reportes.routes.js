// HU-10: datos del reporte PDF e historial de reportes.
const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const { generarReporte, listarMisReportes } = require('../controllers/reportes.controller');

router.use(verificarToken);
router.get('/', listarMisReportes);
router.post('/hogar/:id_hogar', generarReporte);

module.exports = router;
