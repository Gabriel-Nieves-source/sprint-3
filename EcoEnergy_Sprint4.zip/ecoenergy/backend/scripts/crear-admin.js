// Convierte una cuenta existente en administrador (o la devuelve a usuario).
// Uso, desde la carpeta backend/:
//   npm run crear-admin -- correo@ejemplo.com
//   npm run crear-admin -- correo@ejemplo.com --quitar
// La cuenta debe haberse registrado antes desde la aplicacion.

require('dotenv').config();
const { pool } = require('../db');

async function main() {
  const correo = (process.argv[2] || '').trim();
  const quitar = process.argv.includes('--quitar');

  if (!correo || correo.startsWith('--')) {
    console.error('Indica el correo de la cuenta. Ejemplo: npm run crear-admin -- maria@ejemplo.com');
    process.exitCode = 1;
    return;
  }

  const [filas] = await pool.query('SELECT id_usuario, nombre_completo, rol FROM usuarios WHERE correo = ?', [correo]);
  if (!filas.length) {
    console.error(`No existe una cuenta con el correo ${correo}. Registrala primero en la aplicacion.`);
    process.exitCode = 1;
    return;
  }

  const nuevoRol = quitar ? 'usuario' : 'administrador';
  await pool.query('UPDATE usuarios SET rol = ? WHERE id_usuario = ?', [nuevoRol, filas[0].id_usuario]);
  console.log(`${filas[0].nombre_completo} (${correo}) ahora tiene el rol: ${nuevoRol}.`);
  console.log('Cierra sesion y vuelve a entrar para ver el menu de administracion.');
}

main()
  .catch((error) => {
    console.error('No fue posible cambiar el rol:', error.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
