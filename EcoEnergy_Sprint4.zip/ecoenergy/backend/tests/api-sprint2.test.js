// Pruebas automaticas de la API del Sprint 2 (una o mas por criterio de aceptacion).
// Uso (desde backend/), con el backend corriendo y una base de datos RECIEN CREADA
// con database/ecoenergy.sql (las pruebas crean usuarios, hogares y equipos):
//   npm run test:api
// La prueba convierte en administrador la cuenta admin@test.co que ella misma crea.
// Si OPENAI_API_KEY no esta configurada, el asistente se prueba en modo de respaldo.
require('dotenv').config();
const { pool: db } = require('../db');
const BASE = process.env.BASE || `http://localhost:${process.env.PORT || 3000}/api`;
let ok = 0, fail = 0;
const resultados = [];
function check(id, desc, cond, extra) {
  resultados.push({ id, desc, ok: !!cond });
  if (cond) ok++; else { fail++; console.log('  FALLA', id, desc, extra !== undefined ? JSON.stringify(extra).slice(0, 400) : ''); }
}
async function api(ruta, { method = 'GET', body, token } = {}) {
  const r = await fetch(BASE + ruta, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
  let j = null; try { j = await r.json(); } catch (_) {}
  return { s: r.status, j };
}
const close = (a, b, t = 0.02) => Math.abs(a - b) <= t;
async function registrar(nombre, correo) {
  await api('/auth/registro', { method: 'POST', body: { nombre_completo: nombre, correo, password: 'clave123', confirmar_password: 'clave123' } });
  const r = await api('/auth/login', { method: 'POST', body: { correo, password: 'clave123' } });
  return r.j;
}

(async () => {

  // ---------- Usuarios ----------
  const u1 = await registrar('Ana Uno', 'u1@test.co');
  const u2 = await registrar('Beto Dos', 'u2@test.co');
  check('AUTH', 'login devuelve rol usuario', u1.usuario.rol === 'usuario', u1.usuario);
  const T1 = u1.token, T2 = u2.token;

  const h1 = (await api('/hogares', { method: 'POST', token: T1, body: { nombre_hogar: 'Casa Peña' } })).j.id_hogar;
  const h2 = (await api('/hogares', { method: 'POST', token: T1, body: { nombre_hogar: 'Vacío' } })).j.id_hogar;
  const hB = (await api('/hogares', { method: 'POST', token: T2, body: { nombre_hogar: 'Casa B' } })).j.id_hogar;
  const cats = (await api('/electrodomesticos/categorias', { token: T1 })).j;
  const cat = (n) => cats.find((c) => c.nombre === n).id_categoria;
  const nuevo = async (tok, h, e) => (await api(`/electrodomesticos/hogar/${h}`, { method: 'POST', token: tok, body: e })).j.id_electrodomestico;

  const nevera = await nuevo(T1, h1, { nombre: 'Nevera', id_categoria: cat('Refrigeración'), potencia_watts: 150, cantidad: 1, horas_uso_diario: 24, dias_uso_semana: 7 });
  const tv = await nuevo(T1, h1, { nombre: 'Televisor', id_categoria: cat('Entretenimiento'), potencia_watts: 100, cantidad: 2, horas_uso_diario: 5, dias_uso_semana: 7 });
  const vent = await nuevo(T1, h1, { nombre: 'Ventilador', id_categoria: cat('Climatización'), potencia_watts: 60, cantidad: 1, horas_uso_diario: 8, dias_uso_semana: 7 });
  const lav = await nuevo(T2, hB, { nombre: 'Lavadora', id_categoria: cat('Lavado'), potencia_watts: 500, cantidad: 1, horas_uso_diario: 1, dias_uso_semana: 3 });
  await nuevo(T2, hB, { nombre: 'Bombillos', id_categoria: cat('Iluminación'), potencia_watts: 60, cantidad: 4, horas_uso_diario: 6, dias_uso_semana: 7 });

  // ---------- HU-05 ----------
  let c = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j;
  const nev = c.detalle_por_electrodomestico.find((e) => e.nombre === 'Nevera');
  check('HU-05 C1', 'consumo diario nevera 3,6 kWh', close(nev.consumo_diario_kwh, 3.6, 0.01), nev);
  check('HU-05 C2', 'consumo mensual = semanal*4.345', close(nev.consumo_mensual_kwh, 3.6 * 7 * 4.345), nev.consumo_mensual_kwh);
  check('HU-05 C3', 'consumo anual = mensual*12', close(nev.consumo_anual_kwh, nev.consumo_mensual_kwh * 12, 0.05), nev.consumo_anual_kwh);
  check('HU-05 C1b', 'resumen diario = suma diarios', close(c.resumen_hogar.consumo_diario_kwh, c.detalle_por_electrodomestico.reduce((s, e) => s + e.consumo_diario_kwh, 0)), c.resumen_hogar);
  check('HU-05 C3b', 'diario*365 ≈ anual (coherencia)', close(c.resumen_hogar.consumo_diario_kwh * 365, c.resumen_hogar.consumo_anual_kwh, 0.5), c.resumen_hogar);
  const lavC = (await api(`/consumo/hogar/${hB}`, { token: T2 })).j.detalle_por_electrodomestico.find((e) => e.nombre === 'Lavadora');
  check('HU-05 dias', 'lavadora 3 dias: dia de uso 0,5 y promedio < 0,5', lavC.consumo_dia_uso_kwh === 0.5 && lavC.consumo_diario_kwh < 0.25, lavC);
  check('HU-05 %', 'porcentajes suman 100', close(c.detalle_por_electrodomestico.reduce((s, e) => s + e.porcentaje_participacion, 0), 100, 0.2));
  const lista = (await api(`/electrodomesticos/hogar/${h1}`, { token: T1 })).j;
  check('HU-05 C4', 'listado de equipos incluye kWh calculados', lista.every((e) => typeof e.consumo_mensual_kwh === 'number'), lista[0]);
  await api(`/electrodomesticos/${nevera}`, { method: 'PUT', token: T1, body: { nombre: 'Nevera', id_categoria: cat('Refrigeración'), potencia_watts: 200, cantidad: 1, horas_uso_diario: 24, dias_uso_semana: 7 } });
  c = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j;
  check('HU-05 C5', 'recalcula al editar (4,8 kWh/dia)', close(c.detalle_por_electrodomestico.find((e) => e.nombre === 'Nevera').consumo_diario_kwh, 4.8, 0.01));
  await api(`/electrodomesticos/${nevera}`, { method: 'PUT', token: T1, body: { nombre: 'Nevera', id_categoria: cat('Refrigeración'), potencia_watts: 150, cantidad: 1, horas_uso_diario: 24, dias_uso_semana: 7 } });
  check('HU-05 seg', 'U2 no ve consumo de U1 (403)', (await api(`/consumo/hogar/${h1}`, { token: T2 })).s === 403);
  const vacio = (await api(`/consumo/hogar/${h2}`, { token: T1 })).j;
  check('HU-05 vacio', 'hogar sin equipos -> 0 y sin errores', vacio.resumen_hogar.consumo_mensual_kwh === 0 && vacio.mayor_consumidor === null, vacio);

  // ---------- HU-06 ----------
  c = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j;
  check('HU-06 C1', 'usa tarifa de referencia 850', c.tarifa_kwh_cop === 850 && c.tarifa_origen === 'referencia', c.tarifa_kwh_cop);
  const r = c.resumen_hogar;
  check('HU-06 C2-4', 'costos diario/mensual/anual = kWh*tarifa', close(r.costo_diario_cop, r.consumo_diario_kwh * 850, 1) && close(r.costo_mensual_cop, r.consumo_mensual_kwh * 850, 1) && close(r.costo_anual_cop, r.consumo_anual_kwh * 850, 1), r);
  let t = await api('/tarifas/mi-tarifa', { method: 'PUT', token: T1, body: { valor_kwh_cop: 900 } });
  check('HU-06 C5', 'usuario actualiza su tarifa', t.s === 200 && t.j.tarifa_kwh_cop === 900 && t.j.origen === 'personal', t.j);
  c = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j;
  check('HU-06 C5b', 'costos recalculados con 900', close(c.resumen_hogar.costo_mensual_cop, c.resumen_hogar.consumo_mensual_kwh * 900, 1), c.resumen_hogar);
  check('HU-06 kWh', 'cambio de tarifa no altera kWh', close(c.resumen_hogar.consumo_mensual_kwh, r.consumo_mensual_kwh, 0.001));
  const tB = (await api(`/consumo/hogar/${hB}`, { token: T2 })).j;
  check('HU-06 aislamiento', 'tarifa de U1 no afecta a U2', tB.tarifa_kwh_cop === 850);
  for (const v of [0, -850, 'abc', '', null, true, 1e9]) {
    const x = await api('/tarifas/mi-tarifa', { method: 'PUT', token: T1, body: { valor_kwh_cop: v } });
    check('HU-06 val', `rechaza tarifa ${JSON.stringify(v)}`, x.s === 400, x);
  }
  check('HU-06 val2', 'tarifa sigue en 900', (await api('/tarifas/mi-tarifa', { token: T1 })).j.tarifa_kwh_cop === 900);

  // ---------- HU-08 ----------
  c = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j;
  const venA = c.detalle_por_electrodomestico.find((e) => e.nombre === 'Ventilador');
  let sim = await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T1, body: { cambios: [{ id_electrodomestico: vent, horas_uso_diario: 4 }] } });
  const dV = sim.j.detalle.find((e) => e.nombre === 'Ventilador');
  check('HU-08 C1-2', 'nuevo consumo = mitad', close(dV.simulado.consumo_mensual_kwh, venA.consumo_mensual_kwh / 2), dV);
  check('HU-08 C3', 'diferencia mostrada', close(sim.j.ahorro.consumo_mensual_kwh, venA.consumo_mensual_kwh / 2), sim.j.ahorro);
  check('HU-08 C4', 'ahorro en dinero con tarifa del usuario', close(sim.j.ahorro.costo_mensual_cop, (venA.consumo_mensual_kwh / 2) * 900, 2) && sim.j.resultado === 'ahorro', sim.j.ahorro);
  const despues = (await api(`/electrodomesticos/hogar/${h1}`, { token: T1 })).j.find((e) => e.nombre === 'Ventilador');
  check('HU-08 C5', 'simulación no modifica datos reales', Number(despues.horas_uso_diario) === 8);
  const [[bd]] = await db.query('SELECT horas_uso_diario FROM electrodomesticos WHERE id_electrodomestico = ?', [vent]);
  check('HU-08 C5b', 'BD conserva 8 h', Number(bd.horas_uso_diario) === 8, bd);
  sim = await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T1, body: { cambios: [{ id_electrodomestico: vent, horas_uso_diario: 10 }] } });
  check('HU-08 aumento', 'aumento identificado', sim.j.resultado === 'aumento' && sim.j.ahorro.consumo_mensual_kwh < 0, sim.j.resultado);
  sim = await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T1, body: { cambios: [{ id_electrodomestico: vent, horas_uso_diario: 8 }] } });
  check('HU-08 igual', 'sin cambio -> 0', sim.j.resultado === 'sin_cambio' && sim.j.ahorro.costo_mensual_cop === 0, sim.j.ahorro);
  sim = await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T1, body: { cambios: [{ id_electrodomestico: tv, potencia_watts: 50 }] } });
  check('HU-08 eficiente', 'simula equipo más eficiente (potencia)', sim.s === 200 && sim.j.resultado === 'ahorro', sim.j);
  for (const v of [25, -1, 'abc', '', null]) {
    const x = await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T1, body: { cambios: [{ id_electrodomestico: vent, horas_uso_diario: v }] } });
    check('HU-08 val', `rechaza horas ${JSON.stringify(v)}`, x.s === 400, x);
  }
  check('HU-08 seg', 'no simula equipo de otro hogar', (await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T1, body: { cambios: [{ id_electrodomestico: lav, horas_uso_diario: 1 }] } })).s === 400);
  check('HU-08 seg2', 'U2 no simula hogar de U1', (await api(`/simulador/hogar/${h1}`, { method: 'POST', token: T2, body: { cambios: [{ id_electrodomestico: vent, horas_uso_diario: 1 }] } })).s === 403);
  check('HU-08 vacio', 'sin cambios -> 400', (await api(`/simulador/hogar/${h2}`, { method: 'POST', token: T1, body: { cambios: [] } })).s === 400);

  // ---------- HU-12 ----------
  const rec1 = (await api(`/recomendaciones/hogar/${h1}`, { token: T1 })).j;
  const rec2 = (await api(`/recomendaciones/hogar/${hB}`, { token: T2 })).j;
  check('HU-12 C1', 'análisis del comportamiento', rec1.hay_datos && rec1.analisis.mayor_consumidor === 'Nevera', rec1.analisis);
  check('HU-12 C2', 'identifica oportunidades con ahorro', rec1.acciones.some((a) => a.ahorro_mensual_cop > 0) && rec1.ahorro_potencial.mensual_cop > 0, rec1.acciones);
  check('HU-12 C3', 'acciones concretas (texto + equipo)', rec1.acciones.every((a) => a.accion && a.electrodomestico));
  const vAcc = rec1.acciones.find((a) => a.electrodomestico === 'Ventilador');
  check('HU-12 calc', 'ahorro ventilador 1h = 1/8 del consumo', vAcc && close(vAcc.ahorro_mensual_kwh, venA.consumo_mensual_kwh / 8, 0.01), vAcc);
  check('HU-12 C4', 'recomendaciones varían por usuario', JSON.stringify(rec1.acciones.map((a) => a.electrodomestico)) !== JSON.stringify(rec2.acciones.map((a) => a.electrodomestico)) && rec2.acciones.some((a) => a.tipo === 'reemplazo_led') && !rec2.acciones.some((a) => a.electrodomestico === 'Nevera'), rec2.acciones.map((a) => a.tipo + ':' + a.electrodomestico));
  check('HU-12 consejos', 'consejos del admin filtrados por categorías', rec2.consejos.some((x) => x.categoria === 'Lavado') && !rec2.consejos.some((x) => x.categoria === 'Refrigeración'), rec2.consejos.map((x) => x.categoria));
  const recV = (await api(`/recomendaciones/hogar/${h2}`, { token: T1 })).j;
  check('HU-12 vacio', 'sin datos -> mensaje, sin acciones', recV.hay_datos === false && recV.acciones.length === 0 && recV.mensaje, recV);
  check('HU-12 seg', 'U2 no ve recomendaciones de U1', (await api(`/recomendaciones/hogar/${h1}`, { token: T2 })).s === 403);

  // ---------- HU-10 ----------
  const rep = await api(`/reportes/hogar/${h1}`, { method: 'POST', token: T1 });
  check('HU-10 C1', 'reporte generado (201)', rep.s === 201 && rep.j.id_reporte, rep);
  check('HU-10 C2-4', 'incluye consumo, estadísticas y detalle', rep.j.consumo.resumen_hogar && rep.j.consumo.detalle_por_electrodomestico.length === 3 && rep.j.consumo.detalle_por_electrodomestico[0].porcentaje_participacion !== undefined);
  check('HU-10 C5', 'incluye recomendaciones', rep.j.recomendaciones.acciones.length > 0);
  check('HU-10 usuario', 'identifica usuario y hogar', rep.j.usuario.nombre_completo === 'Ana Uno' && rep.j.consumo.nombre_hogar === 'Casa Peña');
  const coh = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j;
  check('HU-10 coherencia', 'mismos valores que el panel', rep.j.consumo.resumen_hogar.costo_mensual_cop === coh.resumen_hogar.costo_mensual_cop);
  const hist = (await api('/reportes', { token: T1 })).j;
  check('HU-10 historial', 'historial de reportes', hist.length === 1 && hist[0].nombre_hogar === 'Casa Peña', hist);
  check('HU-10 seg', 'U2 no genera reporte de U1', (await api(`/reportes/hogar/${h1}`, { method: 'POST', token: T2 })).s === 403);
  check('HU-10 seg2', 'U2 no ve historial de U1', (await api('/reportes', { token: T2 })).j.length === 0);
  check('HU-10 vacio', 'reporte de hogar vacío no falla', (await api(`/reportes/hogar/${h2}`, { method: 'POST', token: T1 })).s === 201);

  // ---------- HU-11 ----------
  let ia = await api('/ia/preguntar', { method: 'POST', token: T1, body: { id_hogar: h1, pregunta: '¿Qué electrodoméstico consume más?' } });
  check('HU-11 C3', 'responde preguntas de consumo', ia.s === 200 && ia.j.respuesta.length > 0, ia.j);
  check('HU-11 C1', 'usa los datos calculados por EcoEnergy', ia.j.datos_referencia.consumo_mensual_kwh === (await api(`/consumo/hogar/${h1}`, { token: T1 })).j.resumen_hogar.consumo_mensual_kwh);
  if (ia.j.modo === 'fallback') {
    check('HU-11 C2', 'respaldo interpreta mayor consumidor con %', /Nevera/.test(ia.j.respuesta) && /%/.test(ia.j.respuesta), ia.j.respuesta);
    ia = await api('/ia/preguntar', { method: 'POST', token: T1, body: { id_hogar: h1, pregunta: '¿Cómo puedo reducir mi consumo?' } });
    check('HU-11 C4', 'respaldo da recomendaciones con ahorro', /Ahorro estimado/.test(ia.j.respuesta), ia.j.respuesta);
    ia = await api('/ia/preguntar', { method: 'POST', token: T1, body: { id_hogar: h1, pregunta: 'Dame una receta de arepas' } });
    check('HU-11 tema', 'fuera de tema', /Solo puedo ayudarte/.test(ia.j.respuesta), ia.j.respuesta);
  } else {
    console.log('  (IA conectada: las verificaciones de texto del modo de respaldo se omiten)');
  }
  check('HU-11 val', 'pregunta vacía 400', (await api('/ia/preguntar', { method: 'POST', token: T1, body: { id_hogar: h1, pregunta: '   ' } })).s === 400);
  check('HU-11 seg2', 'U2 no pregunta por hogar de U1', (await api('/ia/preguntar', { method: 'POST', token: T2, body: { id_hogar: h1, pregunta: 'consumo' } })).s === 403);
  const hIA = (await api(`/ia/historial/${h1}`, { token: T1 })).j;
  check('HU-11 historial', 'historial guardado', hIA.length >= 1, hIA.length);
  check('HU-11 historial2', 'U2 no ve historial de U1', (await api(`/ia/historial/${h1}`, { token: T2 })).s === 403);

  // ---------- Admin ----------
  for (const ruta of ['/admin/tarifa', '/admin/estadisticas', '/admin/recomendaciones']) {
    check('ADMIN seg', `usuario normal bloqueado en ${ruta}`, (await api(ruta, { token: T1 })).s === 403);
  }
  check('ADMIN seg2', 'usuario no cambia tarifa referencia', (await api('/admin/tarifa', { method: 'PUT', token: T1, body: { valor_kwh_cop: 1 } })).s === 403);
  check('ADMIN seg3', 'usuario no crea recomendaciones', (await api('/admin/recomendaciones', { method: 'POST', token: T1, body: { titulo: 'xxx', descripcion: 'yyyyyyyyyyyy' } })).s === 403);
  check('ADMIN seg4', 'sin token 401', (await api('/admin/estadisticas')).s === 401);
  const adm = await registrar('Admin Uno', 'admin@test.co');
  await db.query("UPDATE usuarios SET rol = 'administrador' WHERE correo = 'admin@test.co'");
  const TA = adm.token; // token emitido antes del cambio: el rol se verifica en BD

  // HU-15
  let ta = await api('/admin/tarifa', { token: TA });
  check('HU-15 R1', 'admin consulta tarifa', ta.s === 200 && ta.j.tarifa_referencia_cop === 850 && ta.j.usuarios_con_tarifa_personal === 1, ta.j);
  ta = await api('/admin/tarifa', { method: 'PUT', token: TA, body: { valor_kwh_cop: 950 } });
  check('HU-15 R1b', 'admin actualiza tarifa', ta.s === 200 && ta.j.tarifa_referencia_cop === 950, ta.j);
  const tB2 = (await api(`/consumo/hogar/${hB}`, { token: T2 })).j;
  check('HU-15 R2', 'tarifa nueva es predeterminada para usuarios sin tarifa personal', tB2.tarifa_kwh_cop === 950 && close(tB2.resumen_hogar.costo_mensual_cop, tB2.resumen_hogar.consumo_mensual_kwh * 950, 1));
  check('HU-15 R2b', 'usuario con tarifa personal conserva la suya', (await api(`/consumo/hogar/${h1}`, { token: T1 })).j.tarifa_kwh_cop === 900);
  const [[act]] = await db.query('SELECT COUNT(*) AS n FROM tarifas WHERE activa = 1');
  check('HU-15 hist', 'una sola tarifa activa y queda historial', Number(act.n) === 1 && (await api('/admin/tarifa', { token: TA })).j.historial.length === 2);
  for (const v of [0, -850, 'abc', '']) check('HU-15 val', `rechaza ${JSON.stringify(v)}`, (await api('/admin/tarifa', { method: 'PUT', token: TA, body: { valor_kwh_cop: v } })).s === 400);
  await api('/tarifas/mi-tarifa', { method: 'DELETE', token: T1 });
  check('HU-06 reset', 'usuario vuelve a tarifa de referencia', (await api(`/consumo/hogar/${h1}`, { token: T1 })).j.tarifa_kwh_cop === 950);

  // HU-17
  let rc = await api('/admin/recomendaciones', { method: 'POST', token: TA, body: { titulo: 'Desconectar cargadores USB', descripcion: 'Desconecte los cargadores cuando no estén en uso.', id_categoria: cat('Otros') } });
  check('HU-17 C1', 'crear', rc.s === 201, rc);
  const idR = rc.j.id_recomendacion;
  rc = await api(`/admin/recomendaciones/${idR}`, { method: 'PUT', token: TA, body: { titulo: 'Desconectar cargadores USB', descripcion: 'Desconecte cargadores y aparatos en modo de espera.', id_categoria: cat('Otros'), activa: true } });
  const listaR = (await api('/admin/recomendaciones', { token: TA })).j;
  check('HU-17 C2', 'editar sin duplicar', rc.s === 200 && listaR.filter((x) => x.titulo === 'Desconectar cargadores USB').length === 1 && listaR.find((x) => x.id_recomendacion === idR).descripcion.includes('modo de espera'));
  check('HU-17 dup', 'título duplicado 409', (await api('/admin/recomendaciones', { method: 'POST', token: TA, body: { titulo: 'Desconectar cargadores USB', descripcion: 'otra descripción larga' } })).s === 409);
  check('HU-17 val', 'vacíos 400', (await api('/admin/recomendaciones', { method: 'POST', token: TA, body: {} })).s === 400);
  check('HU-17 val2', 'sin descripción 400', (await api('/admin/recomendaciones', { method: 'POST', token: TA, body: { titulo: 'Título válido' } })).s === 400);
  check('HU-17 val3', 'categoría inexistente 400', (await api('/admin/recomendaciones', { method: 'POST', token: TA, body: { titulo: 'Otra cosa', descripcion: 'descripción suficiente', id_categoria: 999 } })).s === 400);
  // C4: contenido actualizado llega al asistente y a las recomendaciones
  await api('/admin/recomendaciones', { method: 'POST', token: TA, body: { titulo: 'Programa la lavadora en la noche', descripcion: 'Usa la lavadora solo con carga completa.', id_categoria: cat('Lavado') } });
  const recB = (await api(`/recomendaciones/hogar/${hB}`, { token: T2 })).j;
  check('HU-17 C4', 'consejo nuevo aparece en recomendaciones', recB.consejos.some((x) => x.titulo === 'Programa la lavadora en la noche'));
  const inact = listaR.find((x) => x.titulo === 'Revisa tu consumo cada mes');
  await api(`/admin/recomendaciones/${inact.id_recomendacion}`, { method: 'PUT', token: TA, body: { titulo: inact.titulo, descripcion: inact.descripcion, id_categoria: null, activa: false } });
  check('HU-17 inactiva', 'inactiva no se usa', !(await api(`/recomendaciones/hogar/${hB}`, { token: T2 })).j.consejos.some((x) => x.titulo === inact.titulo));
  rc = await api(`/admin/recomendaciones/${idR}`, { method: 'DELETE', token: TA });
  check('HU-17 C3', 'eliminar', rc.s === 200 && !(await api('/admin/recomendaciones', { token: TA })).j.some((x) => x.id_recomendacion === idR));
  check('HU-17 404', 'eliminar inexistente 404', (await api(`/admin/recomendaciones/${idR}`, { method: 'DELETE', token: TA })).s === 404);

  // HU-16
  const est = (await api('/admin/estadisticas', { token: TA })).j;
  const [[cu]] = await db.query('SELECT COUNT(*) n FROM usuarios'); const [[ch]] = await db.query('SELECT COUNT(*) n FROM hogares');
  const [[ce]] = await db.query('SELECT COUNT(*) n FROM electrodomesticos'); const [[cr]] = await db.query('SELECT COUNT(*) n FROM reportes_generados');
  check('HU-16 C1', 'usuarios', est.usuarios_registrados === Number(cu.n) && est.usuarios_registrados === 3, est);
  check('HU-16 C2', 'hogares', est.hogares_creados === Number(ch.n) && est.hogares_creados === 3);
  check('HU-16 C3', 'electrodomésticos', est.electrodomesticos_registrados === Number(ce.n) && est.electrodomesticos_registrados === 5);
  const m1 = (await api(`/consumo/hogar/${h1}`, { token: T1 })).j.resumen_hogar.consumo_mensual_kwh;
  const m2 = (await api(`/consumo/hogar/${hB}`, { token: T2 })).j.resumen_hogar.consumo_mensual_kwh;
  check('HU-16 C4', 'consumo promedio por hogar con equipos', close(est.consumo_promedio_mensual_hogar_kwh, (m1 + m2) / 2, 0.01), [est.consumo_promedio_mensual_hogar_kwh, (m1 + m2) / 2]);
  check('HU-16 C5', 'reportes generados', est.reportes_generados === Number(cr.n) && est.reportes_generados === 2);
  await api(`/reportes/hogar/${hB}`, { method: 'POST', token: T2 });
  check('HU-16 actualiza', 'se actualiza tras nuevo reporte', (await api('/admin/estadisticas', { token: TA })).j.reportes_generados === 3);
  await db.query("UPDATE usuarios SET rol = 'usuario' WHERE correo = 'admin@test.co'");
  check('ADMIN revocar', 'rol revocado surte efecto inmediato', (await api('/admin/estadisticas', { token: TA })).s === 403);
  await db.query("UPDATE usuarios SET rol = 'administrador' WHERE correo = 'admin@test.co'");

  // Robustez
  check('JSON', 'JSON inválido -> 400', (await api('/tarifas/mi-tarifa', { method: 'PUT', token: T1, body: '{malo' })).s === 400);

  await db.end();
  console.log(`\n${ok} pruebas OK, ${fail} fallidas`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('ERROR FATAL', e); process.exit(2); });
