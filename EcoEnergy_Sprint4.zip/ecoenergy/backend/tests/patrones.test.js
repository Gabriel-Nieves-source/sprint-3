// Pruebas unitarias de los patrones GoF y principios SOLID (Sprint 4).
// No necesitan base de datos, servidor ni internet: usan dobles de prueba
// gracias a la inversion de dependencias.
//
// Ejecutar:  npm run test:patrones     (usa el ejecutor nativo node:test)

const test = require('node:test');
const assert = require('node:assert/strict');

const { ClienteIA, ErrorProveedorIA } = require('../services/ia/clientes/ClienteIA');
const { ChatCompletionsAdapter } = require('../services/ia/clientes/ChatCompletionsAdapter');
const { OpenAIResponsesAdapter } = require('../services/ia/clientes/OpenAIResponsesAdapter');
const { crearClienteIA, PROVEEDORES } = require('../services/ia/fabricaClienteIA');
const { AsistenteIA, AVISOS } = require('../services/ia/asistente.service');
const { MotorRecomendaciones } = require('../services/recomendaciones/MotorRecomendaciones');
const {
  EstrategiaRecomendacion,
  ReemplazoLedEstrategia,
  ReducirHorasEstrategia,
  AgruparCiclosEstrategia,
  RevisarEficienciaEstrategia,
  ESTRATEGIAS_PREDETERMINADAS
} = require('../services/recomendaciones/estrategias');
const { calcularConsumo, calcularCosto } = require('../services/calculo.service');

// ---------- dobles de prueba ----------

function fetchFalso(status, cuerpo) {
  const llamadas = [];
  const fn = async (url, opciones) => {
    llamadas.push({ url, opciones, cuerpo: JSON.parse(opciones.body) });
    return {
      ok: status >= 200 && status < 300,
      status,
      json: async () => cuerpo,
      text: async () => (typeof cuerpo === 'string' ? cuerpo : JSON.stringify(cuerpo))
    };
  };
  fn.llamadas = llamadas;
  return fn;
}

const RECO = { acciones: [], ahorro_potencial: { mensual_kwh: 0, mensual_cop: 0, anual_cop: 0 }, consejos: [] };
const TURNOS = [{ role: 'user', content: '¿Cuánto gasto?' }];

function equipo(campos) {
  const e = { id_electrodomestico: 1, nombre: 'Equipo', categoria: 'Entretenimiento', potencia_watts: 100, cantidad: 1, horas_uso_diario: 2, dias_uso_semana: 7, porcentaje_participacion: 10, ...campos };
  return { ...e, ...calcularConsumo(e) };
}

function datosHogar(equipos, tarifa = 850) {
  const detalle = equipos.map((e) => ({ ...e, ...calcularCosto(calcularConsumo(e), tarifa) }));
  const total = detalle.reduce((s, e) => s + e.consumo_mensual_kwh, 0);
  const mayor = detalle.slice().sort((a, b) => b.consumo_mensual_kwh - a.consumo_mensual_kwh)[0] || null;
  return {
    id_hogar: 1,
    tarifa_kwh_cop: tarifa,
    detalle_por_electrodomestico: detalle,
    mayor_consumidor: mayor,
    resumen_hogar: { consumo_mensual_kwh: total, costo_mensual_cop: total * tarifa }
  };
}

// ======================= ADAPTER =======================

test('Adapter: ClienteIA es abstracta y no se puede instanciar', () => {
  assert.throws(() => new ClienteIA({ nombre: 'x', url: 'u', modelo: 'm', clave: 'k' }), /abstracta/);
});

test('Adapter: ChatCompletions traduce la peticion y la respuesta (Gemini/Groq)', async () => {
  const fetch = fetchFalso(200, { choices: [{ message: { content: 'Respuesta Gemini' } }] });
  const cliente = new ChatCompletionsAdapter({ nombre: 'Google Gemini', url: 'https://gemini/x', modelo: 'g', clave: 'k1', fetchImpl: fetch });
  const texto = await cliente.generar({ instrucciones: 'REGLAS', turnos: TURNOS });

  assert.equal(texto, 'Respuesta Gemini');
  const { url, opciones, cuerpo } = fetch.llamadas[0];
  assert.equal(url, 'https://gemini/x');
  assert.equal(opciones.headers.Authorization, 'Bearer k1');
  assert.equal(cuerpo.model, 'g');
  assert.deepEqual(cuerpo.messages[0], { role: 'system', content: 'REGLAS' });
  assert.deepEqual(cuerpo.messages.slice(1), TURNOS);
});

test('Adapter: OpenAIResponses traduce la peticion y lee output[].content[]', async () => {
  const fetch = fetchFalso(200, { output: [{ type: 'message', content: [{ type: 'output_text', text: 'Respuesta OpenAI' }] }] });
  const cliente = new OpenAIResponsesAdapter({ nombre: 'OpenAI', url: 'https://openai/x', modelo: 'o', clave: 'k2', fetchImpl: fetch });
  const texto = await cliente.generar({ instrucciones: 'REGLAS', turnos: TURNOS });

  assert.equal(texto, 'Respuesta OpenAI');
  const { cuerpo } = fetch.llamadas[0];
  assert.equal(cuerpo.instructions, 'REGLAS');
  assert.deepEqual(cuerpo.input, TURNOS);
});

test('Adapter: los errores de cualquier proveedor se traducen a un codigo comun', async () => {
  const casos = [
    [401, 'x', 'CLAVE_INVALIDA'],
    [403, 'x', 'CLAVE_INVALIDA'],
    [400, 'API key not valid', 'CLAVE_INVALIDA'],
    [429, 'quota', 'CUOTA_AGOTADA'],
    [500, 'x', 'API_NO_DISPONIBLE'],
    [503, 'x', 'API_NO_DISPONIBLE']
  ];
  for (const [status, cuerpo, codigo] of casos) {
    for (const Adaptador of [ChatCompletionsAdapter, OpenAIResponsesAdapter]) {
      const cliente = new Adaptador({ nombre: 'P', url: 'u', modelo: 'm', clave: 'k', fetchImpl: fetchFalso(status, cuerpo) });
      await assert.rejects(cliente.generar({ instrucciones: '', turnos: TURNOS }), (e) => e instanceof ErrorProveedorIA && e.codigo === codigo);
    }
  }
});

test('Adapter: sin red o con respuesta vacia -> API_NO_DISPONIBLE', async () => {
  const sinRed = async () => { throw new Error('ECONNREFUSED'); };
  const c1 = new ChatCompletionsAdapter({ nombre: 'P', url: 'u', modelo: 'm', clave: 'k', fetchImpl: sinRed });
  await assert.rejects(c1.generar({ instrucciones: '', turnos: TURNOS }), { codigo: 'API_NO_DISPONIBLE' });

  const c2 = new ChatCompletionsAdapter({ nombre: 'P', url: 'u', modelo: 'm', clave: 'k', fetchImpl: fetchFalso(200, { choices: [] }) });
  await assert.rejects(c2.generar({ instrucciones: '', turnos: TURNOS }), { codigo: 'API_NO_DISPONIBLE' });
});

// ============== FABRICA + OCP (registro de proveedores) ==============

test('Fabrica: crea el adaptador correcto para cada proveedor', () => {
  const g = crearClienteIA({ IA_PROVEEDOR: 'gemini', IA_API_KEY: 'k' });
  const q = crearClienteIA({ IA_PROVEEDOR: 'groq', IA_API_KEY: 'k' });
  const o = crearClienteIA({ IA_PROVEEDOR: 'openai', IA_API_KEY: 'k' });
  assert.ok(g instanceof ChatCompletionsAdapter);
  assert.ok(q instanceof ChatCompletionsAdapter);
  assert.ok(o instanceof OpenAIResponsesAdapter);
  assert.equal(g.url, PROVEEDORES.gemini.url);
  assert.equal(q.url, PROVEEDORES.groq.url);
  assert.ok(g instanceof ClienteIA && o instanceof ClienteIA);
});

test('Fabrica: IA_MODELO cambia el modelo; OPENAI_API_KEY sigue funcionando (Sprint 1)', () => {
  assert.equal(crearClienteIA({ IA_PROVEEDOR: 'groq', IA_API_KEY: 'k', IA_MODELO: 'otro' }).modelo, 'otro');
  assert.ok(crearClienteIA({ OPENAI_API_KEY: 'k' }) instanceof OpenAIResponsesAdapter);
});

test('Fabrica: sin clave o proveedor invalido -> null (modo respaldo)', () => {
  assert.equal(crearClienteIA({}), null);
  assert.equal(crearClienteIA({ IA_PROVEEDOR: 'gemini' }), null);
  const avisoOriginal = console.warn;
  console.warn = () => {};
  try {
    assert.equal(crearClienteIA({ IA_PROVEEDOR: 'inventado', IA_API_KEY: 'k' }), null);
  } finally {
    console.warn = avisoOriginal;
  }
});

test('OCP: un proveedor nuevo se agrega registrandolo, sin modificar el asistente', async () => {
  PROVEEDORES.prueba = { nombre: 'Proveedor Nuevo', url: 'https://nuevo/x', modelo: 'n1', Adaptador: ChatCompletionsAdapter };
  try {
    const fetch = fetchFalso(200, { choices: [{ message: { content: 'Hola desde el proveedor nuevo' } }] });
    const cliente = crearClienteIA({ IA_PROVEEDOR: 'prueba', IA_API_KEY: 'k' }, { fetchImpl: fetch });
    const asistente = new AsistenteIA({ cliente });
    const r = await asistente.responder({ datos: datosHogar([equipo({})]), recomendaciones: RECO, pregunta: 'hola' });
    assert.equal(r.modo, 'ia');
    assert.equal(r.respuesta, 'Hola desde el proveedor nuevo');
    assert.equal(r.modelo, 'Proveedor Nuevo · n1');
  } finally {
    delete PROVEEDORES.prueba;
  }
});

// ================ DIP + SRP: AsistenteIA ================

function clienteFalso(comportamiento) {
  return { descripcion: 'Falso · f1', generar: comportamiento };
}

const respaldoFalso = (datos, reco, pregunta, motivo = 'sin_api_key') => `RESPALDO:${motivo}`;

test('DIP: el asistente usa el cliente inyectado y le pasa instrucciones + datos calculados', async () => {
  let recibido;
  const asistente = new AsistenteIA({ cliente: clienteFalso(async (args) => { recibido = args; return 'ok IA'; }), respaldo: respaldoFalso });
  const r = await asistente.responder({ datos: datosHogar([equipo({ nombre: 'Nevera' })]), recomendaciones: RECO, pregunta: '¿Qué gasta más?' });

  assert.deepEqual(r, { respuesta: 'ok IA', modo: 'ia', modelo: 'Falso · f1' });
  assert.match(recibido.instrucciones, /\S/);
  const ultimo = recibido.turnos[recibido.turnos.length - 1];
  assert.equal(ultimo.role, 'user');
  assert.match(ultimo.content, /DATOS CALCULADOS POR ECOENERGY/);
  assert.match(ultimo.content, /¿Qué gasta más\?/);
});

test('DIP: sin cliente -> modo respaldo sin aviso', async () => {
  const r = await new AsistenteIA({ cliente: null, respaldo: respaldoFalso }).responder({ datos: datosHogar([equipo({})]), recomendaciones: RECO, pregunta: 'x' });
  assert.deepEqual(r, { respuesta: 'RESPALDO:sin_api_key', modo: 'fallback' });
});

test('DIP: cada error del proveedor activa el respaldo con su aviso', async () => {
  const casos = { CUOTA_AGOTADA: 'cuota', CLAVE_INVALIDA: 'clave', API_NO_DISPONIBLE: 'api', OTRO: 'api' };
  for (const [codigo, motivo] of Object.entries(casos)) {
    const asistente = new AsistenteIA({
      cliente: clienteFalso(async () => { throw new ErrorProveedorIA(codigo); }),
      respaldo: respaldoFalso,
      registrarError: () => {}
    });
    const r = await asistente.responder({ datos: datosHogar([equipo({})]), recomendaciones: RECO, pregunta: 'x' });
    assert.equal(r.modo, 'fallback');
    assert.equal(r.respuesta, `RESPALDO:${motivo}`);
    assert.equal(r.aviso, AVISOS[motivo]);
  }
});

// ======================= STRATEGY =======================

test('Strategy: EstrategiaRecomendacion es abstracta', () => {
  assert.throws(() => new EstrategiaRecomendacion('x'), /abstracta/);
});

test('Strategy: ReemplazoLED aplica solo a iluminacion de mas de 18 W', () => {
  const s = new ReemplazoLedEstrategia();
  assert.equal(s.aplica(equipo({ categoria: 'Iluminación', potencia_watts: 60 })), true);
  assert.equal(s.aplica(equipo({ categoria: 'Iluminación', potencia_watts: 9 })), false);
  assert.equal(s.aplica(equipo({ categoria: 'Cocina', potencia_watts: 60 })), false);

  const a = s.generar(equipo({ categoria: 'Iluminación', potencia_watts: 60, cantidad: 4, horas_uso_diario: 5 }), { tarifa: 850 });
  assert.equal(a.tipo, 'reemplazo_led');
  assert.ok(a.ahorro_mensual_kwh > 0 && a.ahorro_mensual_cop > 0);
  assert.equal(a.ahorro_anual_cop, Math.round(a.ahorro_mensual_cop * 12 * 100) / 100);
  assert.match(a.supuesto, /9 W/);
});

test('Strategy: ReducirHoras (uso prolongado, mayor consumidor, esenciales excluidos)', () => {
  const s = new ReducirHorasEstrategia();
  assert.equal(s.aplica(equipo({ horas_uso_diario: 8 }), { esMayorConsumidor: false }), true);
  assert.equal(s.aplica(equipo({ horas_uso_diario: 3 }), { esMayorConsumidor: true }), true);
  assert.equal(s.aplica(equipo({ horas_uso_diario: 3 }), { esMayorConsumidor: false }), false);
  assert.equal(s.aplica(equipo({ horas_uso_diario: 1 }), { esMayorConsumidor: true }), false);
  assert.equal(s.aplica(equipo({ categoria: 'Refrigeración', horas_uso_diario: 24 }), { esMayorConsumidor: true }), false);

  assert.match(s.generar(equipo({ horas_uso_diario: 12 }), { tarifa: 850 }).accion, /2 horas menos/);
  assert.match(s.generar(equipo({ horas_uso_diario: 8 }), { tarifa: 850 }).accion, /1 hora menos/);
  assert.match(s.generar(equipo({ horas_uso_diario: 3 }), { tarifa: 850 }).accion, /mayor consumidor/);
});

test('Strategy: AgruparCiclos y RevisarEficiencia', () => {
  const ag = new AgruparCiclosEstrategia();
  assert.equal(ag.aplica(equipo({ categoria: 'Lavado', dias_uso_semana: 5 })), true);
  assert.equal(ag.aplica(equipo({ categoria: 'Lavado', dias_uso_semana: 3 })), false);
  assert.match(ag.generar(equipo({ categoria: 'Lavado', dias_uso_semana: 5 }), { tarifa: 850 }).accion, /3 días por semana en lugar de 5/);

  const ef = new RevisarEficienciaEstrategia();
  assert.equal(ef.aplica(equipo({ categoria: 'Refrigeración', porcentaje_participacion: 45 })), true);
  assert.equal(ef.aplica(equipo({ categoria: 'Refrigeración', porcentaje_participacion: 20 })), false);
  assert.equal(ef.generar(equipo({ categoria: 'Refrigeración', porcentaje_participacion: 45 })).ahorro_mensual_cop, 0);
});

test('Strategy: el motor elige la estrategia de mayor ahorro por equipo', async () => {
  const fija = (tipo, ahorro) => Object.assign(Object.create(EstrategiaRecomendacion.prototype), {
    tipo,
    aplica: () => true,
    generar: () => ({ tipo, titulo: tipo, accion: tipo, ahorro_mensual_kwh: ahorro, ahorro_mensual_cop: ahorro * 850, ahorro_anual_cop: ahorro * 850 * 12 })
  });
  const motor = new MotorRecomendaciones({ estrategias: [fija('poco', 1), fija('mucho', 5), fija('medio', 3)], obtenerConsejos: async () => [] });
  const r = await motor.generar(datosHogar([equipo({})]));
  assert.equal(r.acciones.length, 1);
  assert.equal(r.acciones[0].tipo, 'mucho');
});

test('OCP + DIP: se agrega una estrategia nueva sin modificar el motor', async () => {
  class ApagarStandbyEstrategia extends EstrategiaRecomendacion {
    constructor() { super('apagar_standby'); }
    aplica(e) { return e.categoria === 'Entretenimiento'; }
    generar(e, { tarifa }) {
      return { tipo: this.tipo, titulo: `Desconecta ${e.nombre}`, accion: 'Desconéctalo de noche.', ...this.ahorroPorCambio(e, { horas_uso_diario: e.horas_uso_diario * 0.5 }, tarifa) };
    }
  }
  const consejosPedidos = [];
  const motor = new MotorRecomendaciones({
    estrategias: [...ESTRATEGIAS_PREDETERMINADAS, new ApagarStandbyEstrategia()],
    obtenerConsejos: async (cats) => { consejosPedidos.push(cats); return [{ titulo: 'Consejo falso' }]; }
  });
  const r = await motor.generar(datosHogar([equipo({ nombre: 'TV', categoria: 'Entretenimiento', horas_uso_diario: 4 })]));

  assert.equal(r.acciones[0].tipo, 'apagar_standby');
  assert.deepEqual(consejosPedidos, [['Entretenimiento']]);
  assert.deepEqual(r.consejos, [{ titulo: 'Consejo falso' }]);
});

test('Strategy: motor sin estrategias es un error; hogar vacio no genera acciones', async () => {
  assert.throws(() => new MotorRecomendaciones({ estrategias: [], obtenerConsejos: async () => [] }), /al menos una estrategia/);
  const motor = new MotorRecomendaciones({ estrategias: ESTRATEGIAS_PREDETERMINADAS, obtenerConsejos: async () => [] });
  const r = await motor.generar(datosHogar([]));
  assert.equal(r.hay_datos, false);
  assert.deepEqual(r.acciones, []);
});

test('Strategy: prioridades alta / media / informativa y maximo 6 acciones', async () => {
  const motor = new MotorRecomendaciones({ estrategias: ESTRATEGIAS_PREDETERMINADAS, obtenerConsejos: async () => [] });
  const equipos = [
    equipo({ id_electrodomestico: 1, nombre: 'Nevera', categoria: 'Refrigeración', potencia_watts: 400, horas_uso_diario: 24 }),
    ...Array.from({ length: 8 }, (_, i) => equipo({ id_electrodomestico: i + 2, nombre: `Foco ${i}`, categoria: 'Iluminación', potencia_watts: 60, horas_uso_diario: 5 }))
  ];
  const datos = datosHogar(equipos);
  const total = datos.resumen_hogar.consumo_mensual_kwh;
  datos.detalle_por_electrodomestico.forEach((e) => { e.porcentaje_participacion = Math.round((e.consumo_mensual_kwh / total) * 1000) / 10; });
  const r = await motor.generar(datos);

  assert.equal(r.acciones.length, 6);
  for (const a of r.acciones) {
    const esperada = a.ahorro_mensual_cop >= datos.resumen_hogar.costo_mensual_cop * 0.05 ? 'alta' : a.ahorro_mensual_cop > 0 ? 'media' : 'informativa';
    assert.equal(a.prioridad, esperada);
  }
});
