# EcoEnergy — Sprint 2

Aplicación web funcional para el control y optimización del consumo energético
residencial. Incluye autenticación, gestión de hogares y electrodomésticos,
cálculo automático de consumo y costo, dashboard y estadísticas (Sprint 1) y,
desde el Sprint 2: consumo y costo diario/mensual/anual, tarifa configurable,
simulador de ahorro, reporte PDF, asistente de IA mejorado, recomendaciones
inteligentes y un panel de administración (tarifas, estadísticas generales y
gestión de recomendaciones). Todo se guarda en MySQL.

> ¿Ya tenías instalado el Sprint 1? Lee primero la sección
> **15.1 Actualizar una instalación del Sprint 1**.

## Requisitos previos
- Node.js 18 o superior
- MySQL 8.0 o superior (recomendado, por uso de `CHECK` constraints)
- Un editor de código (VS Code recomendado)
- Un navegador moderno (Chrome, Firefox, Edge)

---

## 1. Instalar Node.js

1. Ir a https://nodejs.org y descargar la versión **LTS**.
2. Ejecutar el instalador y seguir los pasos por defecto.
3. Verificar la instalación abriendo una terminal y ejecutando:
   ```
   node -v
   npm -v
   ```
   Ambos comandos deben mostrar un número de versión (ej. `v20.11.0`).

---

## 2. Crear la base de datos MySQL

1. Abrir MySQL Workbench, phpMyAdmin, o la terminal de MySQL.
2. Si usas la terminal, conéctate con:
   ```
   mysql -u root -p
   ```
   e ingresa tu contraseña de MySQL cuando se solicite.
3. No es necesario crear la base de datos manualmente: el script
   `database/ecoenergy.sql` la crea automáticamente (`CREATE DATABASE ecoenergy`).

---

## 3. Ejecutar el archivo ecoenergy.sql

**Opción A — Desde la terminal:**
```
mysql -u root -p < database/ecoenergy.sql
```

**Opción B — Desde MySQL Workbench:**
1. Abrir el archivo `database/ecoenergy.sql` (File → Open SQL Script).
2. Ejecutar todo el script con el ícono de rayo ⚡ (Execute).

**Verificación:**
```sql
USE ecoenergy;
SHOW TABLES;
SELECT * FROM categorias;
SELECT * FROM tarifas;
```
Debes ver 8 tablas (`usuarios`, `hogares`, `categorias`, `electrodomesticos`,
`tarifas`, `recomendaciones`, `reportes_generados`, `consultas_ia`),
7 categorías precargadas, 1 tarifa activa de 850.00 COP/kWh y 10 consejos de
ahorro iniciales (`SELECT * FROM recomendaciones;`).

---

## 4. Configurar el archivo .env

1. Entrar a la carpeta `backend/`.
2. Copiar el archivo de ejemplo:
   ```
   cp .env.example .env
   ```
   (En Windows: copiar y pegar manualmente el archivo, o usar `copy .env.example .env`)
3. Abrir `.env` y completar con tus datos reales de MySQL:
   ```
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=tu_password_real_de_mysql
   DB_NAME=ecoenergy

   JWT_SECRET=una_clave_larga_y_dificil_de_adivinar_123456
   JWT_EXPIRES_IN=8h

   PORT=3000
   ```
4. Guardar el archivo. **Nunca subas este `.env` a un repositorio público.**

---

## 5. Instalar las dependencias

1. Desde la terminal, entra a la carpeta del backend:
   ```
   cd backend
   ```
2. Instala las dependencias:
   ```
   npm install
   ```
3. Espera a que termine (crea la carpeta `node_modules`).

---

## 6. Iniciar el backend

Dentro de `backend/`, ejecuta:
```
npm start
```

Deberías ver en la consola:
```
✅ Conexión a MySQL establecida correctamente.
🚀 EcoEnergy backend corriendo en http://localhost:3000
```

Si ves un error de conexión, revisa que:
- MySQL esté corriendo (servicio activo).
- Los datos en `.env` sean correctos (usuario, contraseña, puerto).

*(Opcional para desarrollo: `npm run dev` usa `nodemon` y reinicia el servidor automáticamente al guardar cambios.)*

---

## 7. Abrir la aplicación (frontend)

El frontend es HTML/CSS/JS puro, sin build. Dos formas de abrirlo:

**Opción A — Extensión Live Server (recomendada, VS Code):**
1. Instalar la extensión "Live Server" en VS Code.
2. Clic derecho sobre `frontend/index.html` → "Open with Live Server".
3. Se abrirá en algo como `http://127.0.0.1:5500/frontend/index.html`.

**Opción B — Abrir el archivo directamente:**
1. Doble clic en `frontend/index.html`.
2. Se abrirá en el navegador como `file:///.../index.html`.

> Nota: con la Opción B, algunos navegadores son más estrictos con CORS.
> Si tienes problemas de conexión con la API, usa la Opción A.

---

## 8. Probar el registro

1. En `index.html`, clic en "Regístrate aquí".
2. Llenar el formulario:
   - Nombre completo: `María Gómez`
   - Correo: `maria@ejemplo.com`
   - Contraseña: `eco2026!`
   - Confirmar contraseña: `eco2026!`
3. Clic en "Crear cuenta".
4. Resultado esperado: mensaje de éxito y redirección al login.

---

## 9. Probar el login

1. En `index.html`, ingresar:
   - Correo: `maria@ejemplo.com`
   - Contraseña: `eco2026!`
2. Clic en "Iniciar sesión".
3. Resultado esperado: redirección a `dashboard.html`.

---

## 10. Crear un hogar

1. En el menú superior, clic en "Mis Hogares".
2. Escribir un nombre, ej. `Casa Principal`.
3. Clic en "Crear hogar".
4. Resultado esperado: el hogar aparece en la tabla inferior.

---

## 11. Registrar un electrodoméstico

1. Desde "Mis Hogares", clic en "Ver equipos" sobre "Casa Principal"
   (o ir directo a "Electrodomésticos" en el menú).
2. Llenar el formulario:
   - Nombre: `Nevera`
   - Categoría: `Refrigeración`
   - Potencia: `300`
   - Cantidad: `1`
   - Horas de uso diario: `24`
   - Días de uso por semana: `7`
3. Clic en "Guardar electrodoméstico".
4. Resultado esperado: el equipo aparece en la tabla de electrodomésticos.

---

## 12. Verificar que el consumo se calcula

1. Ir a "Dashboard" o "Estadísticas".
2. Verificar que las tarjetas muestran un consumo mensual aproximado de
   **219 kWh** y un costo estimado aproximado de **$186.142 COP**
   (con la tarifa por defecto de 850 COP/kWh).
3. Editar la Nevera y cambiar las horas de uso diario a `12`.
4. Volver al Dashboard: el consumo mensual debe reducirse a la mitad
   automáticamente.

---

## 13. Verificar que los datos realmente se almacenan en MySQL

Desde una terminal o MySQL Workbench:
```sql
USE ecoenergy;

SELECT * FROM usuarios;
SELECT * FROM hogares;
SELECT * FROM electrodomesticos;
```

Debes ver:
- Tu usuario registrado (con `password_hash` cifrado, nunca en texto plano).
- El hogar "Casa Principal" asociado a tu `id_usuario`.
- El electrodoméstico "Nevera" asociado al `id_hogar` correcto.

Si estos datos aparecen correctamente en MySQL después de haber usado
solo la interfaz web, se confirma que **EcoEnergy no es una maqueta**:
los datos ingresados desde el navegador se guardan, consultan, actualizan
y eliminan realmente en la base de datos.

---

## Estructura del proyecto

```
ecoenergy/
├── frontend/       → HTML, CSS y JS separados (sin frameworks)
├── backend/        → API REST en Node.js + Express
├── database/       → Script SQL completo (ecoenergy.sql)
└── README.md       → Este archivo
```

## Notas de cálculo

- La fórmula de cálculo mensual usa un promedio de **4.345 semanas/mes**
  para convertir "días de uso por semana" en consumo mensual real, y el anual
  es el mensual × 12. Está documentada en `backend/services/calculo.service.js`.
- Desde el Sprint 2, el **consumo diario** se muestra como promedio por día del
  año (anual ÷ 365), para que diario, mensual y anual sean coherentes aunque un
  equipo no se use todos los días. El consumo de un día en que sí se usa sigue
  disponible en la API como `consumo_dia_uso_kwh`.

## Pruebas

- `PRUEBAS.md`: casos manuales del Sprint 1.
- `PRUEBAS_SPRINT2.md`: casos manuales del Sprint 2 con valores esperados.
- `backend/tests/api-sprint2.test.js`: pruebas automáticas de la API del
  Sprint 2 (ver sección 15.4).


---

## 14. Modulo EcoEnergy IA

El proyecto incluye un asistente de IA que interpreta los datos de consumo ya calculados por EcoEnergy y genera respuestas y recomendaciones personalizadas. La IA no reemplaza el motor matematico de consumo.

### 14.1 Instalar la dependencia de IA

Desde `backend/`:

```bash
npm install
```

No se requiere una dependencia adicional para la IA: el backend usa `fetch` nativo de Node.js 18+.

### 14.2 Configurar la API de IA

EcoEnergy puede usar tres proveedores. Gemini y Groq tienen plan gratuito.

| Proveedor | `IA_PROVEEDOR` | Dónde se saca la clave | Modelo por defecto |
|---|---|---|---|
| Google Gemini (gratis) | `gemini` | https://aistudio.google.com → *Get API key* | `gemini-3.5-flash-lite` |
| Groq (gratis) | `groq` | https://console.groq.com → *API Keys* | `openai/gpt-oss-120b` |
| OpenAI (de pago) | `openai` | https://platform.openai.com | `gpt-5.6-luna` |

En `backend/.env` agrega, por ejemplo para Gemini:

```env
IA_PROVEEDOR=gemini
IA_API_KEY=tu_clave
```

Opcional: `IA_MODELO=` para usar otro modelo del proveedor. La configuración
anterior (`OPENAI_API_KEY` y `OPENAI_MODEL`) sigue funcionando.

Los planes gratuitos tienen un límite diario de preguntas; cuando se alcanza,
EcoEnergy pasa solo al modo de respaldo hasta que el límite se renueva. En el
plan gratuito de Gemini, Google puede usar lo que se envía para mejorar sus
productos: usa datos de prueba, no información personal.

La clave debe permanecer en el backend y nunca en archivos JavaScript del frontend.

### 14.3 Ejecutar

Reinicia el backend:

```bash
npm start
```

Luego abre `frontend/asistente.html` y realiza una pregunta.

Si `OPENAI_API_KEY` no esta configurada o la API no esta disponible, EcoEnergy usa un modo de respaldo con recomendaciones basadas directamente en los datos calculados por el sistema.

---

## 15. Sprint 2

### 15.1 Actualizar una instalación del Sprint 1

Elige **una** de estas opciones:

- **Empezar de cero** (borra todos los datos): ejecuta otra vez
  `database/ecoenergy.sql`.
- **Conservar tus datos**: ejecuta una sola vez `database/migracion_sprint2.sql`:
  ```
  mysql -u root -p < database/migracion_sprint2.sql
  ```
  Agrega las columnas y tablas nuevas sin borrar usuarios, hogares ni
  electrodomésticos.

No hay dependencias nuevas en el backend. Reinicia el backend con `npm start`.
El frontend incluye Chart.js (gráficos) y pdf-lib (reporte PDF) en
`frontend/vendor/`, así que funcionan sin depender de un CDN (ambas con licencia MIT).

### 15.2 Crear un administrador

Por seguridad no existe un administrador con contraseña fija:

1. Regístrate normalmente en la aplicación con el correo del administrador.
2. Desde `backend/` ejecuta:
   ```
   npm run crear-admin -- correo_del_admin@ejemplo.com
   ```
3. Cierra sesión y vuelve a entrar: aparece el menú **Administración**.

Para quitar el rol: `npm run crear-admin -- correo@ejemplo.com --quitar`.
El backend revisa el rol en la base de datos en cada petición, así que quitar
el rol tiene efecto inmediato.

### 15.3 Qué hace cada historia de usuario

| HU | Dónde se ve | Qué se agregó |
|---|---|---|
| HU-05 Calcular consumo | Dashboard, Electrodomésticos, Estadísticas | Consumo diario (promedio), mensual y anual en kWh; se recalcula al editar un equipo; la tabla de electrodomésticos muestra su consumo. Motor único en `services/calculo.service.js`. |
| HU-06 Estimar costo | Dashboard → «Valor del kWh» | Costo diario, mensual y anual. Cada usuario puede poner la tarifa de su factura o volver a la de referencia. |
| HU-08 Simulador | Menú **Simulador** | Cambia horas de uso (y potencia, para comparar con un equipo eficiente). Muestra consumo actual vs. simulado, diferencia y ahorro en dinero. **No guarda nada**. Avisa si el escenario aumenta el consumo. |
| HU-10 Reporte PDF | Dashboard → «Descargar reporte PDF» | PDF con usuario, hogar, fecha, consumo y costos, estadísticas por equipo, 2 gráficos y recomendaciones. Cada reporte queda en el historial. |
| HU-11 Asistente IA | Menú **Asistente IA** | La IA recibe consumos, costos, porcentajes, acciones de ahorro calculadas y consejos del administrador; se le prohíbe calcular. Recuerda las últimas 3 preguntas, guarda el historial y rechaza temas ajenos. El modo de respaldo ahora responde según la pregunta. |
| HU-12 Recomendaciones | Menú **Recomendaciones** | Analiza los hábitos registrados y propone acciones concretas con ahorro calculado (reducir horas, pasar a LED, agrupar lavados, revisar la nevera), más los consejos del administrador para tus categorías. |
| HU-15 Administrar tarifas | Administración → Tarifa del kWh | El administrador cambia la tarifa de referencia; queda historial de cambios. Es la tarifa predeterminada para quien no tiene tarifa personal. |
| HU-16 Estadísticas generales | Administración → Estadísticas | Usuarios, hogares, electrodomésticos, consumo promedio mensual por hogar, reportes generados y consumo por categoría. |
| HU-17 Gestionar recomendaciones | Administración → Recomendaciones | Crear, editar, activar/desactivar y eliminar consejos. Los activos los usan las recomendaciones y el asistente. |

Decisiones tomadas donde las historias no lo definían:

- **Tarifa (HU-06 y HU-15):** la del administrador es la de referencia; el
  usuario puede usar una propia. Si la tiene, prevalece la propia.
- **Consumo promedio (HU-16):** promedio mensual de los hogares que tienen al
  menos un electrodoméstico.
- **Recomendación LED (HU-12):** supone una bombilla LED de 9 W (equivalente
  habitual a una incandescente de 60 W); la recomendación lo indica.
- **Eliminar recomendaciones (HU-17):** se borran de la base de datos; para
  conservarlas sin usarlas, desactívalas.

### 15.4 Pruebas automáticas de la API

Con el backend corriendo y la base de datos **recién creada** con
`ecoenergy.sql` (la prueba crea sus propios usuarios, hogares y equipos):

```
cd backend
npm run test:api
```

Debe terminar con `0 fallidas`. Las pruebas cubren todos los criterios de
aceptación del Sprint 2, además de validaciones y permisos entre usuarios y
roles. Si la API de IA no está configurada, prueban el modo de respaldo.

### 15.5 Nuevos endpoints

| Método | Ruta | HU |
|---|---|---|
| GET / PUT / DELETE | `/api/tarifas/mi-tarifa` | HU-06 |
| POST | `/api/simulador/hogar/:id_hogar` | HU-08 |
| POST | `/api/reportes/hogar/:id_hogar` · GET `/api/reportes` | HU-10 |
| GET / DELETE | `/api/ia/historial/:id_hogar` | HU-11 |
| GET | `/api/recomendaciones/hogar/:id_hogar` | HU-12 |
| GET / PUT | `/api/admin/tarifa` | HU-15 |
| GET | `/api/admin/estadisticas` | HU-16 |
| GET / POST / PUT / DELETE | `/api/admin/recomendaciones[/:id]` | HU-17 |

Todas requieren sesión (token JWT); las de `/api/admin` además requieren el
rol de administrador.

---

## 16. Sprint 4 — Principios SOLID y patrones GoF

En este sprint se reorganizó el código del backend **sin cambiar el
comportamiento** de la aplicación. No hay cambios en la base de datos ni en el
frontend: basta con reemplazar la carpeta `backend` (conservando tu `.env`).

### 16.1 Patrones y principios aplicados

| Qué | Dónde | Patrón / principio |
|---|---|---|
| Un adaptador por formato de API de IA con una interfaz común `ClienteIA` | `services/ia/clientes/` | **Adapter** (GoF) |
| Una clase por forma de ahorro; el motor elige la de mayor ahorro | `services/recomendaciones/` | **Strategy** (GoF) |
| El controlador del asistente se dividió en 6 módulos | `controllers/ia.controller.js`, `services/ia/` | **SRP** |
| Proveedores y estrategias se agregan sin modificar lo existente | `fabricaClienteIA.js` (`PROVEEDORES`), lista de estrategias | **OCP** |
| `AsistenteIA` y `MotorRecomendaciones` reciben sus dependencias | `asistente.service.js`, `MotorRecomendaciones.js` | **DIP** |

```
backend/services/
├── ia/
│   ├── asistente.service.js       decide IA o respaldo (recibe un ClienteIA)
│   ├── contexto.service.js        instrucciones y datos para la IA
│   ├── respaldo.service.js        respuestas sin IA
│   ├── historial.repository.js    tabla consultas_ia
│   ├── fabricaClienteIA.js        crea el adaptador según el .env
│   └── clientes/
│       ├── ClienteIA.js                 interfaz común (Target)
│       ├── ChatCompletionsAdapter.js    Gemini y Groq
│       └── OpenAIResponsesAdapter.js    OpenAI
├── recomendaciones/
│   ├── MotorRecomendaciones.js    contexto del patrón Strategy
│   └── estrategias/
│       ├── EstrategiaRecomendacion.js   interfaz común
│       └── index.js                     LED, reducir horas, agrupar ciclos, eficiencia
└── recomendaciones.service.js     arma el motor con las estrategias y MySQL
```

> El proveedor de IA ahora se crea una sola vez al iniciar el backend. Si
> cambias `IA_PROVEEDOR` o `IA_API_KEY` en el `.env`, **reinicia el backend**.

### 16.2 Cómo ampliar sin modificar el código existente

- **Nuevo proveedor de IA:** agrégalo al objeto `PROVEEDORES` de
  `services/ia/fabricaClienteIA.js` con su `url`, `modelo` y el adaptador de su
  formato. Si su API tiene un formato distinto, crea otra subclase de
  `ClienteIA` que implemente `construirCuerpo()` y `extraerTexto()`.
- **Nueva recomendación:** crea una subclase de `EstrategiaRecomendacion` con
  `aplica(equipo, contexto)` y `generar(equipo, contexto)`, y súmala a
  `ESTRATEGIAS_PREDETERMINADAS` en `services/recomendaciones/estrategias/index.js`.

### 16.3 Pruebas

```bash
cd backend
npm run test:patrones   # 20 pruebas unitarias; no necesitan MySQL ni internet
npm run test:api        # regresión de la API; necesita MySQL y el backend encendido
```
