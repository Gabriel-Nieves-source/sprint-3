# EcoEnergy — Pruebas manuales Sprint 2

Casos para verificar cada historia de usuario desde la aplicación. Los valores
esperados salen del motor de cálculo de EcoEnergy (4.345 semanas por mes).

## Datos de prueba

Crea un usuario (por ejemplo `laura@ejemplo.com`), un hogar «Casa Principal» y
estos electrodomésticos:

| Nombre | Categoría | Potencia | Cantidad | Horas/día | Días/semana |
|---|---|---|---|---|---|
| Nevera | Refrigeración | 150 | 1 | 24 | 7 |
| Televisor | Entretenimiento | 100 | 2 | 5 | 7 |
| Ventilador | Climatización | 60 | 1 | 8 | 7 |

Tarifa de referencia inicial: 850 COP/kWh.

---

## HU-05 — Calcular consumo energético

**Pasos:** abre el Dashboard con «Casa Principal».

**Resultado esperado:**
- Consumo diario (promedio): **5,08 kWh**
- Consumo mensual: **154,51 kWh**
- Consumo anual: **1.854,10 kWh**
- En la tabla, Nevera: 3,60 kWh/día, 109,49 kWh/mes, 1.313,93 kWh/año.
- En Electrodomésticos, cada equipo muestra su consumo diario y mensual.

**Recálculo:** edita la Nevera a 200 W y vuelve al Dashboard: la Nevera pasa a
4,80 kWh/día sin recargar caché.

---

## HU-06 — Estimar costo energético

**Resultado esperado con 850 COP/kWh:** costo diario **$ 4.318**, mensual
**$ 131.332**, anual **$ 1.575.983**.

**Actualizar la tarifa:**
1. En «Valor del kWh» escribe `900` y pulsa «Actualizar tarifa».
2. Costo diario **$ 4.572**, mensual **$ 139.057**, anual **$ 1.668.688**.
3. Los kWh no cambian.
4. «Usar la tarifa de referencia» devuelve los costos a 850.

**Validación:** `0` o un valor negativo no se aceptan y la tarifa no cambia.

---

## HU-08 — Simular ahorro energético

1. Abre **Simulador** y cambia las horas del Ventilador de 8 a 4.
2. Pulsa «Simular ahorro».

**Resultado esperado (tarifa 850):**
- Ventilador: 14,60 → 7,30 kWh/mes.
- Diferencia: 7,30 kWh al mes; ahorro cercano a **$ 6.205 al mes**.
- Insignia «Ahorro».
- En Electrodomésticos el Ventilador **sigue en 8 horas** (datos reales intactos).

**Otros casos:**
- 12 horas → insignia «Aumento» y costo adicional.
- Mismas horas → «Sin cambio».
- 30 horas → no se permite.
- Cambiar la potencia del Televisor de 100 a 50 W → ahorro (equipo más eficiente).

---

## HU-10 — Generar reporte PDF

1. En el Dashboard pulsa «Descargar reporte PDF».

**Resultado esperado:** se descarga `EcoEnergy_reporte_Casa_Principal_<fecha>.pdf` con:
- Usuario, hogar, fecha y tarifa usada.
- Tabla de consumo y costo diario, mensual y anual.
- Estadísticas por electrodoméstico con su porcentaje (Nevera 70,9 %).
- Dos gráficos (barras y torta).
- Recomendaciones con su ahorro estimado y consejos.

El reporte aparece en «Reportes generados» y suma en las estadísticas del
administrador (HU-16).

---

## HU-11 — Asistente de IA

1. Abre **Asistente IA** y pulsa la sugerencia «Mayor consumidor».
2. Pregunta.

**Resultado esperado:**
- Identifica a la Nevera con 70,9 % del consumo, usando las mismas cifras del Dashboard.
- Con la API configurada aparece «IA conectada»; sin API o sin créditos aparece
  «Modo respaldo» con un aviso, y la respuesta igual usa los datos del hogar.
- «¿Cómo puedo reducir mi consumo?» → acciones con ahorro en kWh y pesos.
- «Dame una receta de arepas» → responde que solo atiende temas de consumo energético.
- La pregunta aparece en «Conversación reciente»; «Borrar historial» la elimina.
- Un mensaje vacío no se envía.

---

## HU-12 — Recomendaciones inteligentes

1. Abre **Recomendaciones**.

**Resultado esperado:**
- «Lo que encontramos»: Nevera es el mayor consumidor (70,9 %) y Ventilador tiene uso prolongado.
- Acción «Reduce el uso de Ventilador» (8 → 7 horas) con su ahorro calculado.
- Acción de revisión para la Nevera (sin ahorro calculado, porque funciona 24 h).
- Consejos de las categorías Refrigeración, Entretenimiento, Climatización y generales.

**Varía según los datos:** con otro usuario que solo tenga bombillas de 60 W
aparece «Cambia ... a LED» y no aparecen acciones de la Nevera.

---

## HU-15 — Administrar tarifas

**Requisito:** un administrador (ver README, sección 15.2).

1. Administración → Tarifa del kWh → escribe `950` → Actualizar.
2. La tarifa de referencia cambia y el historial muestra el valor anterior y el nuevo.
3. Un usuario **sin** tarifa personal ve sus costos calculados con 950.
4. Un usuario **con** tarifa personal conserva la suya.
5. Un usuario normal que abre `admin.html` vuelve al Dashboard; la API responde 403.

---

## HU-16 — Consultar estadísticas generales

Administración → Estadísticas generales muestra:
- Usuarios registrados, hogares creados y electrodomésticos registrados
  (compáralos con `SELECT COUNT(*)` de cada tabla).
- Consumo promedio mensual por hogar (con los datos de prueba: 154,51 kWh si es el único hogar con equipos).
- Reportes generados (aumenta al descargar un PDF).
- Consumo mensual por categoría.

---

## HU-17 — Gestionar recomendaciones de IA

1. Administración → Recomendaciones → crea «Plancha la ropa en tandas» (categoría Otros).
2. Edítala: el cambio se ve en la tabla y no se duplica.
3. Crear otra con el mismo título → «Ya existe una recomendación con ese título».
4. Desactívala: deja de aparecer en Recomendaciones del usuario.
5. Elimínala: desaparece de la tabla.
6. Un consejo activo de la categoría de un equipo del usuario aparece en su
   página de Recomendaciones y se envía al asistente.

---

## Pruebas automáticas

`cd backend && npm run test:api` (backend corriendo y base de datos recién
creada). Debe terminar con `0 fallidas`.
